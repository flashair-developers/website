<?php
require_once './const.php';

function authorization($clientId, $code, &$message) {
    if (empty($code)) {
        $message = 'Code was not returned.';
        return false;
    } else {
        $url = 'https://iot-hub-api.flashair-developers.com/v1/token';
        $data = array(
          'grant_type' => 'authorization_code',
          'code' => $code,
          'client_id' => $clientId,
          'redirect_uri' => REDIRECT_URL);
        $header = array('Content-Type: application/x-www-form-urlencoded');
        $curl=curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header);

        $response = curl_exec($curl);
        curl_close($curl);
        if (empty($response)) {
            $message = 'Failed token api.';
            return false;
        }
        $response_json = json_decode($response);
        if (!$response_json) {
            $message = 'Failed decode token api:' . $response;
            return false;
        }
        if (property_exists($response_json, 'error')) {
            $message = 'Failed error occurred. ' . $response_json->error;
            return false;
        }
        if (!property_exists($response_json, 'access_token')) {
            $message = 'Failed decode access_token. token:' . $response_json;
            return false;
        }
        $access_token = $response_json->access_token;
        if (empty($access_token)) {
            $message = 'Failed decode access_token. token:' . $response_json;
            return false;
        }
        if (!file_put_contents('token.txt', $access_token)) {
            $message = 'Failed save authorization code.';
            return false;
        }
        $message = 'Authorization succeeded.';
        return true;
    }
}
$code = $_GET['code'];
$state = $_GET['state'];
$error = $_GET['error'];
$message = '';
$isAuthorized = false;

if (empty($state) || ($state != CLIENT_STATE)) {
    $message = 'state is invalid.';
} else if (!empty($error)) {
    $message = $error;
} else {
    $isAuthorized = authorization(CLIENT_ID, $code, $message);
}
?>
<html>
  <body>
    <p><?php echo $message ?></p>
    <?php if ($isAuthorized) : ?>
      <a href="measurement.php">Show Measurement Data</a>
    <?php endif; ?>
  </body>
</html>