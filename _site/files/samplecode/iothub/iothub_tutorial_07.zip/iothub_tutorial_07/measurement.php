<?php
require_once './const.php';

function getMeasurements($token, $device_id, &$message) {
    $url = "https://iot-hub-api.flashair-developers.com/v1/flashairs/$device_id/measurements/flashair";
    $header = array("Authorization: Bearer $token");

    $curl=curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);

    $response = curl_exec($curl);
    curl_close($curl);

    if (empty($response)) {
        $message  = 'failed obtain response';
        return false;
    }
    $response_json = json_decode($response);
    if (empty($response_json)
        || !property_exists($response_json, 'measurements')) {
        $message  = 'failed obtain Mesurements';
        return false;
    }
    $measurements = $response_json->measurements;
    return $measurements;
}
$token = file_get_contents('token.txt', false, null);
$message = '';
$measurements = getMeasurements($token, DEVICE_ID, $message);
?>
<html>
  <body>
    <?php echo $message ?>
    <ul>
    <?php
    foreach ((array) $measurements as $measure) {
      $values = implode(', ', array_filter($measure->values, 'strlen'));
      echo '<li>' . $measure->time . ':' . $values . '</li>';
    }
    ?>
    </ul>
    <a href="main.php">Back</a>
  </body>
</html>
