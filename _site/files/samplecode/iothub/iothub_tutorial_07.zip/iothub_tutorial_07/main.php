<?php
require_once './const.php';

$api_url = 'https://iot-hub-api.flashair-developers.com/v1/authorize';
$responseType = 'code';
$clientId = CLIENT_ID;
$redirectUri = str_replace('.', '%2E', rawurlencode(REDIRECT_URL));
$scope = str_replace('.', '%2E', rawurlencode('user.read flashair.read flashair.write'));
$state = CLIENT_STATE;
$auth_url = "$api_url?response_type=$responseType&client_id=$clientId&redirect_uri=$redirectUri&state=$state&scope=$scope";
?>
<html>
  <body>
    <ul>
      <li><a href="<?php echo $auth_url ?>">Authorize</a></li>
    </ul>
  </body>
</html>
