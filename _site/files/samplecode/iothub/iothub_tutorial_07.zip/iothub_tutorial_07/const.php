<?php
define('CLIENT_ID', 'xxxxxxxxxxxxxxxxxxxxxx');
define('CLIENT_STATE', 'r5h2dcvm');
define('DEVICE_ID', '000000000000000000');
define('REDIRECT_URL', 'http://localhost/auth.php');
?>
