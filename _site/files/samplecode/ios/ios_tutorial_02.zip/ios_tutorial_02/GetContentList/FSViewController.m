//
//  FSViewController.m
//  GetContentList
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/05/16.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import "FSViewController.h"

@interface FSViewController ()

@end

@implementation FSViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.labelCount.text = @"";
    self.textViewList.text = @"";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonPush:(id)sender {
    
    NSError *error = nil;
    self.labelCount.text = @"";
    self.textViewList.text = @"";
    
    // Get file list
    // Make url
    NSURL *url100 = [NSURL URLWithString:@"http://flashair/command.cgi?op=100&DIR=/DCIM"];
    // Run cgi
    NSString *dirStr =[NSString stringWithContentsOfURL:url100 encoding:NSUTF8StringEncoding error:&error];
    if ([error.domain isEqualToString:NSCocoaErrorDomain]){
        NSLog(@"error100 %@\n",error);
        return;
    }
    // Display results
    self.textViewList.text = dirStr;

    // Get the number of files
    // Make url
    NSURL *url101 = [NSURL URLWithString:@"http://flashair/command.cgi?op=101&DIR=/DCIM"];
    // Run cgi
    NSString *cntStr =[NSString stringWithContentsOfURL:url101 encoding:NSUTF8StringEncoding error:&error];
    if ([error.domain isEqualToString:NSCocoaErrorDomain]) {
        NSLog(@"error101 %@\n",error);
        return;
    }
    // Display results
    self.labelCount.text =[@"Count=" stringByAppendingString:cntStr];

}

@end
