//
//  FSViewController.h
//  DownloadContent
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/05/16.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import <UIKit/UIKit.h>
#import "FSImageViewController.h"

@interface FSViewController : UIViewController{
@private
    NSArray  *files;
    NSString *count;
    NSString *rowdata;
}
@property (strong, nonatomic) IBOutlet UILabel *labelCount;
@property (strong, nonatomic) IBOutlet UILabel *labelDirectory;
@property (strong, nonatomic) IBOutlet UITableView *tableViewFileList;
- (IBAction)buttonPush:(id)sender;
- (void)getFileList:(NSString*)path;
@end

























































































































































































































