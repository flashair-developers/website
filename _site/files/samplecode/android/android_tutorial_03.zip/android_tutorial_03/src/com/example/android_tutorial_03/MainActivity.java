/**
 *  MainActivity.java
 *    An activity that gets the unformatted contents of a FlashAir card
 *    and displays them in a clickable list on the Android screen.
 *
 *  Created by Anisha Smith, Fixstars Corporation on 2013/05/29.
 * 
 *  Copyright (c) 2013, TOSHIBA CORPORATION
 *  All rights reserved.
 *  Released under the BSD 2-Clause license.
 *  http://flashair-developers.com/documents/license.html
 */
 package com.example.android_tutorial_03;

import java.util.ArrayList;
import java.util.Locale;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.PorterDuff;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity implements AdapterView.OnItemClickListener {

	ListView listView;
	ImageView imageView;
	TextView currentDirText;
	TextView numFilesText;
	Button backButton;
	String rootDir = "DCIM";
	String directoryName = rootDir; // Initialize to rootDirectory
	ArrayAdapter<String> listAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		try {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);

			// Set buttons
			backButton = (Button)findViewById(R.id.button1);
			getWindow().setTitleColor(Color.rgb(65, 183, 216));
			backButton.getBackground().setColorFilter(Color.rgb(65, 183, 216), PorterDuff.Mode.SRC_IN);
			backButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if(directoryName.equals(rootDir)) {
						listRootDirectory();
					}
					else {
						int index = directoryName.lastIndexOf("/");
						directoryName = directoryName.substring(0, index);
						listDirectory(directoryName);
					}
				}
			});		
			backButton.setEnabled(false); // Disable in root directory
			listRootDirectory();
		} catch(Exception e) {
			Log.e("ERROR", "ERROR IN CODE: " + e.toString());
			e.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);		
		return true;
	}

	public void listRootDirectory() {
		directoryName = rootDir;
		listDirectory(directoryName);
	}

	public void listDirectory(String dir) {
		// Prepare command directory path
		if(dir.equals(rootDir)) {
			backButton.setEnabled(false);
		}
		else {
			backButton.setEnabled(true);
		}
		currentDirText = (TextView)findViewById(R.id.textView1);
		currentDirText.setText(dir + "/");
		// Fetch number of items in directory and display in a TextView
		dir = "/" + dir;
		ArrayList <NameValuePair> httpParams = new  ArrayList <NameValuePair> ();
		httpParams.add(new BasicNameValuePair("DIR", dir));
		dir = URLEncodedUtils.format (httpParams, "UTF-8" );
		numFilesText = (TextView)findViewById(R.id.textView2);
		// Fetch number of items in directory and display in a TextView
		new AsyncTask<String, Void, String>(){
			@Override
			protected String doInBackground(String... params) {
				String dir = params[0];
				String fileCount =  FlashAirRequest.getString("http://flashair/command.cgi?op=101&" + dir);				
				return fileCount;
			}
			@Override
			protected void onPostExecute(String fileCount) {
				numFilesText.setText("Items Found: " + fileCount);				
			}
		}.execute(dir);	
		// Fetch list of items in directory and display in a ListView
		new AsyncTask<String, Void, ListAdapter>(){
			@Override
			protected ListAdapter doInBackground(String... params) {
				String dir = params[0];
				ArrayList <String> fileNames = new ArrayList <String>();				
				String files = FlashAirRequest.getString("http://flashair/command.cgi?op=100&" + dir);
				String[] allFiles = files.split("([,\n])"); // split by newline or comma
				for(int i = 2; i < allFiles.length; i= i + 6) {
					if(allFiles[i].contains(".")) {
						// File
						fileNames.add(allFiles[i]);
					}
					else { // Directory, append "/"
						fileNames.add(allFiles[i] + "/");
					}
				}
				
				listAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, fileNames);
				
				return listAdapter;
			}
			@Override
			protected void onPostExecute(ListAdapter listAdapter) {
				// Set the file list to a widget
				listView = (ListView)findViewById(R.id.listView1);
				ColorDrawable divcolor = new ColorDrawable(Color.rgb(17, 19, 58));
				listView.setDivider(divcolor);
				listView.setDividerHeight(1);
				listView.setAdapter(listAdapter);
				listView.setOnItemClickListener(MainActivity.this);
			}
		}.execute(dir);	
	}

	@Override
	public void onItemClick(AdapterView<?> l, View v, int position, long id) {
		Object downloadFile = l.getItemAtPosition(position); // get item at clicked position in list of files
		if(downloadFile.toString().endsWith("/")) {
			// Directory, remove "/" and show content list
			String dirName = downloadFile.toString().substring(0, downloadFile.toString().length()-1); // all but the "/"
			directoryName = directoryName + "/" + dirName;
			listDirectory(directoryName);
		}
		else if( downloadFile.toString().toLowerCase(Locale.getDefault()).endsWith(".jpg") || downloadFile.toString().toLowerCase(Locale.getDefault()).endsWith(".jpeg")
		        || downloadFile.toString().toLowerCase(Locale.getDefault()).endsWith(".jpe") || downloadFile.toString().toLowerCase(Locale.getDefault()).endsWith(".png") ) {
			// Image file, download using ImageViewActivity
			Intent viewImageIntent = new Intent(this, ImageViewActivity.class);
			viewImageIntent.putExtra("downloadFile", downloadFile.toString());
			viewImageIntent.putExtra("directoryName", directoryName);
			MainActivity.this.startActivity(viewImageIntent); 
		} // Else, do nothing
	}
} // End MainActivity class
