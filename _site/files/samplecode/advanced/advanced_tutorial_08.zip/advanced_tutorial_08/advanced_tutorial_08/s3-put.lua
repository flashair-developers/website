local s3Util = require("s3-util")

local REGION = "ap-northeast-1"
local ACCESS_KEY = "AKIAIXXXXXXXXXXXXXXX"
local SECRET_KEY = "/id3EXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX+"
local BACKET = "flashair-bkt"

local S3Put = {}

S3Put.new = function(self, fpath, fname)
    local this = {}
    
    local SERVICE = "s3"
    local METHOD = "PUT"
    local PAYLOAD_HASH = "UNSIGNED-PAYLOAD"
    local ALGORITHM = "AWS4-HMAC-SHA256"
    local CONTENT_TYPE = "image/jpeg"

    local util = s3Util:new()
    
    local filepath = fpath
    local filename = fname
    local nowtime = util:currentTime()
    local date = os.date('!%Y%m%d', nowtime)
    local datetime = os.date('!%Y%m%dT%H%M00Z', nowtime)

    local dataPath = "/" .. filename
    local host = SERVICE .. "-" .. REGION .. ".amazonaws.com"
    local canonicalURI = "/" .. BACKET .. dataPath
    local endpoint = "https://" .. host
    local canonicalQuery = ""
    local signedHeader = "content-type;host;x-amz-content-sha256;x-amz-date"
    local credentialScope = date .. "/" .. REGION .. "/" .. SERVICE .. "/" .. "aws4_request"
            
    function this:getSignatureKey()
        local kDate = util:sha256Hmac("AWS4" .. SECRET_KEY, date)
        debug("kDate=" .. kDate)
        kDate = util:hex2Bytes(kDate)
        local kRegion = util:sha256Hmac(kDate, REGION)
        debug("kRegion=" .. kRegion)
        kRegion = util:hex2Bytes(kRegion)
        local kService = util:sha256Hmac(kRegion, SERVICE)
        debug("kService=" .. kService)
        kService = util:hex2Bytes(kService)
        local kSigning = util:sha256Hmac(kService, "aws4_request")
        debug("kSigning=" .. kSigning)
        kSigning = util:hex2Bytes(kSigning)
        return kSigning
    end

    function this:getStringToSign()
        local canonicalHeader = "content-type:" .. CONTENT_TYPE .. "\n" .. "host:" .. host .. "\n" .. "x-amz-content-sha256:" .. PAYLOAD_HASH .. "\n" .. "x-amz-date:" .. datetime .. "\n"
        local canonicalRequest = METHOD .. "\n" .. canonicalURI .. "\n" .. canonicalQuery .. "\n" .. canonicalHeader .. "\n" .. signedHeader .. "\n" .. PAYLOAD_HASH
        debug("canonicalRequest=" .. canonicalRequest)
        local stringToSign = ALGORITHM .. "\n" .. datetime .. "\n" .. credentialScope .. "\n" .. util:sha256(canonicalRequest)
        debug("----stringToSign----")
        debug(stringToSign)
        debug("----------")
        return stringToSign
    end

    function this:getAuthorizationHeader()
        local signingKey = this:getSignatureKey()
        local signingSign = this:getStringToSign()
        local signature = util:sha256Hmac(signingKey, signingSign)
        local authorizationHeader = ALGORITHM .. " " .. "Credential=" .. ACCESS_KEY .. "/" .. credentialScope .. ", " .. "SignedHeaders=" .. signedHeader .. ", " .. "Signature=" .. signature
        debug("----authorizationHeader----")
        debug(authorizationHeader)
        debug("----------")
        return authorizationHeader
    end

    function this:put()
        local filesize = lfs.attributes(filepath, "size")
        local headers = {["content-type"]=CONTENT_TYPE, ["content-length"]=filesize, ["x-amz-date"]=datetime, ["x-amz-content-sha256"]=PAYLOAD_HASH, ["Authorization"]=this:getAuthorizationHeader()}
        local requestURL = endpoint .. canonicalURI
        local body, code, header = fa.request{
            url=requestURL,
            method="PUT",
            headers=headers,
            file=filepath,
            body='<!--WLANSDFILE-->',
            bufsize=1460*10,
        }

        debug("resultCode=" .. code)
        debug("headers=" ..  cjson.encode(header))
        debug("body=" .. body)
    end 
    return this
end

function debug(msg)
    --print(msg)
end

return S3Put