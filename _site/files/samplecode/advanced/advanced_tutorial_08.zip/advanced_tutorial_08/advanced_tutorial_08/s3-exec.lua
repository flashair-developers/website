print("START")

local s3Put = require("s3-put")

local dir = "/DATA"
local timefile = "sendtime.dat"

function readSendTime()
    local sendtime = 0
    local file = io.open(timefile, "r")
    if file ~= nil then
        sendtime = file:read()
        file.close()
    else
        debug("file == nil")
    end
    if sendtime == nil then
        debug("sendtime == nil")
        sendtime = 0
    end 
    debug("r = " .. sendtime)
    return sendtime
end

function writeSendTime(sendtime)
    local file = io.open(timefile, "w+")
    if file ~= nil then
        file:write(sendtime)
        file:close()
        debug("w = " .. sendtime)
    end
end

function getFilePath(sendtime)
    local filepath, filename = nil
    local result, filelist, sendtime = fa.search("file", dir, sendtime)
    if result == 1 or filelist ~= nil then
        filepath = string.match(filelist, "(.-),")
        if filepath ~= nil then
            filename = string.match(filepath, "[^/]*$")
        end
    end
    return filepath, filename, sendtime 
end

function execute()
    local temptime = readSendTime()
    if temptime == 0 then
        print("temptime == 0")
        return
    end
    local sendtime = tonumber(readSendTime()) + 1
    local filepath, filename, time = getFilePath(sendtime)
    if filepath == nil then
        return
    end
    writeSendTime(time)
    debug("filepath = " .. filepath .. ", filename = " .. filename)
    local s3 = s3Put:new(filepath, filename)
    s3:put()
end

function debug(msg)
    --print(msg)
end

while(1) do
    execute()
    sleep(10000)
    collectgarbage("collect")
end

print("END")
