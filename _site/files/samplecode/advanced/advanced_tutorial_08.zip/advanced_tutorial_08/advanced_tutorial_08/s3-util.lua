local S3Util = {}

S3Util.new = function()
    local this = {}

    local CRYPTO_FILE = "sha256.dat"
    local BASETIME = 2592000 -- 1month
    local EXPIRATION_TIME = 7200 -- 2hour 
    local TIMEAREA_START = 0
    local TIMEAREA_END = 10

    function this:currentTime()
        local watchtime = fa.watchdog("status")
        debug("watchtime=" .. watchtime)
        local timestamp = fa.sharedmemory("read", TIMEAREA_START, TIMEAREA_END)
        checkstamp = tonumber(timestamp)
        
        if checkstamp == nil or watchtime < BASETIME - EXPIRATION_TIME then
            debug("get ntp")
            body, code, header = fa.request{
                url="http://ntp-a1.nict.go.jp/cgi-bin/jst",
                METHOD="GET"
            }
            ntptime = string.match(body, "(%d+).(%d+)")
            debug("ntptime=" .. ntptime)
            fa.watchdog("start", BASETIME)
            fa.sharedmemory("write", TIMEAREA_START, TIMEAREA_END, ntptime)
            timestamp = ntptime
        else
            timestamp = checkstamp + (BASETIME - watchtime)
        end
        return timestamp
    end

    function this:hex2Bytes(hex)
        local bytes = ""
        local len = hex:len() / 2
        for i = 1, len do
            local hexVal = string.sub(hex, (i-1) * 2 + 1, i * 2)
            local numVal = tonumber(hexVal, 16)
            local chVal = string.char(numVal) 
            bytes = bytes .. chVal
            -- debug("hexVal=" .. hexVal .. " numVal=" .. numVal .. " chVal=" .. chVal)
        end
        return bytes
    end
    
    function this:keyXor(key, pad)
        local bytes = ""
        local BLOCK_LEN = 64
        while (key:len() < BLOCK_LEN) do
            key = key .. "\x00"
        end
    
        for i = 1, BLOCK_LEN do
            local old = string.sub(key,i,i)
            local num = string.byte(old)
            local num2 = bit32.bxor(num,pad)
            local ch = string.char(num2)
            bytes = bytes .. ch
        end
        return bytes
    end
    
    function this:sha256(data)
        sleep(400)
        local file = io.open(CRYPTO_FILE, "w+")
        file:write(data)
        file:close()
        local hash = fa.hash("sha256-file", CRYPTO_FILE)
        return hash
    end
     
    function this:sha256Hmac(key, data)
        --debug("key=" .. key .. " data=" .. data)
        local hash
        local BLOCK_LEN = 64
        local SHA256LEN = 32
     
        if (BLOCK_LEN < key:len()) then
            hash = this:hex2Bytes(this:sha256(key))
            key = string.sub(hash, 1, SHA256LEN)
        end
        local ipadKey = this:keyXor(key, 0x36)
        local opadKey = this:keyXor(key, 0x5c)
     
        local buf = string.sub(ipadKey, 1, BLOCK_LEN)
        buf = buf .. data
        hash = this:hex2Bytes(this:sha256(buf)) 
     
        buf = string.sub(opadKey, 1, BLOCK_ELN)
        buf = buf .. string.sub(hash, 1, SHA256LEN)
        return this:sha256(buf)
    end
    return this
end

function debug(msg)
    --print(msg)
end

return S3Util