print("Hello World!")
local file = io.open("p:Hello.txt", "a")
file:write("Hello There!\n")
file:close()