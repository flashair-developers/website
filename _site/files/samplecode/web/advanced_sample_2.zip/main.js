/**
 *  main.js
 *
 *  Created by Junichi Kitano on 2013/05/15.
 * 
 *  Copyright (c) 2013, Fixstars Corporation
 *  All rights reserved.
 *  Released under the BSD 2-Clause license.
 *   http://flashair-developers.com/documents/license.html
 */
//Show file list
function getFileList(){
	var dir    = (arguments.length > 0) ? arguments[0] : '';
 	var showHidden = (arguments.length > 1) ? arguments[1] : false;
	var nextPath = makePath(dir);
	//Pathの末尾にスラッシュをつけてはいけない
	url="/command.cgi?op=100&DIR=/"+nextPath;
	$.get(url,function(data){
		//Pathを保存
		path=nextPath;
		//行に分割
		wlansd = data.split(/\n/g);
		//先頭行を除去
		wlansd.shift();
        //最終行も空なので除去
		wlansd.pop();
        //ソート
		wlansd.sort(cmptime);
		//領域の初期化
		$("#list").html('');
		//ルートでなければ戻りパスを用意する
		if(path!=""){
			$("#list").append(
				$("<div></div>").append(
					$('<a href="javascript:void(0)" class="dir">..</a>')
				)
			);
		}
		$.each(wlansd,function(){
			var file = this.split(',');
			var filelink = $('<a href="javascript:void(0)"></a>').text(file[1]);
			var fileobj = $("<div></div>");
			//隠しファイルを飛ばす
			if(!showHidden && (file[3] & 0x02) ){
				return;
			}
			if((file[3] & 0x10) ){
				filelink.addClass("dir");
				
			}else{
				filelink.addClass("file").attr("href",path+"/"+file[1]).attr("target","_blank");
			}
			$("#list").append(
				fileobj.append(filelink)
			);
		});		
	});
}

//maiking Path
function makePath(dir){
	var nextPath;
	if(dir==".."){
		var arrPath = path.split('/');
		arrPath.pop();
		nextPath=arrPath.join("/");
	}else if(dir==""){
		nextPath=path;
	}else{
		nextPath=path+"/"+dir;
	}
	if(nextPath=="/"){
		nextPath="";
	}
	return nextPath;
}

//UploadProcess
function doUpload(){
	var cgi="/upload.cgi";
	var fd = new FormData();
	var timestring ="0x";
	var dt = new Date();
	var year=(dt.getFullYear()-1980)<<9;
	var month=(dt.getMonth()+1)<<5;
	var date=dt.getDate();
	var hours=dt.getHours()<<11;
	var minites=dt.getMinutes()<<5;
	var seconds=Math.floor(dt.getSeconds()/2);
	timestring +=(year+month+date).toString(16) + (hours+minites+seconds).toString(16);	
	$.get(cgi + "?WRITEPROTECT=ON&UPDIR=" + path + "&FTIME=" + timestring,function(){
		var uploadFile = $('#file')[0].files[0];
		fd.append("file",uploadFile);
		$.ajax({url: cgi,
			type: "POST",
			data: fd,
			processData:false,
			contentType:false,
			success: function(html){
				if(html.indexOf("SUCCESS")){
					alert("success");
					getFileList();
				}else{
					alert("error");
				}
			}
		});			
	});	
	return false;
}

//Callback Function for sort()
function cmptime(a, b){
	var g = a.split(",");
	var f = b.split(",");
	if( eval(f[4]) == eval(g[4]) ){
		return eval(f[5] - g[5]);
	}
	else{
		return eval(f[4] - g[4]);
	}
}

//Document Ready
$(function() {
	//初期化
	wlansd = new Array();
	path="";
	getFileList();
	
	//イベント登録
	$(document).on("click","a.dir",function() {
    	getFileList(this.text);
	});
	$("#cmdUpload").click(function(e) {
        doUpload();
		return false;
    });
	
});