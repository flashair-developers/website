//
//  FSViewController.m
//  ChangeSSIDAndPassword
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/06/06.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import "FSViewController.h"

@interface FSViewController ()

@end

@implementation FSViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.labelSSID.text = @"Current SSID will be here";
    self.labelPassword.text = @"Current password will be here";
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonGetPush:(id)sender {
    
    NSError *error = nil;
    
    // Get SSID
    // Make url
    NSURL *url104 = [NSURL URLWithString:@"http://flashair/command.cgi?op=104"];
    // Run cgi
    NSString *SSIDStr =[NSString stringWithContentsOfURL:url104 encoding:NSUTF8StringEncoding error:&error];
    if ([error.domain isEqualToString:NSCocoaErrorDomain]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:self.title
                                            message:@"op=104 Failed \n check access point" delegate:nil
                                              cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        NSLog(@"error104 %@\n",error);
        return;
    }

    // Get Password
    // Make url
    NSURL *url105 = [NSURL URLWithString:@"http://flashair/command.cgi?op=105"];
    // Run cgi
    NSString *passwordStr =[NSString stringWithContentsOfURL:url105 encoding:NSUTF8StringEncoding error:&error];
    if ([error.domain isEqualToString:NSCocoaErrorDomain]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:self.title
                                            message:@"op=105 Failed \n check access point" delegate:nil
                                              cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        NSLog(@"error105 %@\n",error);
        return;
    }
    
    self.labelSSID.text = SSIDStr;
    self.labelPassword.text = passwordStr;

}

@end
