//
//  FSSetViewController.m
//  ChangeSSIDAndPassword
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/06/06.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import "FSSetViewController.h"

@interface FSSetViewController ()

@end

@implementation FSSetViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.textMASTERCODE.text = @"";
    self.textSSID.text = @"";
    self.textPassword1.text = @"";
    self.textPassword2.text = @"";

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonDonePush:(id)sender {
    
    NSError *error = nil;
        
    // Check
    NSCharacterSet *charSet = [NSCharacterSet whitespaceAndNewlineCharacterSet];    
    // MASTERCODE
    NSString *mastercodeText = [self.textMASTERCODE.text stringByTrimmingCharactersInSet:charSet];
    if ([mastercodeText isEqualToString:@""]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:self.title
                                                        message:@"Enter MASTERCODE" delegate:nil
                                              cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        return;
    }
     // SSID
    NSString *ssidText = [self.textSSID.text stringByTrimmingCharactersInSet:charSet];
    if ([ssidText isEqualToString:@""]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:self.title
                                                        message:@"Enter SSID" delegate:nil
                                              cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        return;
    }
    // password
    NSString *password1Text = [self.textPassword1.text stringByTrimmingCharactersInSet:charSet];
    NSString *password2Text = [self.textPassword2.text stringByTrimmingCharactersInSet:charSet];
    if ([password1Text isEqualToString:@""] || [password2Text isEqualToString:@""]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:self.title
                                                        message:@"Enter password" delegate:nil
                                              cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        return;
    }else if(![password1Text isEqualToString:password2Text]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:self.title
                                                        message:@"Password mismatch!" delegate:nil
                                              cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
        return;
    }
    
    // Set SSID and password
    // Make url
    NSString *urlStr = [@"http://flashair/config.cgi?MASTERCODE=" stringByAppendingString:mastercodeText];
    urlStr = [urlStr stringByAppendingString:@"&APPNETWORKKEY="];
    urlStr = [urlStr stringByAppendingString:password1Text];
    urlStr = [urlStr stringByAppendingString:@"&APPSSID="];
    urlStr = [urlStr stringByAppendingString:ssidText];
    NSURL *url = [NSURL URLWithString:urlStr];
    // Run cgi
    NSString *rtnStr =[NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
    if ([error.domain isEqualToString:NSCocoaErrorDomain]){
        NSLog(@"config.cgi %@\n",error);
        return;
    }else{
        if([rtnStr isEqualToString:@"ERROR"]){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:self.title
                                  message:@"config.cgi failed" delegate:nil
                                  cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            return;
        }
    }
    
    // Close this View
    [self.navigationController popToRootViewControllerAnimated:YES];

}

-(BOOL)textFieldShouldReturn:(UITextField*)textField{
    [textField resignFirstResponder];
    return YES;
}

@end
