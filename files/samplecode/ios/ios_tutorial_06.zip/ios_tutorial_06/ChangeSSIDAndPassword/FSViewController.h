//
//  FSViewController.h
//  ChangeSSIDAndPassword
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/06/06.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import <UIKit/UIKit.h>

@interface FSViewController : UIViewController
- (IBAction)buttonGetPush:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *labelSSID;
@property (strong, nonatomic) IBOutlet UILabel *labelPassword;
@end
