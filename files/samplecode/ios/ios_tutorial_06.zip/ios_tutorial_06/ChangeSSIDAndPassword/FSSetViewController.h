//
//  FSSetViewController.h
//  ChangeSSIDAndPassword
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/06/06.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import <UIKit/UIKit.h>

@interface FSSetViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *textMASTERCODE;
@property (strong, nonatomic) IBOutlet UITextField *textSSID;
@property (strong, nonatomic) IBOutlet UITextField *textPassword1;
@property (strong, nonatomic) IBOutlet UITextField *textPassword2;
- (IBAction)buttonDonePush:(id)sender;
@end
