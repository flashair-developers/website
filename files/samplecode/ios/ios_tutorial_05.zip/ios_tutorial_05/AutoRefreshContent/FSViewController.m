//
//  FSViewController.m
//  DownloadContent
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/05/16.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import "FSViewController.h"

@interface FSViewController ()

@end

@implementation FSViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    [self getFileList:@"/DCIM"];
    
    // Start updateCheck
    [NSThread detachNewThreadSelector:@selector(updateCheck) toTarget:self withObject:nil];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonPush:(id)sender {
    
    NSString *path = [self.labelDirectory.text substringToIndex:[self.labelDirectory.text length] - 1];
    NSRange found = [path rangeOfString:@"/" options:NSBackwardsSearch];
    
    if(found.location != NSNotFound){
        if (found.location == 0) {
            path = @"/";
        }else{
            path = [path substringToIndex:found.location];
        }
    }else{
        path = @"/";
    }
    
    // Reload tableview
    [self reloadView:path];

}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.    
    return [count intValue];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    // Configure the cell...
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    NSString *filename = [[[files objectAtIndex:indexPath.row + 1] componentsSeparatedByString:@","] objectAtIndex:1];
    NSString *dir = [[[files objectAtIndex:indexPath.row + 1] componentsSeparatedByString:@","] objectAtIndex:0];
    unsigned char attribute = [[[[files objectAtIndex:indexPath.row + 1] componentsSeparatedByString:@","] objectAtIndex:3] intValue];
    
    // If it is folder
    if ((attribute & 0x10) != 0) {
        filename = [filename stringByAppendingString:@"/" ];
        cell.imageView.image = nil;
    }else{
        NSArray *name_array = [filename componentsSeparatedByString:@"."];
        NSString *ext = [[name_array objectAtIndex:[name_array count]-1] lowercaseString];
        if (!([ext isEqualToString:@"jpg"] || [ext isEqualToString:@"jpeg"] ||
              [ext isEqualToString:@"png"] || [ext isEqualToString:@"jpe"])) {
            [cell setUserInteractionEnabled:NO];
        }else{
            
            @try{
                // Make url
                NSString *filePath = [[dir stringByAppendingString:@"/"] stringByAppendingString:filename];
                NSURL *url = [NSURL URLWithString:[@"http://flashair/thumbnail.cgi?" stringByAppendingString:filePath]];
                // Run CGI
                NSData *img_data = [NSData dataWithContentsOfURL:url];
                // Display results
                cell.imageView.image = [[UIImage alloc] initWithData:img_data];            }
            @catch (NSException *exception)
            {
                NSLog(@"thumbnail.cgi %@:%@\n", [exception name], [exception reason]);
            }
            @finally
            {
                //
            }
            
        }
    }
    
    cell.textLabel.text = filename;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.    
    rowdata = [files objectAtIndex:indexPath.row + 1];
    NSString *dir = [[rowdata componentsSeparatedByString:@","] objectAtIndex:0];
    NSString *filename = [[rowdata componentsSeparatedByString:@","] objectAtIndex:1];
    NSString *filePath = [[dir stringByAppendingString:@"/"] stringByAppendingString:filename];
    
    // If it is folder
    if(([[[rowdata componentsSeparatedByString:@","] objectAtIndex:3] intValue] & 0x10) != 0){
        // Reload tableview
        [self reloadView:filePath];
    }else{
        [self performSegueWithIdentifier:@"imageView" sender:self];
    }
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Give next View the Data
    if ([segue.identifier isEqualToString:@"imageView"]) {
        FSImageViewController *iamgeViewController = segue.destinationViewController;
        iamgeViewController.fileInfo = rowdata;
    }
}

- (void)getFileList:(NSString *)path{
    
    NSError *error = nil;
    
    // Get file list
    // Make url
    NSURL *url100 = [NSURL URLWithString:[@"http://flashair/command.cgi?op=100&DIR=" stringByAppendingString: path]];
    // Run cgi
    NSString *dirStr =[NSString stringWithContentsOfURL:url100 encoding:NSUTF8StringEncoding error:&error];
    if ([error.domain isEqualToString:NSCocoaErrorDomain]){
        NSLog(@"error100 %@\n",error);
        return;
    }
    files = [dirStr componentsSeparatedByString:@"\n"];

    // Get the number of files
    // Make url
    NSURL *url101 = [NSURL URLWithString:[@"http://flashair/command.cgi?op=101&DIR=" stringByAppendingString: path]];
    // Run cgi
    NSString *cntStr =[NSString stringWithContentsOfURL:url101 encoding:NSUTF8StringEncoding error:&error];
    if ([error.domain isEqualToString:NSCocoaErrorDomain]) {
        NSLog(@"error101 %@\n",error);
        return;
    }
    count = cntStr;
    
    // Display results
    self.labelCount.text =[@"Items Found:" stringByAppendingString:cntStr];
    if(![path isEqualToString:@"/"]){
        self.labelDirectory.text = [path stringByAppendingString:@"/" ];
    }else{
        self.labelDirectory.text = @"/";
    }
    
    
}

- (void)updateCheck
{
    bool status = true;
    NSError *error = nil;
    NSString *path,*sts;
    NSURL *url102 = [NSURL URLWithString:@"http://flashair/command.cgi?op=102"];

    while (status)
    {
        // Run cgi
        sts =[NSString stringWithContentsOfURL:url102 encoding:NSUTF8StringEncoding error:&error];
        if ([error.domain isEqualToString:NSCocoaErrorDomain]){
            NSLog(@"error102 %@\n",error);
            status = false;
        }else{
            // If flashair is updated then reload 
            if([sts intValue] == 1){
                path = [self.labelDirectory.text substringToIndex:[self.labelDirectory.text length] - 1];
                [self performSelectorOnMainThread:@selector(reloadView:) withObject:path waitUntilDone:YES];
            }
        }
        [NSThread sleepForTimeInterval:0.1f];        
    }
}

- (void) reloadView:(NSString *)path {
    [self getFileList:path];
	[self.tableViewFileList reloadData];
}

@end
