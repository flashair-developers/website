//
//  FSPhotoShareViewController.m
//  Set up Photoshare
//
//  Created by Tomoko Ikuta, Fixstars Corporation on 2013/10/28.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import <UIKit/UIKit.h>

@interface FSPhotoShareViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *labelDirectory;
@property (weak, nonatomic) IBOutlet UILabel *labelDate;
@property (weak, nonatomic) IBOutlet UIButton *buttonBack;

@property (nonatomic) NSString *path;
@property (nonatomic) NSString *date;

- (IBAction) backButton:(id)sender;
@end
