//
//  FSPhotoShareViewController.m
//  Set up Photoshare
//
//  Created by Tomoko Ikuta, Fixstars Corporation on 2013/10/28.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import "FSPhotoShareViewController.h"

@interface FSPhotoShareViewController ()

@end

@implementation FSPhotoShareViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.labelDirectory.text = self.path;
    self.labelDate.text = self.date;
    [self.navigationItem setHidesBackButton:YES];
}

- (IBAction)backButton:(id)sender {
    // back button was pressed.
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PhotoShare" message:@"Do you disable PhotoShare?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
    [alert show];
}


- (void) disablePhotoShare {
    // Disable photoshare
    // Make url
    NSError *error;
    NSString *urlStr = @"http://flashair/command.cgi?op=201";
    NSURL *url = [NSURL URLWithString:urlStr];
    //Run cgi
    NSString *rtnStr = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
    if ([error.domain isEqualToString:NSCocoaErrorDomain]) {
        NSLog(@"command.cgi %@\n", error);
    } else {
        if ([rtnStr isEqualToString:@"OK"]) {
            [self.navigationController popViewControllerAnimated:YES];
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PhotoShare" message:@"command.cgi failed" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            return;
        }
    }
}

-(void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    switch (buttonIndex) {
        case 1:
            [self disablePhotoShare];
            break;
        default:
            NSLog(@"Cancel");
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
