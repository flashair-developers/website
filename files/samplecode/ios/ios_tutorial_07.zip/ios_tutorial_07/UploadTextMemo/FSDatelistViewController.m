//
//
//  FSDatelistViewController.m
//  DownloadContent
//
//  Created by Junichi Kitano, Fixstars Corporation on 2013/10/08.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import "FSDatelistViewController.h"
#import "FSDatelistViewCell.h"
#import "FSMemoEditViewController.h"

@interface FSDatelistViewController ()

@property (nonatomic) NSDictionary *datelist;

@end

@implementation FSDatelistViewController

@synthesize files = _files;
@synthesize path = _path;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated {
    NSLog(@"viewWillAppear");
    self.datelist = [self makeDateList: self.files];
    self.labelDirectory.text = self.path;
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [self.tableViewDateList reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Pass next View the Data
    if ([segue.identifier isEqualToString:@"toMemoEdit"]) {
        FSMemoEditViewController *memoEditViewController = segue.destinationViewController;
        
        NSArray *key = [[self.datelist allKeys] objectAtIndex:self.tableViewDateList.indexPathForSelectedRow.row];
        
        // Pass the list of files and the name of the directory to DateListView.
        memoEditViewController.files = self.files;
        memoEditViewController.path = self.labelDirectory.text;
        memoEditViewController.date = [[self.datelist objectForKey:key] objectForKey:@"date"];
        memoEditViewController.memoTitle = [[self.datelist objectForKey:key] objectForKey:@"title"];
        memoEditViewController.memoBody = [[self.datelist objectForKey:key] objectForKey:@"body"];
    }
    
}

- (NSInteger)numberOfSectionInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //Todo:
    return [self.datelist count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"dateCell";
    
    FSDatelistViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    // Set values of the date at indexPath to the cell.
    NSArray *key=[[self.datelist allKeys] objectAtIndex:indexPath.row];
    cell.dateLabel.text = [[self.datelist objectForKey:key] objectForKey:@"date"];
    cell.subjectLabel.text = [[self.datelist objectForKey:key] objectForKey:@"title"];

    return cell;

}


// Make Date List
- (NSDictionary *)makeDateList:(NSArray *)filelist
{
    NSMutableDictionary *ret = nil;

    // Find unique dates of files
    NSMutableSet *dates = [NSMutableSet set];
    for (NSString *fileInfo in self.files) {
        NSArray *tokens = [fileInfo componentsSeparatedByString:@","];
        
        // Skip if it is the signature line or an empty line or not image file.
        NSString *dir = [tokens objectAtIndex:0];
        NSString *filename = [tokens objectAtIndex:1];
        NSString *ext = [[filename pathExtension] lowercaseString];
        if([dir isEqualToString:@""] || [dir isEqualToString:@"WLANSD_FILELIST\r"] ||
           !([ext isEqualToString:@"jpg"] || [ext isEqualToString:@"jpeg"] ||
            [ext isEqualToString:@"png"] || [ext isEqualToString:@"jpe"])){
            continue;
        }
        
        // Add date.
        [dates addObject:[tokens objectAtIndex:4]];
    }
    
    // Load existing memo.
    ret = [NSMutableDictionary dictionary];
    NSDateFormatter *toFormatter = [[NSDateFormatter alloc] init];
    [toFormatter setDateFormat:@"yyyyMMdd"];        //for filename
    NSDateFormatter *tostrFormatter = [[NSDateFormatter alloc] init];
    [tostrFormatter setDateFormat:@"yyyy/MM/dd"];   //for show display
    for (NSString *date in dates) {
        NSError *error = nil;
        
        // Convert date number to string.
        NSString *sDate= [toFormatter stringFromDate:[self dateAsDate:date]];
        NSString *strDate= [tostrFormatter stringFromDate:[self dateAsDate:date]];
        
        // Make up URL to the memo file.
        NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"http://flashair%@/%@.txt", self.path, sDate]];
        
        // Get memo contents from the FlashAir.
        NSString *title = @"";
        NSString *body = @"";
        NSString *memoData =[NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
        if ( ![error.domain isEqualToString:NSCocoaErrorDomain] && [memoData rangeOfString:@"DOCTYPE" options:NSCaseInsensitiveSearch].location == NSNotFound) {
            // Success to get existing memo.
            NSArray *data = [memoData componentsSeparatedByString:@"\n"];
            title = [data objectAtIndex:0];
            body = [data objectAtIndex:1];
        }
        
        // Add this memo to the list.
        NSDictionary *memo = [NSDictionary dictionaryWithObjectsAndKeys:
                              title, @"title",
                              body, @"body",
                              strDate, @"date",
                              nil];
       [ret setObject:memo forKey:sDate];
    }
    return ret;
}



// Convert CSV date to NSDate
- (NSDate*)dateAsDate:(NSString *)dateString{
    NSDateFormatter *aFormatter = [[NSDateFormatter alloc] init];
    [aFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *aString = [NSString stringWithFormat:@"%04u-%02u-%02u 00:00:00",
            ((([dateString intValue]>> 9)  & 0x1FF) + 1980),
            (([dateString intValue] >> 5)  & 0xF),
            ([dateString intValue]        & 0x1F)
            ];
    NSDate* aDate = [aFormatter dateFromString:aString];
    return aDate;
}
                    
@end
