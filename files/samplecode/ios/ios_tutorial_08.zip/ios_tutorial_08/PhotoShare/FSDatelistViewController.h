//
//
//  FSDatelistViewController.h
//  DownloadContent
//
//  Created by Junichi Kitano, Fixstars Corporation on 2013/10/08.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import <UIKit/UIKit.h>

@interface FSDatelistViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *labelDirectory;
@property (strong, nonatomic) IBOutlet UITableView *tableViewDateList;
@property (nonatomic) NSArray *files;
@property (nonatomic) NSString *path;
@end
