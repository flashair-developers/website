//
//  FSMemoEditViewController.m
//  UploadTextMemo
//
//  Created by Doi, Fixstars Corporation on 2013/10/28.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import "FSMemoEditViewController.h"
#import "FSPhotoShareViewController.h"
#import "FSCollectionViewCell.h"
#import "FSImageViewController.h"

@interface FSMemoEditViewController ()

@end

@implementation FSMemoEditViewController

@synthesize files = _files;
@synthesize path = _path;
@synthesize date = _date;
@synthesize memoTitle = _memoTitle;
@synthesize memoBody = _memoBody;
@synthesize imgCollectionView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.labelDirectory.text = [self.path stringByAppendingString:@"/"];
    self.labelDate.text = self.date;
    self.textFieldTitle.text = self.memoTitle;
    self.textViewMemo.text = self.memoBody;
    
    self.imgCollectionView.delegate   = self;
    self.imgCollectionView.dataSource = self;

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidShow:) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    NSMutableArray *muary = [NSMutableArray array];
    for(NSString *file in self.files) {
        NSString *fileInfo = file;
        NSString *date = [[fileInfo componentsSeparatedByString:@","] objectAtIndex:4];
        
        unsigned char attribute = [[[fileInfo componentsSeparatedByString:@","] objectAtIndex:3] intValue];
        if(!((attribute & 0x10) != 0)){
            if ([date isEqualToString:[self getDate16:self.date]]) {
                [muary addObject:fileInfo];
            }
        }
    }
    dateFiles = [muary copy];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)keyboardDidShow:(NSNotification*)notification
{
    CGPoint scrollPoint = CGPointMake(0.0, 220.0);
    //[self.storyboard instantiateViewControllerWithIdentifier:@"MemoEditScrollView"];
    [self.scrollView setContentOffset:scrollPoint animated:YES];
}

- (void)keyboardWillHide:(NSNotification*)notification
{
    [self.scrollView setContentOffset:CGPointZero animated:YES];
}


- (BOOL)textFieldShouldReturn:(UITextField*)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textViewShouldEndEditing:(UITextView*)textView
{
    [textView resignFirstResponder];
    return YES;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{

    return dateFiles.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"Cell";
    FSCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    
    NSString *filename = [[[dateFiles objectAtIndex:indexPath.row ] componentsSeparatedByString:@","] objectAtIndex:1];
    NSString *dir = [[[dateFiles objectAtIndex:indexPath.row ] componentsSeparatedByString:@","] objectAtIndex:0];
    unsigned char attribute = [[[[dateFiles objectAtIndex:indexPath.row ] componentsSeparatedByString:@","] objectAtIndex:3] intValue];
    cell.backgroundColor = [UIColor blueColor];
    // If it is folder
    if ((attribute & 0x10) != 0) {
        filename = [filename stringByAppendingString:@"/" ];
        cell.imageView.image = nil;
        
    }else{
        NSArray *name_array = [filename componentsSeparatedByString:@"."];
        NSString *ext = [[name_array objectAtIndex:[name_array count]-1] lowercaseString];
        if (!([ext isEqualToString:@"jpg"] || [ext isEqualToString:@"jpeg"] ||
              [ext isEqualToString:@"png"] || [ext isEqualToString:@"jpe"])) {
            [cell setUserInteractionEnabled:NO];
        }else{
            
            @try{
                // Make url
                NSString *filePath = [[dir stringByAppendingString:@"/"] stringByAppendingString:filename];
                NSURL *url = [NSURL URLWithString:[@"http://flashair/thumbnail.cgi?" stringByAppendingString:filePath]];
                NSLog(@"path:%@", url);
                // Run CGI
                NSData *img_data = [NSData dataWithContentsOfURL:url];
                // Display results
                cell.imageView.image = [[UIImage alloc] initWithData:img_data];
            }
            @catch (NSException *exception)
            {
                NSLog(@"thumbnail.cgi %@:%@\n", [exception name], [exception reason]);
            }
            @finally
            {
                //
            }
            
        }
    }
    return  cell;
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    rowdata = [dateFiles objectAtIndex:indexPath.row];
    [self performSegueWithIdentifier:@"toImageView" sender:self];
}

- (IBAction)doneButton:(id)sender
{

    
    // Set Write-Protect and upload directory and System-Time
    // Make System-Time
    NSDate *systemdate = [NSDate date];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *dateCompnents;
    dateCompnents =[calendar components:NSYearCalendarUnit
                                        | NSMonthCalendarUnit
                                        | NSDayCalendarUnit
                                        | NSHourCalendarUnit
                                        | NSMinuteCalendarUnit
                                        | NSSecondCalendarUnit fromDate:systemdate];
    
    NSInteger year =([dateCompnents year]-1980) << 9;
    NSInteger month = ([dateCompnents month]) << 5;
    NSInteger day = [dateCompnents day];
    NSInteger hour = [dateCompnents hour] << 11;
    NSInteger minute = [dateCompnents minute]<< 5;
    NSInteger second = floor([dateCompnents second]/2);
    
    NSString *datePart = [@"0x" stringByAppendingString:[NSString stringWithFormat:@"%x%x" ,year+month+day,hour+minute+second]];
    
    // Make Filename
    NSString *filename=[[self.date stringByReplacingOccurrencesOfString:@"/" withString:@""] stringByAppendingString :@".txt"];
    
    // Make url
    NSString *urlStr = @"http://flashair/upload.cgi";
    urlStr = [urlStr stringByAppendingString:@"?WRITEPROTECT=ON&UPDIR="];
    urlStr = [urlStr stringByAppendingString:self.path];
    urlStr = [urlStr stringByAppendingString:@"&FTIME="];
    urlStr = [urlStr stringByAppendingString:datePart];
    NSURL *url = [NSURL URLWithString:urlStr];
    // Run cgi
    NSError *error;
    NSString *rtnStr =[NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
    if ([error.domain isEqualToString:NSCocoaErrorDomain]){
        NSLog(@"upload.cgi %@\n",error);
        return;
    }else{
        if(![rtnStr isEqualToString:@"SUCCESS"]){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:self.title
                                                            message:@"upload.cgi:setup failed" delegate:nil
                                                  cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            return;
        }
    }

    // File upload
    // Make Data
    self.memoTitle = self.textFieldTitle.text;
    self.memoBody = self.textViewMemo.text;
    NSString *memoData = [[self.memoTitle stringByAppendingString:@"\n"] stringByAppendingString:self.memoBody];
    NSData *textData=[memoData dataUsingEncoding:NSUTF8StringEncoding ];
    
    //url
    url=[NSURL URLWithString:@"http://flashair/upload.cgi"];
    
    //boundary
    CFUUIDRef uuid = CFUUIDCreate(nil);
    CFStringRef uuidString = CFUUIDCreateString(nil, uuid);
	CFRelease(uuid);
    NSString *boundary = [NSString stringWithFormat:@"flashair-%@",uuidString];
    
    //header
    NSString *header = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    
    //body
    NSMutableData *body=[NSMutableData data];
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
	[body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"file\"; filename=\"%@\"\r\n",filename] dataUsingEncoding:NSUTF8StringEncoding]];
	[body appendData:[[NSString stringWithFormat:@"Content-Type: text/plain\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
	[body appendData:textData];
	[body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
	
    
    //Request
    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request addValue:header forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:body];
    
    NSURLResponse *response;
    
    NSData *result = [NSURLConnection sendSynchronousRequest:request
                                           returningResponse:&response
                                                       error:&error];
    rtnStr=[[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
    
    if ([error.domain isEqualToString:NSCocoaErrorDomain]){
        NSLog(@"upload.cgi %@\n",error);
        return;
    }else{
        if([rtnStr rangeOfString:@"Success"].location==NSNotFound){     //v2.0
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:self.title
                                                message:@"upload.cgi: POST failed" delegate:nil
                                                  cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            return;
        }
    }
    
    
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
}

- (IBAction) photoshareButton:(id)sender {
    NSError *error = nil;
    
    // Set photoshare
    // Make url
    NSString *urlStr = [@"http://flashair/command.cgi?op=200&DIR=" stringByAppendingString:self.path ];
    urlStr = [urlStr stringByAppendingString:@"&DATE="];
    urlStr = [urlStr stringByAppendingString: [self getDate16: self.date]];
    NSURL *url = [NSURL URLWithString:urlStr];
    //Run cgi
    NSString *rtnStr = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
    if ([error.domain isEqualToString:NSCocoaErrorDomain]) {
        NSLog(@"command.cgi %@\n", error);
    } else {
        if ([rtnStr isEqualToString:@"OK"]) {
            // Segue
            [self performSegueWithIdentifier:@"toPhotoshare" sender:self];
        } else {
            NSLog(@"%@", rtnStr);
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PhotoShare" message:@"command.cgi failed" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            return;
        }
    }
}


- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Pass next View the Data
    if ([segue.identifier isEqualToString:@"toImageView"]) {
        FSImageViewController *imageViewController = segue.destinationViewController;
        imageViewController.fileInfo = rowdata;
    }
    if ([segue.identifier isEqualToString:@"toPhotoshare"]) {
        FSPhotoShareViewController *photoShareViewController = segue.destinationViewController;
        photoShareViewController.path = [self.path stringByAppendingString:@"/"];
        photoShareViewController.date = self.date;
    }
    
}


//getDatefromDateFormat
- (NSString*)getDate16:(NSString *)dateString{
    NSInteger year = ([[dateString substringWithRange:NSMakeRange(0, 4)] intValue] -1980) << 9;
    NSInteger month = ([[dateString substringWithRange:NSMakeRange(5, 2)] intValue]) <<5;
    NSInteger day = [[dateString substringWithRange:NSMakeRange(8, 2)] intValue];
    NSString *datePart = [NSString stringWithFormat:@"%d" ,year+month+day];
    return datePart;
}


@end
