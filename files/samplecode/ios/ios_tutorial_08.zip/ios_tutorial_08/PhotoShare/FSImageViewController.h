//
//  FSImageViewController.h
//  DownloadContent
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/05/30.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import <UIKit/UIKit.h>

@interface FSImageViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic) NSString *fileInfo;
@end
