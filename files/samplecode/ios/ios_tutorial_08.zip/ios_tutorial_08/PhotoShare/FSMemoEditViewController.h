//
//  FSMemoEditViewController.h
//  UploadTextMemo
//
//  Created by Doi, Fixstars Corporation on 2013/10/28.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import <UIKit/UIKit.h>

@interface FSMemoEditViewController : UIViewController <UICollectionViewDataSource, UICollectionViewDelegate> {
@private
    NSArray *dateFiles;
    NSString *rowdata;
}

@property (strong, nonatomic) IBOutlet UILabel *labelDirectory;
@property (strong, nonatomic) IBOutlet UILabel *labelDate;
@property (strong, nonatomic) IBOutlet UITextField *textFieldTitle;
@property (strong, nonatomic) IBOutlet UITextField *textViewMemo;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UIButton *buttonPhotoshare;
@property (weak, nonatomic) IBOutlet UICollectionView *imgCollectionView;
@property (nonatomic) NSArray *files;
@property (nonatomic) NSString *path;
@property (nonatomic) NSString *date;
@property (nonatomic) NSString *memoTitle;
@property (nonatomic) NSString *memoBody;

- (IBAction) doneButton:(id)sender;
- (IBAction) photoshareButton:(id)sender;

@end
