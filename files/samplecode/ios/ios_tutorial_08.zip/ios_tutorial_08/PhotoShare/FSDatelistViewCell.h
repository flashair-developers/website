//
//  FSDatelistViewCell.h
//  DatelistviewCell
//
//  Created by doi, Fixstars Corporation on 2013/10/28.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//
//

#import <UIKit/UIKit.h>

@interface FSDatelistViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *dateLabel;
@property (strong, nonatomic) IBOutlet UILabel *subjectLabel;


@end
