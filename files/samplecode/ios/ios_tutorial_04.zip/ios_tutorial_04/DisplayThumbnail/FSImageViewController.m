//
//  FSImageViewController.m
//  DownloadContent
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/05/30.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import "FSImageViewController.h"

@interface FSImageViewController ()

@end

@implementation FSImageViewController

@synthesize fileInfo = _fileInfo;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Make a file path
    NSString *dir = [[self.fileInfo componentsSeparatedByString:@","] objectAtIndex:0];
    NSString *filename = [[self.fileInfo componentsSeparatedByString:@","] objectAtIndex:1];
    NSString *filePath = [[dir stringByAppendingString:@"/"] stringByAppendingString:filename];
    // Run
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://flashair/%@", filePath]];
    // Get image data
    if(nil == url)return;
	NSData *img_data = [NSData dataWithContentsOfURL:url];
    UIImage *img = [[UIImage alloc] initWithData:img_data];
    // Display result
    self.imageView.image = img;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
