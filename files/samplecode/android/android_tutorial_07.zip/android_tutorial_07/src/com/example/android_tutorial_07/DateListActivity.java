/**
 *  DateListActivity.java
 *  Uploading to FlashAir
 *
 *  Created by Nahoko Uwabe, Fixstars Corporation on 2013/09/23.
 * 
 *  Copyright (c) 2013, TOSHIBA CORPORATION    
 *  All rights reserved.
 *  Released under the BSD 2-Clause license.
 *  http://flashair-developers.com/documents/license.html
 */

package com.example.android_tutorial_07;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.PorterDuff;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;

public class DateListActivity extends Activity implements AdapterView.OnItemClickListener {

    ListView listView;
    ImageView imageView;
    TextView currentDirText;
    Button backButton;
    String rootDir = "DCIM";
    String directoryName;
    SimpleAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_list);
        try {
            Bundle extrasData = getIntent().getExtras();
            directoryName = extrasData.getString("dir");
            if(!directoryName.equals(rootDir)) {
                int index = directoryName.lastIndexOf("/");
                directoryName = directoryName.substring(0, index);
            }    
            
            // Set backButton
            backButton = (Button)findViewById(R.id.button1);
            getWindow().setTitleColor(Color.rgb(65, 183, 216));
            backButton.getBackground().setColorFilter(Color.rgb(65, 183, 216), PorterDuff.Mode.SRC_IN);
            backButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                	DateListActivity.this.finish(); // Go back to Get screen
                }
            });            
            listDirectory(directoryName);
        }
        catch(Exception e) {
            Log.e("ERROR", "ERROR: " + e.toString());
            e.printStackTrace();
        }
    }

    public void listRootDirectory() {
        directoryName = rootDir;
        listDirectory(directoryName);
    }

    public void listDirectory(String dir) {
        // Prepare command directory path
        currentDirText = (TextView)findViewById(R.id.textView1);
        currentDirText.setText(dir + "/");

        // Fetch list of items in directory and display in a ListView
        new AsyncTask<String, Void, ListAdapter>(){
            @Override
            protected ListAdapter doInBackground(String... params) {
                String dir = params[0];
                
                String cmddir = "/" + dir;
                ArrayList <NameValuePair> httpParams = new  ArrayList <NameValuePair> ();
                httpParams.add(new BasicNameValuePair("DIR", cmddir));
                cmddir = URLEncodedUtils.format (httpParams, "UTF-8" );
                
                Set <Integer> dates = new HashSet <Integer>();                
                String files = FlashAirRequest.getString("http://flashair/command.cgi?op=100&" + cmddir);
                String[] allFiles = files.split("([,\n])"); // split by newline or comma
                for(int i = 2; i < allFiles.length; i= i + 6) {
                    if(allFiles[i].contains(".")) {
                        if( (allFiles[i].toString().toLowerCase(Locale.getDefault()).endsWith(".jpg")) || (allFiles[i].toString().toLowerCase(Locale.getDefault()).endsWith(".jpeg"))
                                || (allFiles[i].toString().toLowerCase(Locale.getDefault()).endsWith(".jpe")) || (allFiles[i].toString().toLowerCase(Locale.getDefault()).endsWith(".png")) ) {                            
                            // Image file
                            Integer date = Integer.parseInt(allFiles[i+3]);
                            dates.add(date);
                        }
                    }
                }                    
                
                // Get Title
                ArrayList<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
                for (Integer date : dates) {
                    Map<String, Object> entry = new HashMap<String, Object>();                    
                    String dataStr = FlashAirRequest.getString("http://flashair/" + dir + "/" + getDate(date, "") + ".txt");
                    String[] dataStrAry = dataStr.split("([\n])"); // split by newline
                    entry.put("date", getDate(date, "/"));
                    if (dataStrAry.length >= 2) {
                        entry.put("title", dataStrAry[0]);
                    }                    
                    data.add(entry);
                }
                
                // Set the file list to a widget
                listAdapter = new SimpleAdapter(DateListActivity.this,
                        data,
                        R.layout.list_view_item,
                        new String[]{"date", "title"},
                        new int[]{R.id.textView1, R.id.textView2});

                return listAdapter;
            }
            @Override
            protected void onPostExecute(ListAdapter listAdapter) {
                listView = (ListView)findViewById(R.id.listView1);
                ColorDrawable divcolor = new ColorDrawable(Color.rgb(17, 19, 58));
                listView.setDivider(divcolor);
                listView.setDividerHeight(1);
                listView.setAdapter(listAdapter);
                listView.setOnItemClickListener(DateListActivity.this);                
            }
        }.execute(dir);    

    }
    
    @Override
    public void onRestart(){
        super.onRestart();
        listDirectory(directoryName);
    }    

    @Override
    public void onItemClick(AdapterView<?> l, View v, int position, long id) {
        Object item = l.getItemAtPosition(position); // Get item at clicked position in list of files
        if(item instanceof Map<?, ?>) {
            Map<String, Object> mapItem = (Map<String, Object>) item;
            Object selectDate = mapItem.get("date");
            // Next button to start new intent to allow day detail
            Intent memoEdit = new Intent(getBaseContext(), MemoEditActivity.class);     
            memoEdit.putExtra("date", selectDate.toString());
            memoEdit.putExtra("dir", directoryName);    
            DateListActivity.this.startActivity(memoEdit);        
        }
    }
    
    public String getDate(Integer date, String sep) {
        return  String.format("%04d", ((date >> 9) & 0x1FF)+1980)+sep+
                String.format("%02d", (date >> 5)  & 0xF)+sep+
                String.format("%02d", date & 0x1F);
    }
} // End DateListActivity class    