/**
 *  MainActivity.java
 *    An activity that gets the current SSID and password
 *    of a FlashAir card and displays them on the Android screen.
 *
 *  Created by Anisha Smith, Fixstars Corporation on 2013/06/07.
 * 
 *  Copyright (c) 2013, TOSHIBA CORPORATION
 *  All rights reserved.
 *  Released under the BSD 2-Clause license.
 *  http://flashair-developers.com/documents/license.html
 */
package com.example.android_tutorial_06;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

	TextView SSID;
	TextView password;
	Button getButton;
	Button setButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getWindow().setTitleColor(Color.rgb(65, 183, 216));
		getButton = (Button)findViewById(R.id.button1);
		setButton = (Button)findViewById(R.id.button2);
		getButton.getBackground().setColorFilter(Color.rgb(65, 183, 216), PorterDuff.Mode.SRC_IN);
		setButton.getBackground().setColorFilter(Color.rgb(65, 183, 216), PorterDuff.Mode.SRC_IN);
		try {
			getButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Set button to show current SSID and Password
					getSSID();
					getPassword();
				}
			});
		} catch(Exception e) {
			Log.e("ERROR", "ERROR: " + e.toString());
			e.printStackTrace();
		}
		try {
			setButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Set button to start new intent to allow new SSID and password input
					Intent setSSIDPassword = new Intent(getBaseContext(), SetScreenActivity.class);
					MainActivity.this.startActivity(setSSIDPassword);
				}
			});
		} catch(Exception e) {
			Log.e("ERROR", "ERROR: " + e.toString());
			e.printStackTrace();
		}
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}


	public void getSSID() {
		new AsyncTask<String, Void, String>(){
			@Override
			protected String doInBackground(String... params) {
				return FlashAirRequest.getString(params[0]);
			}
			@Override
			protected void onPostExecute(String currentSSID) {
				SSID = (TextView)findViewById(R.id.textView4);
				SSID.setText(currentSSID);
			}
		}.execute("http://flashair/command.cgi?op=104");				
	}


	public void getPassword() {
		new AsyncTask<String, Void, String>(){
			@Override
			protected String doInBackground(String... params) {
				return FlashAirRequest.getString(params[0]);
			}
			@Override
			protected void onPostExecute(String currentPassword) {
				password = (TextView)findViewById(R.id.textView5);
				password.setText(currentPassword);
			}
		}.execute("http://flashair/command.cgi?op=105");
	}

} // End MainActivity class
