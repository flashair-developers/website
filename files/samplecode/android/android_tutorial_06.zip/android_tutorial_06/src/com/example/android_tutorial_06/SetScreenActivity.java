/**
 *  SetScreenActivity.java
 *    An activity that allows the user to set
 *    a new SSID and password for a 
 *    FlashAir card using an Android.
 *
 *  Created by Anisha Smith, Fixstars Corporation on 2013/06/07.
 * 
 *  Copyright (c) 2013, TOSHIBA CORPORATION
 *  All rights reserved.
 *  Released under the BSD 2-Clause license.
 *  http://flashair-developers.com/documents/license.html
 */
package com.example.android_tutorial_06;

import java.util.Locale;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SetScreenActivity extends Activity {

	EditText mastercodeField;
	EditText SSIDfield;
	EditText passwordField;
	EditText passwordField2;
	Button backButton;
	Button doneButton;
	String newSSID = "";
	String newPassword = "";
	String newPassword2 = "";
	String mastercode = "";
	TextWatcher fieldWatcher = new TextWatcher(){
		@Override
		public void afterTextChanged(Editable e) {
			if(mastercodeField.getText().toString().isEmpty() || SSIDfield.getText().toString().isEmpty()
			   || passwordField.getText().toString().isEmpty() || passwordField2.getText().toString().isEmpty() ) {
				doneButton.setEnabled(false);
			}
			else {
				doneButton.setEnabled(true);
			}
		}

		@Override
		public void beforeTextChanged(CharSequence cs, int start, int count, int after) {
			// Do nothing
		}

		@Override
		public void onTextChanged(CharSequence cs, int start, int before, int count) {
			// Do nothing
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_set_screen);
		getWindow().setTitleColor(Color.rgb(65, 183, 216));
		backButton = (Button)findViewById(R.id.button1);
		doneButton = (Button)findViewById(R.id.button2);
		mastercodeField = (EditText)findViewById(R.id.editMC);
		SSIDfield = (EditText)findViewById(R.id.editText1);
		passwordField = (EditText)findViewById(R.id.editText2);
		passwordField2 = (EditText)findViewById(R.id.editText3);
		backButton.getBackground().setColorFilter(Color.rgb(65, 183, 216), PorterDuff.Mode.SRC_IN);
		doneButton.getBackground().setColorFilter(Color.rgb(65, 183, 216), PorterDuff.Mode.SRC_IN);
		doneButton.setEnabled(false); // Disable until text fields have been filled
		mastercodeField.setHintTextColor(Color.rgb(65, 183, 216));
		SSIDfield.setHintTextColor(Color.rgb(65, 183, 216));
		passwordField.setHintTextColor(Color.rgb(65, 183, 216));
		passwordField2.setHintTextColor(Color.rgb(65, 183, 216));
		try {
			getIntent();
			backButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					SetScreenActivity.this.finish();
				}
			});
			doneButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					getInput();
					setNewSSIDPassword();
				}
			});
			mastercodeField.addTextChangedListener(fieldWatcher);
			SSIDfield.addTextChangedListener(fieldWatcher);
			passwordField.addTextChangedListener(fieldWatcher);
			passwordField2.addTextChangedListener(fieldWatcher);
		} catch(Exception e) {
			Log.e("ERROR", "ERROR: " + e.toString());
			e.printStackTrace();
		}
	}


	public void setNewSSIDPassword() {
		if(passwordConfirmed()) {
			
			// If passwords match, do HTTP command, catch and display if command fails
			new AsyncTask<String, Void, String>(){
				@Override
				protected String doInBackground(String... params) {		
					return FlashAirRequest.getString(params[0]);	
				}
				@Override
				protected void onPostExecute(String result) {
					if(result.toUpperCase(Locale.getDefault()).equals("SUCCESS")) {
						Toast.makeText(SetScreenActivity.this, "Remember to reconnect to your FlashAir device using the new SSID and password!", Toast.LENGTH_LONG).show();
						SetScreenActivity.this.finish(); // Go back to Get screen
					}					
				}
			}.execute("http://flashair/config.cgi?MASTERCODE=" + mastercode + "&APPNETWORKKEY=" + newPassword + "&APPSSID=" + newSSID);				
		}
		else {
			// If passwords don't match, display toast
			Toast.makeText(this, "Password mismatch!", Toast.LENGTH_SHORT).show();
			passwordField.setText("");
			passwordField2.setText("");
		}
	}


	public Boolean passwordConfirmed() {
		if(newPassword.equals(newPassword2)) {
			return true;
		}
		return false;
	}


	public void getInput() {
		mastercode = mastercodeField.getText().toString();
		newSSID = SSIDfield.getText().toString();
		newPassword = passwordField.getText().toString();
		newPassword2 = passwordField2.getText().toString();
	}

} // End SetScreenActivity class
