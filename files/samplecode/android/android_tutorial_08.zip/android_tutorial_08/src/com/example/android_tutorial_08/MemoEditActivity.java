/**
 *  MemoEditActivity.java
 *  Photo Share
 *
 *  Created by Nahoko Uwabe, Fixstars Corporation on 2013/09/23.
 * 
 *  Copyright (c) 2013, TOSHIBA CORPORATION
 *  All rights reserved.
 *  Released under the BSD 2-Clause license.
 *  http://flashair-developers.com/documents/license.html
 */
package com.example.android_tutorial_08;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.SimpleAdapter.ViewBinder;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class MemoEditActivity extends Activity {
    TextView dateText;
    TextView currentDirText;
    Button backButton;
    Button saveButton;
    Button photoShareButton;
    EditText titleField;
    EditText memoField;
    GridView gridView;
    String newTitle = "";
    String newMemo = "";
    String date;
    String rootDir = "DCIM";
    String directoryName; 
    ArrayList<String> fileNamelist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memo_edit);
        
        Bundle extrasData = getIntent().getExtras();
        date = extrasData.getString("date");
        directoryName = extrasData.getString("dir");

        getWindow().setTitleColor(Color.rgb(65, 183, 216));
        // Set backButton
        backButton = (Button) findViewById(R.id.button1);
        backButton.getBackground().setColorFilter(Color.rgb(65, 183, 216), PorterDuff.Mode.SRC_IN);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            	MemoEditActivity.this.finish(); // Go back
            }
        });
        
       // Set photoShareButton
        photoShareButton = (Button)findViewById(R.id.button3);
        photoShareButton.getBackground().setColorFilter(Color.rgb(65, 183, 216), PorterDuff.Mode.SRC_IN);
        photoShareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 
                new AsyncTask<String, Void, String>(){
                    @Override
                    protected String doInBackground(String... params) {        
                        return FlashAirRequest.getString(params[0]);    
                    }
                    @Override
                    protected void onPostExecute(String result) {
                        if(result.toUpperCase(Locale.getDefault()).equals("OK")) {
                            Intent photoShare = new Intent(getBaseContext(), PhotoShareActivity.class);     
                            photoShare.putExtra("date", date);
                            photoShare.putExtra("dir", directoryName);
                            MemoEditActivity.this.startActivity(photoShare);                                
                        }else{
                            Toast.makeText(MemoEditActivity.this, "Enable failed.", Toast.LENGTH_LONG).show();    
                        }                    
                    }
                }.execute("http://flashair/command.cgi?op=200&DIR=/" + directoryName + "&DATE=" + getDate16(date));
    
            }
        });        

        // Set saveButton
        saveButton = (Button) findViewById(R.id.button2);
        saveButton.getBackground().setColorFilter(Color.rgb(65, 183, 216), PorterDuff.Mode.SRC_IN);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newTitle = titleField.getText().toString();
                newMemo = memoField.getText().toString();
                saveNewTitleMemo();
            }
        });

        // Set titleField and memoField
        titleField = (EditText) findViewById(R.id.editTitle);
        titleField.setHintTextColor(Color.rgb(65, 183, 216));
        memoField = (EditText) findViewById(R.id.editMemo);
        memoField.setHintTextColor(Color.rgb(65, 183, 216));

        // Set dateText
        dateText = (TextView) findViewById(R.id.textView2);
        dateText.setText(date);
        
        // Get title and memo
        new AsyncTask<String, Void, ArrayList<String>>() {
            @Override
            protected ArrayList<String> doInBackground(String... params) {
                String dir = params[0];
                ArrayList<String> rtnAry = new ArrayList<String>();
                String files = FlashAirRequest
                        .getString("http://flashair/" + dir + "/" + date.replaceAll("/", "") + ".txt");
                String[] allFiles = files.split("([\n])"); // split by newline
                if (allFiles.length >= 2) {
                    // File
                    rtnAry.add(allFiles[0]);
                    rtnAry.add(allFiles[1]);
                }
                return rtnAry;
            }

            @Override
            protected void onPostExecute(ArrayList<String> strary) {
                // Set the data to a TextView
                titleField = (EditText) findViewById(R.id.editTitle);
                memoField = (EditText) findViewById(R.id.editMemo);

                if (strary.size() > 0) {
                    titleField.setText(strary.get(0));
                    memoField.setText(strary.get(1));
                } else {
                    titleField.setText("");
                    memoField.setText("");
                }
            }
        }.execute(directoryName);

        // Set gridView
        gridView = (GridView) findViewById(R.id.gridView1);
        gridView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                    int position, long id) {
                Object item = parent.getItemAtPosition(position); // Get item at clicked position in list of files
                if (item instanceof Map<?, ?>) {
                    Map<String, Object> mapItem = (Map<String, Object>) item;
                    Object downloadFile = mapItem.get("fname");
                    if ((downloadFile.toString().toLowerCase(Locale.getDefault()).endsWith(".jpg"))|| (downloadFile.toString().toLowerCase(Locale.getDefault()).endsWith(".jpeg"))
                            || (downloadFile.toString().toLowerCase(Locale.getDefault()).endsWith(".jpe"))|| (downloadFile.toString().toLowerCase(Locale.getDefault()).endsWith(".png"))) {
                        // Image file, download using ImageViewActivity
                        Intent viewImageIntent = new Intent(MemoEditActivity.this, ImageViewActivity.class);
                        viewImageIntent.putExtra("downloadFile",downloadFile.toString());
                        viewImageIntent.putExtra("directoryName", directoryName);
                        MemoEditActivity.this.startActivity(viewImageIntent);
                    } // Not an image file, do nothing
                }
            }
        });
        listDirectory(directoryName);
    }

    public void listDirectory(String dir) {
        // Prepare command directory path
        currentDirText = (TextView)findViewById(R.id.textView1);
        currentDirText.setText(dir + "/");        
        
        final ProgressDialog waitDialog;        
        // Setting ProgressDialog
        waitDialog = new ProgressDialog(this);
        waitDialog.setMessage("Now downloading...");
        waitDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        waitDialog.show();          
        
        ArrayList<NameValuePair> httpParams = new ArrayList<NameValuePair>();
        httpParams.add(new BasicNameValuePair("DIR", dir));
        dir = URLEncodedUtils.format(httpParams, "UTF-8");
        // Fetch list of items in directory and display in a ListView
        new AsyncTask<String, Void, ListAdapter>() {
            @Override
            protected ListAdapter doInBackground(String... params) {
                String dir = params[0];
                ArrayList<String> fileNames = new ArrayList<String>();
                fileNamelist = new ArrayList<String>();
                String files = FlashAirRequest
                        .getString("http://flashair/command.cgi?op=100&" + dir);
                String[] allFiles = files.split("([,\n])"); // split by newline�@or comma
                for (int i = 2; i < allFiles.length; i = i + 6) {
                    if (allFiles[i].contains(".") && allFiles[i+3].contains(getDate16(date))) {
                        if( (allFiles[i].toLowerCase(Locale.getDefault()).endsWith(".jpg")) || (allFiles[i].toLowerCase(Locale.getDefault()).endsWith(".jpeg"))
                                || (allFiles[i].toLowerCase(Locale.getDefault()).endsWith(".jpe")) || (allFiles[i].toLowerCase(Locale.getDefault()).endsWith(".png")) ) {                           
                            // Image file                        
                            fileNames.add(allFiles[i]);
                        }
                    }
                }

                // Get thumbnails
                ArrayList<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
                for (int i = 0; i < fileNames.size(); i++) {
                    String url = "";
                    url = "http://flashair/thumbnail.cgi?" + directoryName + "/" + fileNames.get(i);
                    Map<String, Object> entry = new HashMap<String, Object>();
                    Bitmap thumbnail = null;
                    BitmapDrawable drawnIcon = null;
                    if ((url.toLowerCase(Locale.getDefault()).endsWith(".jpg")) || (url.toLowerCase(Locale.getDefault()).endsWith(".jpeg"))) {
                        thumbnail = FlashAirRequest.getBitmap(url);
                        drawnIcon = new BitmapDrawable(getResources(), thumbnail);
                    }
                    if(thumbnail == null) {
                        entry.put("thmb", R.drawable.ic_launcher);
                    }
                    else {
                        entry.put("thmb", drawnIcon);
                    }
                    entry.put("fname", fileNames.get(i)); // Put file name onto the map
                    data.add(entry);                    
                }

                // Set the file list to a widget
                SimpleAdapter listAdapter = new SimpleAdapter(
                		MemoEditActivity.this, data, R.layout.grid_view_item,
                        new String[] { "thmb", "fname" }, 
                        new int[] {R.id.imageView1, android.R.id.text1 });
                listAdapter.setViewBinder(new CustomViewBinder());

                return listAdapter;
            }

            @Override
            protected void onPostExecute(ListAdapter adapter) {
                waitDialog.dismiss();
                gridView.setAdapter(adapter);
            }
        }.execute(dir);
    }

    public void saveNewTitleMemo() {        
        new AsyncTask<String, Void, String>(){
            @Override
            protected String doInBackground(String... params) {        
                String parameter = "?WRITEPROTECT=ON&UPDIR=/" + directoryName;    
                parameter = parameter + "&FTIME=" + getDateTime16();
                String filename = date.replaceAll("/", "") + ".txt";
                String rtnStr = "";                    
                rtnStr = FlashAirRequest.getString(params[0] + parameter);
                if(rtnStr.toUpperCase(Locale.getDefault()).equals("SUCCESS")) {
                    rtnStr = FlashAirRequest.upload( params[0], filename, newTitle + "\n" + newMemo);
                }
                return     rtnStr;
            }    
            @Override
            protected void onPostExecute(String result) {
                if(result.toUpperCase(Locale.getDefault()).indexOf("SUCCESS") >= 0) {
                    Toast.makeText(MemoEditActivity.this, "Save Completed.", Toast.LENGTH_LONG).show();
                }                    
            }
        }.execute("http://flashair/upload.cgi");                
    }

    class CustomViewBinder implements ViewBinder {
        @Override
        public boolean setViewValue(View view, Object obj, String text) {
            if ((view instanceof ImageView) && (obj instanceof Drawable)) {
                ImageView imageView = (ImageView) view;
                BitmapDrawable thumbnail = (BitmapDrawable) obj;
                imageView.setImageDrawable((Drawable) thumbnail);
                return true;
            }
            return false;
        }
    }
    
    public String getDateTime16() {        
        Calendar calendar = Calendar.getInstance();
        int year = (calendar.get(Calendar.YEAR) - 1980) << 9;
        int month = (calendar.get(Calendar.MONTH) + 1) << 5;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hours = calendar.get(Calendar.HOUR_OF_DAY) << 11;
        int minites = calendar.get(Calendar.MINUTE) << 5;
        int seconds = calendar.get(Calendar.SECOND) / 2;
        String rtnStr = "0x" +  Integer.toHexString(year + month + day)    +  Integer.toHexString(hours + minites + seconds);
        return rtnStr;
    }    
    
    public String getDate16(String date) {
        String rtnStr = "";        
        try{
            int year = (Integer.parseInt(date.substring(0,4)) - 1980) << 9;        
            int month = (Integer.parseInt(date.substring(5,7))) << 5;        
            int day = Integer.parseInt(date.substring(8,10));        
            rtnStr = String.valueOf(year + month + day); 
        }
        catch(Exception e) {
            Log.e("ERROR", "ERROR: " + e.toString());
            e.printStackTrace();
        }                  
         return rtnStr;
    }    

} // End MemoEditActivity class