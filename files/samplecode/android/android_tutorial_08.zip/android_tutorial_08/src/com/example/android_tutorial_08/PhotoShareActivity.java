/**
 *  PhotoShareActivity.java
 *  Photo Share
 *
 *  Created by Nahoko Uwabe, Fixstars Corporation on 2013/09/23.
 * 
 *  Copyright (c) 2013, TOSHIBA CORPORATION
 *  All rights reserved.
 *  Released under the BSD 2-Clause license.
 *  http://flashair-developers.com/documents/license.html
 */
package com.example.android_tutorial_08;

import java.util.Locale;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.KeyEvent;


public class PhotoShareActivity extends Activity {

     ImageView imageView;
     Button backButton;
     TextView dateText;
     TextView currentDirText;
     String date;
     String rootDir = "DCIM";
     String directoryName;     
          
     @Override
     protected void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_photoshare);

          Bundle extrasData = getIntent().getExtras();
          date = extrasData.getString("date");
          directoryName = extrasData.getString("dir");
          
          // Set backButton
          backButton = (Button) findViewById(R.id.button1);
          backButton.getBackground().setColorFilter(Color.rgb(65, 183, 216), PorterDuff.Mode.SRC_IN);
          backButton.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   disablePhotoShare();
               }
          });          
          currentDirText = (TextView)findViewById(R.id.textView1);
          currentDirText.setText(directoryName);          
          dateText = (TextView) findViewById(R.id.textView2);
          dateText.setText(date);                        
      }     
     
     @Override
     public boolean onKeyDown(int keyCode, KeyEvent event) {
         if(keyCode == KeyEvent.KEYCODE_BACK){
             disablePhotoShare();
             return false;
         }else{
             return super.onKeyDown(keyCode, event);
         }
     }
     
     private void disablePhotoShare() {
         AlertDialog.Builder alertDialog=new AlertDialog.Builder(PhotoShareActivity.this);
         alertDialog.setTitle(R.string.app_name);
         alertDialog.setMessage("Do you disable PhotoShare?");
         // in case clicked OK
         alertDialog.setPositiveButton("OK",new DialogInterface.OnClickListener() {
             @Override
             public void onClick(DialogInterface dialog,int whichButton) {
                 new AsyncTask<String, Void, String>(){
                      @Override
                      protected String doInBackground(String... params) {          
                          return FlashAirRequest.getString(params[0]);     
                      }
                      @Override
                      protected void onPostExecute(String result) {
                          if(result.toUpperCase(Locale.getDefault()).equals("OK")) {                                  
                             Toast.makeText(PhotoShareActivity.this, "Disable completed.", Toast.LENGTH_LONG).show();
                             PhotoShareActivity.this.finish(); // Go back
                          }else{
                              Toast.makeText(PhotoShareActivity.this, "Disable failed.", Toast.LENGTH_LONG).show();     
                          }                              
                      }
                 }.execute("http://flashair/command.cgi?op=201");    
             }
         });
         // in case clicked Cancel
         alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
             @Override
             public void onClick(DialogInterface dialog,int whichButton) {
             }
         });
         alertDialog.setCancelable(false);
         alertDialog.create();
         alertDialog.show();
     }     
} // End PhotoShareActivity class
