//
//  FSViewController.m
//  DownloadContent
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/05/16.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import "FSViewController.h"

@interface FSViewController ()

@end

@implementation FSViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    [self getFileList:@"/DCIM"];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonPush:(id)sender {
    
    NSString *path = [self.labelDirectory.text substringToIndex:[self.labelDirectory.text length] - 1];
    NSRange found = [path rangeOfString:@"/" options:NSBackwardsSearch];
    
    if(found.location != NSNotFound){
        if (found.location == 0) {
            path = @"/";
        }else{
            path = [path substringToIndex:found.location];
        }
    }else{
        path = @"/";
    }
    
    // Reload tableview
    [self getFileList:path];
    [self.tableViewFileList reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.    
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    // Configure the cell...
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    FAItem *item = [files objectAtIndex:indexPath.row];
    NSString *filename = item.filename ;
    
    // If it is folder
    if (item.isDirectory) {
        filename = [filename stringByAppendingString:@"/" ];
        cell.imageView.image = nil;
    }else{
        NSArray *name_array = [filename componentsSeparatedByString:@"."];
        NSString *ext = [[name_array objectAtIndex:[name_array count]-1] lowercaseString];
        if (!([ext isEqualToString:@"jpg"] || [ext isEqualToString:@"jpeg"] ||
              [ext isEqualToString:@"png"] || [ext isEqualToString:@"jpe"])) {
            [cell setUserInteractionEnabled:NO];
        }else{
            // Get thumbnail
            NSError *error = nil;
            FAFlashAir *flashAir = [[FAFlashAir alloc] init];
            // Make a file path
            NSString *filePath = [[item.directory stringByAppendingString:@"/"] stringByAppendingString:filename];
            NSData *img_data = [flashAir getThumbnail:filePath error:&error];
            if(error){
                NSLog(@"getThumbnail %@\n",error);
            }else{
                // Display results
                cell.imageView.image = [[UIImage alloc] initWithData:img_data];
            }
        }
    }
    
    cell.textLabel.text = filename;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.    
    rowdata = [files objectAtIndex:indexPath.row];
    
    NSString *filePath = [[rowdata.directory stringByAppendingString:@"/"] stringByAppendingString:rowdata.filename];
    
    // If it is folder
    if(rowdata.isDirectory){
        [self getFileList:filePath];
        [self.tableViewFileList reloadData];
    }else{
        [self performSegueWithIdentifier:@"imageView" sender:self];
    }
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Give next View the Data
    if ([segue.identifier isEqualToString:@"imageView"]) {
        FSImageViewController *iamgeViewController = segue.destinationViewController;
        iamgeViewController.fileInfo = rowdata;
    }
}

- (void)getFileList:(NSString *)path{
    
    NSError *error = nil;
    FAFlashAir *flashAir = [[FAFlashAir alloc] init];
    
    // Get file list
    files = [flashAir getFileListWithDirectory:path error:&error];
    if (error){
        NSLog(@"getFileListWithDirectory %@\n",error);
        return;
    }

    // Get the number of files
    int cnt = [flashAir getFileCountWithDirectory:path error:&error];
    if (error) {
        NSLog(@"getFileCountWithDirectory %@\n",error);
        return;
    }
    count = cnt;
    
    // Display results
    self.labelCount.text =[@"Items Found:" stringByAppendingString:[NSString stringWithFormat:@"%d",count]];
    if(![path isEqualToString:@"/"]){
        self.labelDirectory.text = [path stringByAppendingString:@"/" ];
    }else{
        self.labelDirectory.text = @"/";
    }
    
}

@end
