//
//  FSImageViewController.m
//  DownloadContent
//
//  Created by Nahoko Uwabe, Fixstars Corporation on 2013/05/30.
//
//  Copyright (c) 2013, TOSHIBA CORPORATION
//  All rights reserved.
//  Released under the BSD 2-Clause license.
//  http://flashair-developers.com/documents/license.html
//

#import "FSImageViewController.h"

@interface FSImageViewController ()

@end

@implementation FSImageViewController

@synthesize fileInfo = _fileInfo;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Get image data
    NSError *error = nil;
    FAFlashAir *flashAir = [[FAFlashAir alloc] init];
    // Make a file path
    NSString *filePath = [[self.fileInfo.directory stringByAppendingString:@"/"] stringByAppendingString:self.fileInfo.filename];
    NSData *img_data = [flashAir getFile:filePath error:&error];
    if(error){
        NSLog(@"getFile %@\n",error);
    }else{
        UIImage *img = [[UIImage alloc] initWithData:img_data];
        // Display result
        self.imageView.image = img;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
