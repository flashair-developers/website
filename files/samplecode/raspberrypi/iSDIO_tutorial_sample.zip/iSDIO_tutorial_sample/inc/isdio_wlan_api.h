// *******************************************************
//   COPYRIGHT(C) 2017
//   Toshiba Development & Engineering Corporation
//   ALL RIGHTS RESERVED
// *******************************************************
/**
 * @file	isdio_wlan_api.h
 * @brief	iSDIO(FlashAir)用ヘッダファイル
 *
 * @see
 *   Part E7 Wireless LAN Simplified Addendum Version 1.10 March 25, 2014
 */

#ifndef INC_ISDIO_FLASHAIR_API_H_
#define INC_ISDIO_FLASHAIR_API_H_

#include "../inc/isdio_api.h"

/**
 * @name iSDIO(Wireless LAN)コマンドID
 * @{
 */
#define iSDIO_WLAN_SCAN								(0x0001)	//!< Scan()
#define iSDIO_WLAN_CONNECT								(0x0002)	//!< Connect(ssid, networkKey)
#define iSDIO_WLAN_ESTABLISH							(0x0003)	//!< Establish(ssid, networkKey, encMode)
#define iSDIO_WLAN_WIFI_DIRECT							(0x0004)	//!< WiFiDirect(wpsMode, pin)
#define iSDIO_WLAN_START_WPS							(0x0005)	//!< StartWPS(ssid, wpsMode, pin)
#define iSDIO_WLAN_START_WPSAP							(0x0006)	//!< StartWPSAP(wpsMode, pin)
#define iSDIO_WLAN_DISCONNECT							(0x0007)	//!< Disconnect()
#define iSDIO_WLAN_SET_CURRENT_TIME					(0x0011)	//!< SetCurrentTime(currentDate, currentTime)
#define iSDIO_WLAN_ABORT								(0x0012)	//!< Abort(sequenceID) Mandatory Mandatory Mandatory
#define iSDIO_WLAN_READ_RESPONSE						(0x0013)	//!< ReadResponse(sequenceID) Mandatory Mandatory Mandatory
#define iSDIO_WLAN_SET_POWER_SAVE_MODE					(0x0014)	//!< SetPowerSaveMode(powerMode) Mandatory Mandatory Mandatory
#define iSDIO_WLAN_SET_CHANNEL							(0x0015)	//!< SetChannel(channelNum) Mandatory Optional Optional *1
#define iSDIO_WLAN_SEND_HTTP_MESSAGE_BY_REGISTER		(0x0021)	//!< SendHTTPMessageByRegister(hostName, message)
#define iSDIO_WLAN_SEND_HTTP_FILE_BY_REGISTER			(0x0022)	//!< SendHTTPFileByRegister(hostName, appendFileName, message)
#define iSDIO_WLAN_SEND_HTTP_SSL_MESSAGE_BY_REGISTER	(0x0023)	//!< SendHTTPSSLMessageByRegister(hostName, message)
#define iSDIO_WLAN_SEND_HTTP_SSL_FILE_BY_REGISTER		(0x0024)	//!< SendHTTPSSLFileByRegister(hostName, appendFileName, message)
#define iSDIO_WLAN_SEND_HTTP_MESSAGE_BY_FILE			(0x0025)	//!< SendHTTPMessageByFile (hostName, messageFileName, headerRemoval)
#define iSDIO_WLAN_SEND_HTTP_FILE_BY_FILE				(0x0026)	//!< SendHTTPFileByFile (hostName, messageFileName, appendFileName, headerRemoval)
#define iSDIO_WLAN_SEND_HTTP_SSL_MESSAGE_BY_FILE		(0x0027)	//!< SendHTTPSSLMessageByFile (hostName, messageFileName, headerRemoval)
#define iSDIO_WLAN_SEND_HTTP_SSL_FILE_BY_FILE			(0x0028)	//!< SendHTTPSSLFileByFile (hostName, messageFileName, appendFileName, headerRemoval)
#define iSDIO_WLAN_SET_CERTIFICATION					(0x0029)	//!< SetCertificate(certificate) Mandatory Mandatory Mandatory
#define iSDIO_WLAN_SET_CERTIFICATE_BY_FILE				(0x002A)	//!< SetCertificateByFile(certificateFileName)
#define iSDIO_WLAN_START_P2P_SENDER					(0x0081)	//!< StartP2PSender(ssid, ntwk_key, encMode)
#define iSDIO_WLAN_START_P2P_RECEIVER					(0x0082)	//!< StartP2PReceiver(ssid, ntwk_key)
#define iSDIO_WLAN_GET_FILE							(0x0083)	//!< GetFile(requestFileName, saveFileName)
#define iSDIO_WLAN_READ_ID_LIST						(0x0084)	//!< ReadIDList()
#define iSDIO_WLAN_SELECT_MAC							(0x0085)	//!< SelectMAC(mac)
#define iSDIO_WLAN_DESELECT_MAC						(0x0086)	//!< DeselectMAC(mac)
#define iSDIO_WLAN_SET_ID								(0x0087)	//!< SetID(id)
/**
 * @}
 */

/**
 * @name Shared Memory情報
 * @{
 */
#define iSDIO_WLAN_SHAREDMEMORY_START_ADDR			(0x1000)	//!< Shared Memory先頭アドレス
#define iSDIO_WLAN_SHAREDMEMORY_SIZE_W03			(0x200)		//!< Shared Memoryサイズ（512byte）
#define iSDIO_WLAN_SHAREDMEMORY_SIZE_W04			(0x800)		//!< Shared Memoryサイズ（2kbyte）
/**
 * @}
 */

/**
 * @name CIDによるカード情報
 * @{
 */
#define CID_PNM_FLASHAIR			"5357"					//!< PNMの"SW"の部分
#define CID_PNM_CARD_SIZE_08G		"303847"				//!< 8GのPNM
#define CID_PNM_CARD_SIZE_16G		"313647"				//!< 16GのPNM
#define CID_PNM_CARD_SIZE_32G		"333247"				//!< 32GのPNM
#define CID_PNM_CARD_SIZE_64G		"363447"				//!< 64GのPNM
#define CID_PRV_W02_8G16G32G		"08"					//!< W02、8G、16G、32GのPRV
#define CID_PRV_W03_8G				"48"					//!< W03、8GのPRV
#define CID_PRV_W03_16G32G			"40"					//!< W03、16G、32GのPRV
#define CID_PRV_W04_16G			"54"					//!< W04、16GのPRV
#define CID_PRV_W04_32G64G			"55"					//!< W04、32G、64GのPRV

#define CID_PNM_FLASHAIR_POS		(6)						//!< CIDのPNMの開始位置
#define CID_PNM_FLASHAIR_SIZE		(4)						//!< ManufactureIDのサイズ
#define CID_PNM_CARD_SIZE_POS		(10)					//!< CIDのPNMのカードサイズ開始位置
#define CID_PNM_CARD_SIZE_SIZE		(6)						//!< PNMのサイズ
#define CID_PRV_POS				(16)					//!< CIDのPRVの開始位置
#define CID_PRV_SIZE				(2)						//!< PRVのサイズ

#define CID_CARD_SIZE_8G			(8)						//!< カード容量8G
#define CID_CARD_SIZE_16G			(16)					//!< カード容量16G
#define CID_CARD_SIZE_32G			(32)					//!< カード容量32G
#define CID_CARD_SIZE_64G			(64)					//!< カード容量64G
#define CID_CARD_SIZE_UNKNOWN		(0)						//!< カード容量が不明
#define CID_CARDVERSION_W02		(2)						//!< FlashAir W02
#define CID_CARDVERSION_W03		(3)						//!< FlashAir W03
#define CID_CARDVERSION_W04		(4)						//!< FlashAir W04
#define CID_CARDVERSION_UNKNOWN	(255)					//!< FlashAirのバージョンが不明
#define CID_NOT_FLASHAIR			(0)						//!< FlashAirではない
/**
 * @}
 */

/**
 * 無線LAN SSID情報
 */
typedef struct iSDIO_WLAN_SSIDListItem_s {
	uint8_t		ssid[32];							//!< SSID
	uint8_t		mac_address[6];						//!< MACアドレス
	uint8_t		signal_strength;					//!< シグナル強度
	uint8_t		encryption_mode;					//!< 暗号モード
	uint8_t		reserved[4];						//!< 予約
} iSDIO_WLAN_SSIDListItem_t;

/**
 * 無線LAN SSID List
 */
typedef struct iSDIO_WLAN_SSIDList_s {
	uint8_t		ssid_num;							//!< SSIDの数
	uint8_t		reserved[3];						//!< 予約
	iSDIO_WLAN_SSIDListItem_t	items[(iSDIO_BUF_SIZE - 4) / sizeof(iSDIO_WLAN_SSIDListItem_t)];
													//!< 無線LAN SSID情報のリスト
} iSDIO_WLAN_SSIDList_t;

/**
 * 無線LAN ID情報(iSDIO_WLAN_ReadIDList用)
 */
typedef struct iSDIO_WLAN_IDInfo_s {
	uint8_t		id[16];								//!< 受信カードのID
	uint8_t		mac_address[6];						//!< MACアドレス
	uint8_t		permission;							//!< パーミッション
	uint8_t		reserved;							//!< 予約
} iSDIO_WLAN_IDInfo_t;

/**
 * 無線LAN ID List(iSDIO_WLAN_ReadIDList用)
 */
typedef struct iSDIO_WLAN_IDList_s {
	uint8_t 	id_num;								//!< 受信カード IDリストの数
	uint8_t		reserved[3];						//!< 予約
	iSDIO_WLAN_IDInfo_t		receiver[];				//!< 受信カードID情報
} iSDIO_WLAN_IDList_t;

/**
 * WPS List
 */
typedef struct iSDIO_WLAN_WPSList_s {
	char ssid[32];									//!< アクセスポイントのSSID
	char ntwk_key[64];								//!< アクセスポイントのネットワークキー
} iSDIO_WLAN_WPSList_t;

/**
 * 暗号モード
 */
typedef enum iSDIO_WLAN_EcnMode_e {
	iSDIO_WLAN_ENCMODE_NO_ENCRYPTION = 0x00,			//!< 暗号化なし
	iSDIO_WLAN_ENCMODE_OPEN_SYSTEM_AND_WEP	= 0x01,		//!< Open System and WEP
	iSDIO_WLAN_ENCMODE_SHARED_KEY_AND_WEP = 0x02,		//!< Shared Key and WEP
	iSDIO_WLAN_ENCMODE_WPA_PSK_AND_TKIP = 0x03,			//!< WPA-PSK and TKIP
	iSDIO_WLAN_ENCMODE_WPA_PSK_AND_AES = 0x04,			//!< WPA-PSK and AES
	iSDIO_WLAN_ENCMODE_WPA2_PSK_AND_TKIP = 0x05,		//!< WPA2-PSK and TKIP
	iSDIO_WLAN_ENCMODE_WPA2_PSK_AND_AES = 0x06			//!< WPA2-PSK and AES
} iSDIO_WLAN_EcnMode_t;

/**
 * WPSモード
 */
typedef enum iSDIO_WLAN_WPSMode_e {
	iSDIO_WLAN_WPSMODE_WITH_PIN = 0x01,					//!< WPS with PIN
	iSDIO_WLAN_WPSMODE_WITH_PBC = 0x02					//!< WPS with PBX
} iSDIO_WLAN_WPSMode_t;

/**
 * 日付
 */
typedef struct iSDIO_WLAN_Date_s {
	uint16_t day:5;											//!< 日
	uint16_t month:4;										//!< 月
	uint16_t year:7;										//!< 年(1980年からの経過年)
} iSDIO_WLAN_Date_t;

/**
 * 時間
 */
typedef struct iSDIO_WLAN_Time_s {
	uint16_t second:5;										//!< 秒
	uint16_t minute:6;										//!< 分
	uint16_t hour:5;										//!< 時
} iSDIO_WLAN_Time_t;

/**
 * パワーセーブモード
 */
typedef enum iSDIO_WLAN_PowerMode_e {
	iSDIO_WLAN_POWERMODE_OFF = 0x00,					//!< パワーセーブモードOFF
	iSDIO_WLAN_POWERMODE_ON = 0x01						//!< パワーセーブモードON
} iSDIO_WLAN_PowerMode_t;

/**
 * ヘッダ付加情報
 */
typedef enum iSDIO_WLAN_HeaderRemoval_e {
	iSDIO_WLAN_WITH_HEADER = 0x00,					//!< HTTPヘッダ有り
	iSDIO_WLAN_ONLY_BODY = 0x01						//!< BODYのみ(HTTPヘッダ無し)
} iSDIO_WLAN_HeaderRemoval_t;

/*--- 外部関数定義 ---*/

 // 接続可能な無線LANの探索
extern int32_t iSDIO_WLAN_Scan(
		iSDIO_INFO_t *info, uint32_t seq_id);

// ステーションとしての無線LANの接続
extern int32_t iSDIO_WLAN_Connect(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *ssid, uint16_t ssid_size,
		uint8_t *ntwk_key, uint32_t ntwk_key_size);

// アクセスポイントとしての無線LAN接続の確立
extern int32_t iSDIO_WLAN_Establish(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *ssid, uint32_t ssid_size,
		uint8_t *ntwk_key, uint32_t ntwk_key_size,
		iSDIO_WLAN_EcnMode_t encMode);

// WiFiダイレクト接続
extern int32_t iSDIO_WLAN_WiFiDirect(
		iSDIO_INFO_t *info, uint32_t seq_id,
		iSDIO_WLAN_WPSMode_t wpsMode,
		uint8_t *pin, uint32_t pin_size);

// ステーションとしてのWPSによる無線LAN接続設定の開始
extern int32_t iSDIO_WLAN_StartWPS(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *ssid, uint32_t ssid_size,
		iSDIO_WLAN_WPSMode_t wpsMode,
		uint8_t *pin, uint32_t pin_size);

// アクセスポイントとしてのWPSによる無線LAN接続設定の開始
extern int32_t iSDIO_WLAN_StartWPSAP(
		iSDIO_INFO_t *info, uint32_t seq_id,
		iSDIO_WLAN_WPSMode_t wpsMode,
		uint8_t *pin, uint32_t pin_size);

// 無線LANの切断
extern int32_t iSDIO_WLAN_Disconnect(
		iSDIO_INFO_t *info, uint32_t seq_id);

// カードの日時設定
extern int32_t iSDIO_WLAN_SetCurrentTime(
		iSDIO_INFO_t *info, uint32_t seq_id,
		iSDIO_WLAN_Date_t currentDate,
		iSDIO_WLAN_Time_t currentTime);

// iSDIOコマンド実行プロセスの中断
extern int32_t iSDIO_WLAN_Abort(
		iSDIO_INFO_t *info, uint32_t seq_id,
        uint32_t abort_seq_id);

// レスポンスデータ読み込み
extern int32_t iSDIO_WLAN_ReadResponse(
		iSDIO_INFO_t *info, uint32_t seq_id,
        uint32_t read_seq_id);

// パワーセーブモードの設定
extern int32_t iSDIO_WLAN_SetPowerSaveMode(
		iSDIO_INFO_t *info, uint32_t seq_id,
		iSDIO_WLAN_PowerMode_t powerMode);

// アクセスポイントのチャネル番号の設定
extern int32_t iSDIO_WLAN_SetCannel(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t ch);

// HTTPメッセージの送信
extern int32_t iSDIO_WLAN_SendHTTPMessageByRegister(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *message, uint32_t message_size);

// 添付ファイル付きHTTPメッセージの送信
extern int32_t iSDIO_WLAN_SendHTTPFileByRegister(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *filename, uint32_t filename_size,
		uint8_t *message, uint32_t message_size);

// HTTPメッセージの送信(SSL)
extern int32_t iSDIO_WLAN_SendHTTPSSLMessageByRegister(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *message, uint32_t message_size);

// 添付ファイル付きHTTPメッセージの送信(SSL)
extern int32_t iSDIO_WLAN_SendHTTPSSLFileByRegister(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *filename, uint32_t filename_size,
		uint8_t *message, uint32_t message_size);

// HTTPメッセージ(ファイル)の送信
extern int32_t iSDIO_WLAN_SendHTTPMessageByFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *msg_filename, uint32_t msg_filename_size,
		iSDIO_WLAN_HeaderRemoval_t headerRemoval);

// 添付ファイル付きHTTPメッセージ(ファイル)の送信
extern int32_t iSDIO_WLAN_SendHTTPFileByFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *msg_filename, uint32_t msg_filename_size,
		uint8_t *apnd_filename, uint32_t apnd_filename_size,
		iSDIO_WLAN_HeaderRemoval_t headerRemoval);

// HTTPメッセージ(ファイル)の送信(SSL)
extern int32_t iSDIO_WLAN_SendHTTPSSLMessageByFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *msg_filename, uint32_t msg_filename_size,
		iSDIO_WLAN_HeaderRemoval_t headerRemoval);

// 添付ファイル付きHTTPメッセージ(ファイル)の送信(SSL)
extern int32_t iSDIO_WLAN_SendHTTPSSLFileByFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *msg_filename, uint32_t msg_filename_size,
		uint8_t *apnd_filename, uint32_t apnd_filename_size,
		iSDIO_WLAN_HeaderRemoval_t headerRemoval);

// HTTPS接続用ルート証明書の設定
extern int32_t iSDIO_WLAN_SetCertificate(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *certificate, uint32_t certificate_size);

// HTTPS接続用ルート証明書(ファイル)の設定
extern int32_t iSDIO_WLAN_SetCertificateByFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *filename, uint32_t filename_size);

// 送信側としてのP2Pによる無線LAN接続の開始
extern int32_t iSDIO_WLAN_StartP2PSender(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *ssid, uint32_t ssid_size,
		uint8_t *ntwk_key, uint32_t ntwk_key_size,
		iSDIO_WLAN_EcnMode_t encMode);

// 受信側としてのP2Pによる無線LAN接続の開始
extern int32_t iSDIO_WLAN_StartP2PReceiver(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *ssid, uint32_t ssid_size,
		uint8_t *ntwk_key, uint32_t ntwk_key_size);

// P2Pによるファイルの取得(受信側用)
extern int32_t iSDIO_WLAN_GetFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *req_filename, uint32_t req_filename_size,
		uint8_t *save_filename, uint32_t save_filename_size);

// P2Pにおける無線LAN IDリストの取得(送信側用)
extern int32_t iSDIO_WLAN_ReadIDList(
		iSDIO_INFO_t *info, uint32_t seq_id);

// P2Pにおける受信側のMACアドレスの選択(送信側用)
extern int32_t iSDIO_WLAN_SelectMAC(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *mac);

// P2Pにおける受信側のMACアドレスの指定解除(送信側用)
extern int32_t iSDIO_WLAN_DeselectMAC(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *mac);

// P2Pにおける受信側の無線LAN IDの設定(受信側用)
extern int32_t iSDIO_WLAN_SetID(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *id, uint32_t id_size);

// SharedMemory書き込み
extern int32_t iSDIO_WLAN_WriteSharedMemory(
		iSDIO_INFO_t *info, uint32_t addr,
		uint32_t len, uint8_t *buf);

// SharedMemory読み出し
extern int32_t iSDIO_WLAN_ReadSharedMemory(
		iSDIO_INFO_t *info, uint32_t addr,
		uint32_t len, uint8_t *buf);

// CIDからFlashAirのバージョンと容量確認
int32_t iSDIO_WLAN_GetFlashAirVersion(iSDIO_INFO_t *info, uint8_t *cardver, uint16_t *cardsize);

/* NSW add 2017.09.22 start */
/**
 * Bridge情報

 */
typedef struct iSDIO_WLAN_BridgeListItem_s {
	uint32_t		status;
	uint8_t		appssid[32+4];							//!< SSID
	uint8_t		appnetworkKey[64+4];
	uint8_t		ipaddr[4];
	uint8_t		subnetMask[4];
	uint8_t		defGateWay[4];
	uint8_t		prefDnsServer[4];
	uint8_t		altDnsServer[4];
	uint8_t		brgssid[32+4];
	uint8_t		brgnetworkKey[64+4];
	uint8_t		brgIpaddr[4];
	uint8_t		brgsunetMask[4];
	uint8_t		brgdefGateWay[4];
	uint8_t		brgprefDnsServer[4];
	uint8_t		brgaltDnsServer[4];
} iSDIO_WLAN_BridgeListItem_t;
/**
 * @name VenderコマンドID
 * @{
 */
#define iSDIO_WLAN_BRIDGE							(0xE200)	//!< Bridge(apssid, apnetworkKey, encMode, brgssid, brgnetworkKey)
#define iSDIO_WLAN_BRIDGE_GET_INFO_BY_REGISTER		(0xE201)	//!< BridgeGetInfoByRegister()
/**
 * @}
 */

/**
 * WLAN接続状態
 */
typedef enum iSDIO_WLAN_Connect_e {
	iSDIO_WLAN_NO_CONNECTION = 0x00,				//!< WLAN未接続状態
	iSDIO_WLAN_CONNECTED = 0x01						//!< WLAN接続状態
} iSDIO_WLAN_Connect_t;
/**
 * @}
 */

/**
 * WLAN ON/OFF状態
 */
typedef enum iSDIO_WLAN_OnOFF_e {
	iSDIO_WLAN_OFF = 0x00,						//!< WLAN OFF状態
	iSDIO_WLAN_ON = 0x01						//!< WLAN ON状態
} iSDIO_WLAN_OnOFF_t;
/**
 * @}
 */

/**
 * HTTP  TYPE
 */
typedef enum iSDIO_WLAN_httpType_e {
	iSDIO_WLAN_HTTP = 0x00,				//!< HTTP
	iSDIO_WLAN_HTTPSSL = 0x01			//!< HTTP SSL
} iSDIO_WLAN_httpType_t;
/**
 * @}
 */
/**
 * HTTP MESSAGE TYPE
 */
typedef enum iSDIO_WLAN_MessageType_e {
	iSDIO_WLAN_MSG_REGISTER = 0x00,				//!< RegisterからのHTTPメッセージ
	iSDIO_WLAN_MSG_FILE = 0x01					//!< FileからのHTTPメッセージ
} iSDIO_WLAN_MessageType_t;
/**
 * @}
 */


//HTTPメッセージ送信
extern int32_t iSDIO_WLAN_Request(
	iSDIO_INFO_t *info,uint32_t seq_id, 
	iSDIO_WLAN_httpType_t host_type,
	uint8_t *hostname, uint32_t hostname_size, 
	iSDIO_WLAN_MessageType_t msg_type,
	uint8_t *message, uint32_t message_size, 
	uint8_t *apnd_filename, uint32_t apnd_filename_size, 
	iSDIO_WLAN_HeaderRemoval_t headerRemova);

//ブリッジモードを起動
extern int32_t iSDIO_WLAN_Bridge(
	iSDIO_INFO_t *info, uint32_t seq_id, 
	uint8_t *apssid, uint32_t apssid_size,
	uint8_t *apnetworkKey, uint32_t apnetworkKey_size,
	iSDIO_WLAN_EcnMode_t encMode, 
	uint8_t *brgssid, uint32_t brgssid_size,
	uint8_t *brgnetworkKey, uint32_t brgnetworkKey_size);

//ブリッジモード情報を取得
extern int32_t iSDIO_WLAN_BridgeGetInfoByRegister(iSDIO_INFO_t *info, uint32_t seq_id);

// Scan後のSSID数の取得
extern int32_t iSDIO_WLAN_GetSSIDs(
		iSDIO_INFO_t *info, uint8_t *num);
//extern int32_t iSDIO_WLAN_GetSSIDs(iSDIO_INFO_t *info, uint32_t seq_id, uint8 *num);

//アクセスポイント名を取得
//extern int32_t iSDIO_WLAN_GetSSID(iSDIO_INFO_t *info, uint32_t seq_id, uint8 number , uint8 *ssid);
extern int32_t iSDIO_WLAN_GetSSID(iSDIO_INFO_t *info, uint8_t number , uint8_t *ssid);

//Status Registerの出力データを取得
extern int32_t iSDIO_WLAN_GetStatusData(iSDIO_INFO_t *info, uint8_t *getbuf);

//Response Data Register Portの出力データを取得
extern int32_t iSDIO_WLAN_GetResponseData(iSDIO_INFO_t *info, uint8_t *getbuf);

//バージョン情報を取得
extern int32_t iSDIO_WLAN_GetVersion(iSDIO_INFO_t *info, uint8_t *getbuf);

//FA_Api_WaitResponseの待機時間を設定
void iSDIO_WLAN_SetWaitResponseTime(uint32_t time);

//WLAN接続をチェック
extern int32_t iSDIO_WLAN_Check_WLANConnect(iSDIO_INFO_t *info, iSDIO_WLAN_Connect_t *connect);

//WLAN On/Off状態をチェック
extern int32_t iSDIO_WLAN_Check_WLAN(iSDIO_INFO_t *info, iSDIO_WLAN_OnOFF_t *onoff);

//Status Register “WLAN”データを取得
extern int32_t iSDIO_WLAN_Get_WLAN_Status(iSDIO_INFO_t *info, uint8_t *para);

/* NSW add 2017.09.22 end */

#endif /* INC_ISDIO_WLAN_API_H_ */
