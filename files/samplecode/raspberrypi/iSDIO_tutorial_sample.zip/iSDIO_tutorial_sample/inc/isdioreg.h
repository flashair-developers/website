#ifndef __ISDIOREG_H__
#define __ISDIOREG_H__

#include <linux/types.h>
#include <linux/mmc/ioctl.h>

#define iSDIOREG_COMMAND_WRITE_REGISTER_PORT_ADDRESS	(0x00000)	//!< Command Write Register Port
#define iSDIOREG_RESPONSE_DATA_REGISTER_ADDRESS		(0x00200)	//!< Response Data Register Port

#define E_SD_iSDIOREG_OK			(0x00000000)		//!< 正常終了
#define E_SD_iSDIOREG_ERR_PARAM 	(0x00000001)		//!< パラメータエラー
#define E_SD_iSDIOREG_ERR_DEVICE	(0x00000002)		//!< ハードウェアデバイスのエラー
#define E_SD_iSDIOREG_ERR_TIMEOUT	(0x00000003)		//!< タイムアウトエラー

extern int iSDIOREG_read_ext_reg(int fd, __u8 fno, __u32 ext_address, __u8 *pdata, __u32 block_num, __u32 len);
extern int iSDIOREG_write_ext_reg(int fd, __u8 fno, __u32 ext_address, const __u8 *pdata, __u32 block_num, __u32 len);
extern int iSDIOREG_open_ext_reg(char *devname);
extern void iSDIOREG_close_ext_reg(int fd);

#endif //__ISDIOREG_H__
