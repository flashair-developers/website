// *******************************************************
//   COPYRIGHT(C) 2017
//   Toshiba Development & Engineering Corporation
//   ALL RIGHTS RESERVED
// *******************************************************
/**
 * @file	isdio_api.h
 * @brief	iSDIO APIヘッダファイル
 *
 * @see
 *   Part E7 iSDIO Simplified Specification Version 1.10 March 25, 2014
 */

#ifndef INC_ISDIO_API_H_
#define INC_ISDIO_API_H_

#include <stdbool.h>
#include "../inc/isdioreg.h"

/**
 * @name iSDIOドライバの定義
 * @{
 */
#define iSDIO_CARD_MAX_NUM					(1)				//!< SDカードスロット数=1
#define iSDIO_BUF_SIZE						(2048)			//!< iSDIO用テンポラリバッファサイズ
#define SD_HCXC_BLOCK_SIZE					(512)			//!< SDのブロックサイズ
/**
 * @}
 */

/**
 * @name bool_tの定義
 * @{
 */
typedef bool bool_t;
#define TRUE true
#define FALSE false
/**
 * @}
 */

/**
 * @name iSDIO Register Map
 * @{
 */
#define iSDIO_COMMAND_WRITE_REGISTER_PORT_ADDRESS	(0x00000)	//!< Command Write Register Port
#define iSDIO_RESPONSE_DATA_REGISTER_ADDRESS		(0x00200)	//!< Response Data Register Port
#define iSDIO_STATUS_REGISTER_ADDRESS				(0x00400)	//!< Status Register
#define iSDIO_COMMAND_RESPONSE_STATUS_QUEUE		(0x00440)	//!< Command Response Status Queue
#define iSDIO_CAPABILITY_REGISTER_ADDRESS			(0x00600)	//!< Capability Register
/**
 * @}
 */

/**
 * Command Response Status
 */
typedef struct iSDIO_CommandResponseStatus_s {
	uint8_t		status_registration;							//!< Denotes the command status registration
	uint8_t		reserved_1;										//!< Reserved
	uint16_t	cmd_id;											//!< Command id corresponding to one in Command Write Data.
	uint32_t	seq_id;											//!< Command sequence id corresponding to one in Command Data.
	uint8_t		response_status;								//!< Denotes the status of a specified command processing
	uint8_t		reserved_2[3];									//!< Reserved
	uint32_t	vender_error_status;							//!< This field is reserved for vendor error status
	uint32_t	resp_data_size;									//!< Denotes the size in bytes of the Response Data
} iSDIO_CommandResponseStatus_t;

/**
 * iSDIO Status Register Map
 */
typedef struct iSDIO_StatusRegisterMap_s {
	uint8_t	cmd_write_status;									//!< 0x0400: Command Write Status
	uint8_t reserved_1[0x1F];									//!< 0x0401-0x041F: Reserved
	uint16_t isdio_status;										//!< 0x0420-0x0421: iSDIO Status
	uint16_t isdio_int_status;									//!< 0x0422-0x0423: iSDIO Int Enable
	uint16_t err_status;										//!< 0x0424-0x0425: Error Status
	uint16_t mem_status;										//!< 0x0426-0x0427: Memory Status
	uint8_t reserved_2[0x18];									//!< 0x0428-0x043F: Reserved
	iSDIO_CommandResponseStatus_t cmd_resp_status_queue[8];		//!< 0x0440-0x04DF: Command Response Status Queue
	uint8_t reserved_3[0x20];									//!< 0x04E0-0x04FF: Reserved
	uint8_t app_status[0x100];									//!< 0x0500-0x05FF: Application Status
} iSDIO_StatusRegister_t;

/**
 * @name Command Write Status
 * @{
 */
#define iSDIO_COMMAND_WRITE_STATUS_CWU		(1 << 0)			//!< Command Write Update
#define iSDIO_COMMAND_WRITE_STATUS_CWA		(1 << 1)			//!< Command Write Abort
/**
 * @}
 */

/**
 * @name iSDIO Status
 * @{
 */
#define iSDIO_ISDIO_STATUS_CRU				(1 << 0)			//!< Command Response Update
#define iSDIO_ISDIO_STATUS_ESU				(1 << 1)			//!< Error Status Update
#define iSDIO_ISDIO_STATUS_MCU				(1 << 2)			//!< Media Change Update
#define iSDIO_ISDIO_STATUS_ASU				(1 << 3)			//!< Application Status Update
/**
 * @}
 */

/**
 * @name iSDIO Int Enable
 * @{
 */
#define iSDIO_ISDIO_STATUS_CRU_ENA			(1 << 0)			//!< CRU Interrupt Enable
#define iSDIO_ISDIO_STATUS_ESU_ENA			(1 << 1)			//!< ESU Interrupt Enable
#define iSDIO_ISDIO_STATUS_MCU_ENA			(1 << 2)			//!< MCU Interrupt Enable
#define iSDIO_ISDIO_STATUS_ASU_ENA			(1 << 3)			//!< ASU Interrupt Enable
/**
 * @}
 */

/**
 * @name Error Status
 * @{
 */
#define iSDIO_ERROR_STATUS_CRE				(1 << 0)			//!< Command Response Error
#define iSDIO_ERROR_STATUS_CWE				(1 << 1)			//!< Command Write Error
#define iSDIO_ERROR_STATUS_RRE				(1 << 2)			//!< Response Receive Error
#define iSDIO_ERROR_STATUS_APE				(1 << 3)			//!< Application Specific Error
/**
 * @}
 */

/**
 * @name Memory Status
 * @{
 */
#define iSDIO_MEMORY_STATUS_MEX			(1 << 0)			//!< Memory Existence
#define iSDIO_MEMORY_STATUS_FAT			(1 << 1)			//!< FAT System
/**
 * @}
 */

/**
 * @name Status Registration
 * @{
 */
#define iSDIO_STATUS_REGSITRATION_NOT_REGISTERED	(0x00)		//!< Not Registered (Default)
#define iSDIO_STATUS_REGSITRATION_REGISTERED		(0x01)		//!< Registered
/**
 * @}
 */

/**
 * @name Response Status
 * @{
 */
#define iSDIO_INITIAL								(0x00)		//!< Initial (Default)
#define iSDIO_COMMAND_PROCESSING					(0x01)		//!< Command Processing
#define iSDIO_COMMAND_REJECTED						(0x02)		//!< Command Rejected
#define iSDIO_PROCESS_SUCCEEDED					(0x03)		//!< Process Succeeded
#define iSDIO_PROCESS_TERMINATED					(0x04)		//!< Process Terminated
#define iSDIO_GENERAL_ERROR						(0x80)		//!< General Error
#define iSDIO_ARGUMENT_ERROR						(0x81)		//!< Argument Error
#define iSDIO_NETWORK_ERROR						(0x82)		//!< Network Error
#define iSDIO_FILE_SYSTEM_ERROR					(0x83)		//!< File System Error
#define iSDIO_BUFFER_OVERFLOW_ERROR				(0x84)		//!< Buffer Overflow Error
/**
 * @}
 */

/**
 * @name エラーコード
 * @{
 */
#define E_iSDIO_OK									(0)			//!< 正常終了
#define E_iSDIO_INVALID_PARAM          			(-1)		//!< 不正パラメータ
#define E_iSDIO_CMD_BUF_OVERFLOW    				(-2)		//!< コマンドバッファ不足
#define E_iSDIO_TIMEOUT		    				(-3)		//!< タイムアウト発生
#define E_iSDIO_DEVICE_ERROR						(-4)		//!< デバイスエラー
#define E_iSDIO_UNKNOWN_ERROR						(-5)		//!< 不明なエラー
/**
 * @}
 */

/**
 * iSDIO Command Write Data
 */
typedef struct iSDIO_CommandWriteDataHeader_s {
	uint8_t		iSDIO_command_write_identifier;					//!< iSDIO Command Write Identifier
	uint8_t		number_of_iSDIO_commands;						//!< Number of iSDIO commands
	uint16_t	reserved_1;										//!< Reserved
	uint32_t	size_of_iSDIO_command_write_data;				//!< Size of iSDIO Command Write Data
	uint32_t	reserved_2;										//!< Reserved
} iSDIO_CommandWriteDataHeader_t;

/**
 * iSDIO Command Information in Command Write Data
 */
typedef struct iSDIO_CommandInformationHeader_s {
	uint16_t	reserved_1;										//!< Reserved
	uint16_t	iSDIO_command_id;								//!< Command ID
	uint32_t	iSDIO_command_sequence_id;						//!< Sequence ID to distinguish from other issued commands.
	uint16_t	number_of_arguments;							//!< Number of Argument for the command
	uint16_t	reserved_2;										//!< Reserved

} iSDIO_CommandInformationHeader_t;

/**
 * iSDIO Command Response Data
 */
typedef struct iSDIO_CommandResponseDataHeader_s {
	uint8_t		cmd_resp_id;						//!< iSDIO Command Response Identifier(0x02)
	uint8_t		reserved_1[3];						//!< Reserved
	uint32_t	cmd_resp_data_size;					//!< Size of iSDIO Command Response Data
	uint8_t		reserved_2[6];						//!< Reserved
	uint16_t	cmd_id;								//!< Command id corresponding to the one in Command Write Register.
	uint32_t	seq_id;								//!< Command sequence id corresponding to the one in Command Write Register.
	uint32_t	resp_data_size;						//!< Size of Response Data
} iSDIO_CommandResponseDataHeader_t;

/**
 * Capability Register
 */
typedef struct iSDIO_CapabilityRegister_s {
	uint8_t		cmn_spec;							//!< iSDIO Common Specification
	uint8_t		app_spec;							//!< iSDIO Application Specification
	uint8_t		cmd_write_update_necessity;			//!< Command Write Update Necessity
	uint8_t		cmd_resp_status_queue_supprt;		//!< Command Response Status Queue Support
	uint32_t	cmd_write_data_max_size;			//!< Max Size of Command Write Data
	uint32_t	cmd_resp_data_max_size;				//!< Max Size of Command Response Data
	uint8_t		reserved[0x34];						//!< 予約
	uint8_t		app_capability[0x1C0];				//!< Application Capability
} iSDIO_CapabilityRegister_t;

/**
 * iSDIOカード制御情報
 */
typedef struct iSDIO_INFO_s {

	/// iSDIOコマンドバッファ
	uint8_t		buf[iSDIO_BUF_SIZE];

	/// iSDIOコマンドデータサイズ
	uint32_t	cmd_write_data_size;

	/// iSDIOファンクション番号
	uint32_t	fno;

	/// Command Response Status
	iSDIO_CommandResponseStatus_t cmd_resp_status;

	/// iSDIOデバイスハンドル
	int			fd;

} iSDIO_INFO_t;


/*--- 外部関数定義 ---*/

// iSDIOドライバの初期化
extern iSDIO_INFO_t *iSDIO_Init(char *devname);

// iSDIOドライバの終了
extern int32_t iSDIO_Deinit(iSDIO_INFO_t *info);

// iSDIOレジスタの読み込み
extern int32_t iSDIO_ReadRegister(iSDIO_INFO_t *info, uint32_t addr, uint32_t size, uint8_t *buf);

// iSDIOレジスタの書き込み
extern int32_t iSDIO_WriteRegister(iSDIO_INFO_t *info, uint32_t addr, uint32_t size, uint8_t *buf);

// Capability Registerの読み込み
extern iSDIO_CapabilityRegister_t *iSDIO_ReadCapabilityRegister(iSDIO_INFO_t *info);

// Status Registerの読み込み
extern iSDIO_StatusRegister_t *iSDIO_ReadStatusRegister(iSDIO_INFO_t *info);

// iSDIO Write Commandの設定
extern int32_t iSDIO_SetWriteCommand(iSDIO_INFO_t *info, uint32_t seq_id, uint16_t cmd_id, uint16_t arg_num);

// iSDIOコマンド用Argumentデータの設定
extern int32_t iSDIO_SetArgument(iSDIO_INFO_t *info, void *arg, uint32_t size);

// iSDIOコマンドの実行
extern int32_t iSDIO_WriteCommandWriteData(iSDIO_INFO_t *info);

// Command Response Statusの読み込み
extern iSDIO_CommandResponseStatus_t *iSDIO_ReadCommandResponseStatus(iSDIO_INFO_t *info);

// Command Response Dataの読み込み
extern iSDIO_CommandResponseDataHeader_t *iSDIO_ReadCommandResponseData(iSDIO_INFO_t *info);

/* NSW add 2017.09.22 start */
/**
 * @name iSDIO Register Map
 * @{
 */
#define iSDIO_STATUS_REGISTER_VERSION				(0x005F0)	//!< Status Register Version
/**
 * @}
 */

/**
 * @name iSDIO Version Length
 * @{
 */
#define iSDIO_VERSION_LEN			16
/**
 * @}
 */

/**
* iSDIO Status Register Application Status Map(OFFSET:0x0500)
 */
#define iSDIO_STATUS_REGISTER_MAP_WLAN		6					//!< 0x0506 : WLAN
/**
 * @}
 */

/**
* iSDIO Status Register Application Status
 */
#define iSDIO_ST_REG_APPST_CONNECTED		0x80				//!< 3.4 iSDIO Status Register for Wireless LAN : 0x0506 Bit7   : Connected
#define iSDIO_ST_REG_APPST_ID				0x60				//!< 3.4 iSDIO Status Register for Wireless LAN : 0x0506 Bit6,5 : Infra Direct
/**
 * @}
 */

/* NSW add 2017.09.22 end */


#endif /* INC_ISDIO_API_H_ */
