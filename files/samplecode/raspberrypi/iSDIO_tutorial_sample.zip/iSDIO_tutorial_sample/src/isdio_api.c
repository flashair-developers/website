// *******************************************************
//   COPYRIGHT(C) 2017
//   Toshiba Development & Engineering Corporation
//   ALL RIGHTS RESERVED
// *******************************************************
/**
 * @file	isdio_api.c
 * @brief	iSDIO内部処理ライブラリ
 *
 * @see
 *   - Part E7 iSDIO Simplified Specification Version 1.10 March 25, 2014
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "../inc/isdio_api.h"

/**
 * @name Standard iSDIO Function Interface Code
 * @{
 */
#define iSDIO_FUNC_INTERFACE_CODE_NO_STANDARD		(0x0000)	//!< No Standard iSDIO Function
#define iSDIO_FUNC_INTERFACE_CODE_WIRELESS			(0x0001)	//!< Wireless LAN
#define iSDIO_FUNC_INTERFACE_CODE_TRANSFERJET		(0x0002)	//!< TransferJet
/**
 * @}
 */

/// ファンクション許可後のリトライカウント
#define iSDIO_FUNCTION_ENABLE_RETRY_COUNT			(10)

/// iSDIOカード制御情報
static iSDIO_INFO_t	s_iSDIO_info[iSDIO_CARD_MAX_NUM];


/*--- 静的関数のプロトタイプ宣言 ---*/

static bool_t isdio_CheckFBR(iSDIO_INFO_t *info, int fd, uint8_t fno);
static int32_t isdio_ConvertErrorCode(int32_t result);
static int32_t isdio_AppendData(iSDIO_INFO_t *info, void *data, int32_t size);


/**
 * @brief	iSDIOドライバの初期化
 *
 * @param[in]	devname		デバイスファイル名
 *
 * @return	iSDIOカード制御情報へのポインタを返す。
 *
 * 本関数では、指定されたデバイスファイル名のSDカードがサポートしているiSDIOカード
 * かどうかを確認し、制御情報を初期化する。未サポートのカードや制御情報エリアが
 * 確保出来ない場合は、NULLを返す。
 */
iSDIO_INFO_t *iSDIO_Init(char *devname) {

	int fd = 0;
	int32_t i;
	int32_t ret_sd;
	iSDIO_INFO_t *result = NULL;
	uint16_t fno;
	uint8_t ioe, ior;
	uint8_t buf[512];
	int count;

	memset(buf, 0x00, sizeof(buf));

	/**
	 * @par 内部処理
	 */

	fd = iSDIOREG_open_ext_reg(devname);
	if(fd >= 0){
		printf("%s open success\n", devname);
	}
	else{
		printf("!!! %s Open Error !!!\n", devname);
		return NULL;
	}

	/**
	 * @par (1) iSDIOカード制御情報格納エリアの空き状況の確認
	 * - s_iSDIO_infoの各fnoが0の場合、空き情報として扱う。
	 */
	for (i = 0; i < iSDIO_CARD_MAX_NUM; i ++) {
		if (s_iSDIO_info[i].fno == 0) {

			/**
			 * @par (2) 空きが見つかった場合
			 * - 各ファンクションのFBRのAdditional Definitions情報より、
			 *   iSDIOカードで、以下であることを確認する。
			 *   - Wireless LAN
			 *   - TransferJet
			 */

			/*
			 * 000000h-0000FFh CCCR
			 * 000100h-0001FFh FBR (Function 1)
			 *                   100h bit7: Function CSA enable
			 *                        bit6: Function supports CSA
			 *                        bit5,4: RFU
			 *                        bit3-0: Standard SDIO Function Interface Code
			 *                        			1110b: iSDIO
			 *                   103h Standard iSDIO Function Interface Code
			 *                         0000 0000b: No Standard iSDIO Function
			 *                         0000 0001b: Wireless LAN
			 *                         0000 0010b: TransferJet
			 *                   108h iSDIO Type Support Code
			 *                          iSDIO Type Support Code for Wireless LAN
			 *                            bit2: Type-P Support
			 *                            bit1: Type-D Support
			 *                            bit0: Type-W Support
			 * ...
			 * 000700h-0007FFh FBR (Function 7)
			 * 000800h-000BFFh General Information
			 * 000C00h-000FFFh RFU
			 * 001000h-017FFFh CIS Area
			 * 018000h-01FFFFh RFU
			 */

			for (fno = 1; fno < 8; fno ++) {
				ioe = 0x01 << fno;
				ior = 0;
				buf[0] = ioe;
				ret_sd = iSDIOREG_write_ext_reg(fd, 0, 0x0002, buf, 0, 0x01);
				if (ret_sd == E_SD_iSDIOREG_OK) {
					count = iSDIO_FUNCTION_ENABLE_RETRY_COUNT;
					while (count > 0) {
						buf[0] = 0;
						ret_sd = iSDIOREG_read_ext_reg(fd, 0, 0x0003, buf, 0, 0x01);
						ior = buf[0];
						if (ret_sd != E_SD_iSDIOREG_OK) {
							break;
						}
						if ((ior & ioe) != 0) {
							if (isdio_CheckFBR(&s_iSDIO_info[i], fd, fno)) {
								result = &s_iSDIO_info[i];
								break;
							}
						}
						count --;
					}
				}
				if (result != NULL) {
					break;
				}
			}
			break;
		}
	}

	/**
	 * @par (4) 終了処理
	 * - iSDIOカード制御情報へのポインタを返す。
	 */
	return result;

}

/**
 * @brief	FBRの確認
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 * @param[in]	fd		デバイスファイルハンドラ
 * @param[in]	fno		ファンクション番号
 *
 * @retval	TRUE	サポートしているiSDIOカードである。
 * @retval	FALSE	サポートしていないiSDIOカードである。
 *
 * iSDIOカードの FBRを読み込み、iSDIOカード(Wireless LAN(Type-W)またはTransferJet)
 * であることを確認する。
 *
 * @todo 処理を見直す
 */
static bool_t isdio_CheckFBR(iSDIO_INFO_t *info, int fd, uint8_t fno) {

	/**
	 * @par 内部処理
	 */
	bool_t result = FALSE;
	int32_t ret_sd;

	/**
	 * @par (1) FBR内のAdditional Definitions情報の読み込み
	 * - iSDIOREG_read_ext_regにより、Additional Definitions情報を読み込む。
	 */
	ret_sd = iSDIOREG_read_ext_reg(fd, 0, 0x100 * fno, info->buf, 0, 0x10);
	if (ret_sd == E_SD_iSDIOREG_OK) {

		/**
		 * @par (2) サポートしているiSDIOかどうかの確認
		 * - Standard SDIO Function Interface CodeがiSDIO(1110b)でない場合、(4)へジャンプ。
		 * - Standard iSDIO Function Interface CodeがWireless LAN(0000 0001b)で、且つ
		 *   iSDIO Wireless LAN Type-W Support情報が1である場合、(3)へジャンプ。
		 * - Standard iSDIO Function Interface CodeがTransferJet((0000 0010b)でない場合、(4)へジャンプ。
		 */
		if ((info ->buf[0x0000] & 0x0F) == 0x0E) {
			if (((info->buf[0x0003] == iSDIO_FUNC_INTERFACE_CODE_WIRELESS) && ((info->buf[0x0008] & 0x0001) != 0))
					|| (info->buf[0x0003] == iSDIO_FUNC_INTERFACE_CODE_TRANSFERJET)) {
				/**
				 * @par (3) iSDIOカード制御情報の初期化
				 * - s_iSDIO_infoを初期化する。
				 * - fnoには、(2)でiSDIOカードであると認識したファンクション番号を格納する。
				 */
				memset(info, 0, sizeof(iSDIO_INFO_t));
				info->fd = fd;
				info->fno = fno;
				result = TRUE;
			}
		}
	}

	/**
	 * @par (4) 終了処理
	 * 認識結果を返す。
	 */
	return result;
}

/**
 * @brief	iSDIOドライバの終了
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 *
 * @retval	E_iSDIO_OK				正常終了
 * @retval	E_iSDIO_INVALID_PARAM	パラメータエラー
 * @retval	E_iSDIO_DEVICE_ERROR	デバイスエラー
 * @retval	E_iSDIO_TIMEOUT			タイムアウト
 * @retval	E_iSDIO_UNKNOWN_ERROR	不明なエラー
 *
 * iSDIOドライバの終了処理として、iSDIOカードのI/Oファンクションを禁止にし、
 * iSDIOカード制御情報を無効化する。
 */
int32_t iSDIO_Deinit(iSDIO_INFO_t *info) {

	/**
	 * @par 内部処理
	 */
	int32_t result = E_iSDIO_OK;
	uint8_t buf[512];

	memset(buf, 0x00, sizeof(buf));

	/**
	 * @par (1) パラメータチェック
	 * - infoがNULL、またはinfo->fnoが0であればNULLを返す。
	 */
	if ((info == NULL) || (info->fno == 0)) {
		return E_iSDIO_INVALID_PARAM;
	}

	/**
	 * @par (2) I/Oファンクションの禁止
	 * CCCRのIOEを全て0にする。
	 * @note マルチファンクションのことは考慮しない
	 */
	result = iSDIOREG_write_ext_reg(info->fd, 0, 0x0002, buf, 0, 0x01);
	if (result != E_SD_iSDIOREG_OK) {
		printf("I/O function write error: %d\n", result);
		goto exit;
	}

	/**
	 * @par (3) iSDIOカード制御情報の解放
	 * info->fnoを0クリアする。
	 */
	info->fno = 0;

	/**
	 * @par (4) 終了処理
	 * @ref isdio_ConvertErrorCode を介して、実行結果を返す。
	 */
exit:
	iSDIOREG_close_ext_reg(info->fd);

	return isdio_ConvertErrorCode(result);
}

/**
 * @brief	エラーコード変換
 *
 * @param[in]	result	iSDIOコマンド発行関数エラーコード
 *
 * @retval	E_iSDIO_OK				正常終了
 * @retval	E_iSDIO_INVALID_PARAM	パラメータエラー
 * @retval	E_iSDIO_DEVICE_ERROR	デバイスエラー
 * @retval	E_iSDIO_TIMEOUT			タイムアウト
 * @retval	E_iSDIO_UNKNOWN_ERROR	不明なエラー
 *
 * iSDIOコマンド発行関数のエラーコードをiSDIOドライバのエラーコードに変換する。
 */
static int32_t isdio_ConvertErrorCode(int32_t result) {

	/**
	 * @par 内部処理
	 */

	/**
	 * - 以下のようにエラーコードを変換する。(iSDIOコマンド発行関数エラーコード -> iSDIOドライバエラーコート)
	 *   - E_SD_iSDIOREG_OK -> E_iSDIO_OK
	 *   - E_SD_iSDIOREG_ERR_PARAM -> E_iSDIO_INVALID_PARAM
	 *   - E_SD_iSDIOREG_ERR_DEVICE -> E_iSDIO_DEVICE_ERROR
	 *   - E_SD_iSDIOREG_ERR_TIMEOUT -> E_iSDIO_TIMEOUT
	 *   - 上記以外(実際にはない) -> E_iSDIO_UNKNOWN_ERROR
	 */
	switch (result) {
	case E_SD_iSDIOREG_OK:
		result = E_iSDIO_OK;
		break;
	case E_SD_iSDIOREG_ERR_PARAM:
		result = E_iSDIO_INVALID_PARAM;
		break;
	case E_SD_iSDIOREG_ERR_DEVICE:
		result = E_iSDIO_DEVICE_ERROR;
		break;
	case E_SD_iSDIOREG_ERR_TIMEOUT:
		result = E_iSDIO_TIMEOUT;
		break;
	default:
		result = E_iSDIO_UNKNOWN_ERROR;
		break;
	}
	return result;
}

/**
 * @brief	iSDIO Registerの読み込み
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 * @param[in]	addr	iSDIO Registerアドレス
 * @param[in]	size	読み込みサイズ
 * @param[out]	*buf	読み込んだデータの保存領域
 *
 * @retval	E_iSDIO_OK				正常終了
 * @retval	E_iSDIO_INVALID_PARAM	パラメータエラー
 * @retval	E_iSDIO_DEVICE_ERROR	デバイスエラー
 * @retval	E_iSDIO_TIMEOUT			タイムアウト
 * @retval	E_iSDIO_UNKNOWN_ERROR	不明なエラー
 *
 * iSDIO Registerの内容をbufに読み込む。iSDIO RegisterアドレスがiSDIO_RESPONSE_DATA_REGISTER_ADDRESS
 * の場合は、読み込むサイズを512単位となるよう拡張して読み込む(例：1バイト読み込みであっても、512バイト読み込む)。
 */
int32_t iSDIO_ReadRegister(iSDIO_INFO_t *info, uint32_t addr, uint32_t size, uint8_t *buf) {

	/**
	 * @par 内部処理
	 */
	int32_t result = E_SD_iSDIOREG_OK;
	uint32_t read_size;

	/**
	 * @par (1) データパディング
	 * addrが @ref iSDIO_RESPONSE_DATA_REGISTER_ADDRESS の場合は、512バイト単位の読み込みとなるようにする。
	 */
	if (addr == iSDIO_RESPONSE_DATA_REGISTER_ADDRESS) {
		size = (size + (SD_HCXC_BLOCK_SIZE - 1)) / SD_HCXC_BLOCK_SIZE * SD_HCXC_BLOCK_SIZE;
	}

	/**
	 * @par (2) iSDIO Registerの読み込み
	 * 一度に読み込むデータサイズの最大値をSD_HCXC_BLOCK_SIZEとして、
	 * iSDIOREG_read_ext_regにより、addrからのデータ読み込みを繰り返す。
	 */
	while (size > 0) {
		read_size = size;
		if (read_size > SD_HCXC_BLOCK_SIZE) {
			read_size = SD_HCXC_BLOCK_SIZE;
		}
		result = iSDIOREG_read_ext_reg(info->fd, info->fno, addr, buf, 0, read_size);
		if (result != E_SD_iSDIOREG_OK) {
			break;
		}
		size -= read_size;
		buf += read_size;
		if (addr != iSDIO_RESPONSE_DATA_REGISTER_ADDRESS) {
			addr += read_size;
		}
	}

	/**
	 * @par (3) 終了処理
	 * @ref isdio_ConvertErrorCode を介して、実行結果を返す。
	 */
	return isdio_ConvertErrorCode(result);
}

/**
 * @brief	iSDIO Registerの書き込み
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 * @param[in]	addr	iSDIO Registerアドレス
 * @param[in]	size	書き込むサイズ
 * @param[in]	*buf	書き込むデータ
 *
 * @retval	E_iSDIO_OK				正常終了
 * @retval	E_iSDIO_INVALID_PARAM	パラメータエラー
 * @retval	E_iSDIO_DEVICE_ERROR	デバイスエラー
 * @retval	E_iSDIO_TIMEOUT			タイムアウト
 * @retval	E_iSDIO_UNKNOWN_ERROR	不明なエラー
 *
 * bufの内容をiSDIO Registerに書き込む。iSDIO RegisterアドレスがiSDIO_COMMAND_WRITE_REGISTER_PORT_ADDRESS
 * の場合は、512バイト単位になるように0パディングデータを付加する。
 */
int32_t iSDIO_WriteRegister(iSDIO_INFO_t *info, uint32_t addr, uint32_t size, uint8_t *buf) {

	/**
	 * @par 内部処理
	 */
	int32_t result = E_SD_iSDIOREG_OK;
	uint32_t write_size;

	/**
	 * @par (1) データパディング
	 * addrが @ref iSDIO_COMMAND_WRITE_REGISTER_PORT_ADDRESS の場合は、0パディング
	 * データをつけて、512バイト単位の書き込みとなるようにする。
	 */
	if (addr == iSDIO_COMMAND_WRITE_REGISTER_PORT_ADDRESS) {
		if ((size % SD_HCXC_BLOCK_SIZE) != 0) {
			write_size = (size + (SD_HCXC_BLOCK_SIZE - 1)) / SD_HCXC_BLOCK_SIZE * SD_HCXC_BLOCK_SIZE;
			memset(buf + size, 0, write_size - size);
			size = write_size;
		}
	}

	/**
	 * @par (2) iSDIO Registerへの書き込み
	 * 一度に書き込むデータサイズの最大値をSD_HCXC_BLOCK_SIZEとして、
	 * iSDIOREG_write_ext_regにより、addrへデータの書き込みを繰り返す。
	 */
	while (size > 0) {
		write_size = size;
		if (write_size > SD_HCXC_BLOCK_SIZE) {
			write_size = SD_HCXC_BLOCK_SIZE;
		}
		result = iSDIOREG_write_ext_reg(info->fd, info->fno, addr, buf, 0, write_size);
		if (result != E_SD_iSDIOREG_OK) {
			break;
		}
		size -= write_size;
		buf += write_size;
		if (addr != iSDIO_COMMAND_WRITE_REGISTER_PORT_ADDRESS) {
			addr += write_size;
		}
	}

	/**
	 * @par (3) 終了処理
	 * @ref isdio_ConvertErrorCode を介して、実行結果を返す。
	 */
	return isdio_ConvertErrorCode(result);
}

/**
 * @brief	Capability Registerの読み込み
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 *
 * @return	取得したCapabilityへのアドレスを返す。失敗した場合はNULLを返す。
 *
 * iSDIO Registerのアドレス0x600(@ref iSDIO_CAPABILITY_REGISTER_ADDRESS) のCapability Registerを
 * 読み込む。
 */
iSDIO_CapabilityRegister_t *iSDIO_ReadCapabilityRegister(iSDIO_INFO_t *info) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) パラメータチェック
	 * - infoがNULL、またはinfo->fnoが0であればNULLを返す。
	 */
	if ((info == NULL) || (info->fno == 0)) {
		return NULL;
	}

	/**
	 * @par (2) Capability Registerの読み込み
	 * iSDIO_ReadRegisterにより、Capability Registerをinfo->bufに読み込む。
	 * 読み込みに成功した場合は、info->bufのアドレスを返し、失敗した場合は、NULLを返す。
	 */
	result = iSDIO_ReadRegister(info, iSDIO_CAPABILITY_REGISTER_ADDRESS, sizeof(iSDIO_CapabilityRegister_t), info->buf);
	if (result == E_iSDIO_OK) {
		return (iSDIO_CapabilityRegister_t*)info->buf;
	}
	return NULL;
}

/**
 * @brief	Status Registerの読み込み
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 *
 * @return	読み込んだStatus Register保存領域へのポインタを返す。失敗した場合はNULLを返す。
 *
 * iSDIO Registerのアドレス0x400(@ref iSDIO_STATUS_REGISTER_ADDRESS) のStatus Registerを
 * 読み込む。
 */
iSDIO_StatusRegister_t *iSDIO_ReadStatusRegister(iSDIO_INFO_t *info) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) パラメータチェック
	 * - infoがNULL、またはinfo->fnoが0であればNULLを返す。
	 */
	if ((info == NULL) || (info->fno == 0)) {
		return NULL;
	}

	/**
	 * @par (2) Status Register の読み込み
	 * iSDIO_ReadRegisterにより、Status Registerをinfo->bufに読み込む。
	 * 読み込みに成功した場合は、info->bufのアドレスを返し、失敗した場合は、NULLを返す。
	 */
	result = iSDIO_ReadRegister(info, iSDIO_STATUS_REGISTER_ADDRESS, sizeof(iSDIO_StatusRegister_t), info->buf);
	if (result == E_iSDIO_OK) {
		return (iSDIO_StatusRegister_t*)info->buf;
	}
	return NULL;
}

/**
 * @brief	iSDIOコマンド用バッファへのデータ書き込み
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 * @param[in]	*data	データ
 * @param[in]	size	データのサイズ
 *
 * @retval	E_iSDIO_OK					正常終了
 * @retval	E_iSDIO_CMD_BUF_OVERFLOW	iSDIOコマンドバッファが一杯
 *
 * iSDIOコマンド用バッファへ指定されたデータを書き込む。バッファが一杯であること
 * を検出した場合は、E_iSDIO_CMD_BUF_OVERFLOWを返す。
 */
static int32_t isdio_AppendData(iSDIO_INFO_t *info, void *data, int32_t size) {

	/**
	 * @par 内部処理
	 */

	/**
	 * @par (1) パラメータチェック
	 * - infoがNULL、またはinfo->fnoが0であればE_iSDIO_INVALID_PARAMを返す。
	 */
	if ((info == NULL) || (info->fno == 0)) {
		return E_iSDIO_INVALID_PARAM;
	}

	/**
	 * @par (2) バッファの空き状況チェック
	 * - info->bufに指定されたサイズ分の空きがあるかどうかチェックする。
	 * 　空きが無かった場合は、E_iSDIO_CMD_BUF_OVERFLOWを返す。
	 */
	if (info->cmd_write_data_size + size > iSDIO_BUF_SIZE) {
	    return E_iSDIO_CMD_BUF_OVERFLOW;
	}

	/**
	 * @par (3) データコピー
	 * - バッファの空きエリアの先頭に指定されたデータをコピーし、cmd_write_data_sizeを更新する。
	 */
	memcpy(&info->buf[info->cmd_write_data_size], data, size);
	info->cmd_write_data_size += size;

	/**
	 * @par (4) 終了処理
	 * - E_iSDIO_OKを返す。
	 */
	return E_iSDIO_OK;
}

/**
 * @brief	iSDIO Write Commandの設定
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	cmd_id		iSDIOコマンドID
 * @param[in]	arg_num		Argument数
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * iSDIOコマンド発行用バッファの指定されたパラメータで初期化する。本関数実行後は、
 * arg_numで指定したArgument数分の @ref iSDIO_SetArgument でArgumentを設定する
 * 必要がある。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 2.2.2.2 iSDIO Command Write Data
 */
int32_t iSDIO_SetWriteCommand(iSDIO_INFO_t *info, uint32_t seq_id, uint16_t cmd_id, uint16_t arg_num) {

	/**
	 * @par 内部処理
	 */
	int32_t result;
	iSDIO_CommandWriteDataHeader_t cmd_data_header;
	iSDIO_CommandInformationHeader_t cmd_info_header;

	/**
	 * @par (1) パラメータチェック
	 * - infoがNULL、またはinfo->fnoが0であればE_iSDIO_INVALID_PARAMを返す。
	 */
	if ((info == NULL) || (info->fno == 0)) {
		return E_iSDIO_INVALID_PARAM;
	}

	/**
	 * @par (2) info->cmd_write_data_sizeの初期化
	 * - info->cmd_write_data_sizeを0にリセットする。
	 * - info->cmd_resp_status.response_statusをiSDIO_INITIALにセットする。
	 */
	info->cmd_write_data_size = 0;
	info->cmd_resp_status.response_status = iSDIO_INITIAL;

	/**
	 * @par (3) iSDIO Command Write Dataのヘッダの設定
	 * - iSDIO Command Write Dataのヘッダの初期化
	 *   - iSDIO_command_write_identifierに0x01を設定する。
	 *   - number_of_iSDIO_commandsに1を設定する。
	 *   - size_of_iSDIO_command_write_dataに0を設定する。(iSDIO_WriteCommandWriteDataにて再設定)
	 *   - Reservedフィールドには0を設定する。
	 */
	cmd_data_header.iSDIO_command_write_identifier = 0x01;
	cmd_data_header.reserved_1 = 0x0000;
	cmd_data_header.number_of_iSDIO_commands = 0x01;
	cmd_data_header.size_of_iSDIO_command_write_data = 0;
	cmd_data_header.reserved_2 = 0x00000000;
	isdio_AppendData(info, &cmd_data_header, sizeof(iSDIO_CommandWriteDataHeader_t));	// エラーが返ることはない！

	/**
	 * @par (4) iSDIO Command Information in Command Write Dataの設定
	 * - iSDIO_CommandInformationHeader_tの初期化
	 *   - iSDIO_command_idに入力cmd_idを設定する。
	 *   - iSDIO_command_sequence_idにseq_idを設定する。
	 *   - number_of_argumentsに入力のarg_numを設定する。
	 *   - Reservedフィードは0クリアする。
	 * - iSDIO_CommandInformationHeader_tをinfo->bufに追加する。
	 *   - 追加に失敗した場合はエラーとする。
	 */
	cmd_info_header.reserved_1 = 0x0000;
	cmd_info_header.iSDIO_command_id = cmd_id;
	cmd_info_header.iSDIO_command_sequence_id = seq_id;
	cmd_info_header.number_of_arguments = arg_num;
	cmd_info_header.reserved_2 = 0x0000;
	result = isdio_AppendData(info, &cmd_info_header, sizeof(iSDIO_CommandInformationHeader_t));

	/**
	 * @par (5) 終了処理
	 * - 実行結果を返す。
	 */
	return result;
}

/**
 * @brief	iSDIOコマンド用Argumentデータの設定
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 * @param[in]	*arg	Argumentデータ
 * @param[in]	size	Argumentデータのバイト数
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * iSDIOコマンド用Argumentを内部バッファに追加する。
 */
int32_t iSDIO_SetArgument(iSDIO_INFO_t *info, void *arg, uint32_t size) {

	/**
	 * @par	内部処理
	 */
	static uint8_t padding[] = {0x00, 0x00, 0x00};
	uint32_t padding_size;
	int32_t result;

	/**
	 * @par (1) パラメータチェック
	 * - infoがNULL、sizeが0でないのにargがNULL、またはinfo->fnoが0であれば
	 *   E_iSDIO_INVALID_PARAMを返す。
	 */
	if ((info == NULL) || ((size != 0) && (arg == NULL)) || (info->fno == 0)) {
		return E_iSDIO_INVALID_PARAM;
	}

	/**
	 * @par (2) Argumentのバイト数の設定
	 * 指定されたArgumentデータのバイト数をinfo->bufに追加する。
	 */
	result = isdio_AppendData(info, &size, 4);
	if (result != E_iSDIO_OK) {
		goto error;
	}

	if (size != 0) {
		/**
		 * @par (3) Argumentの設定
		 * 指定されたサイズ分のArgumentデータをinfo->bufに格納する。
		 *
		 */
		result = isdio_AppendData(info, arg, size);
		if (result != E_iSDIO_OK) {
			goto error;
		}

		/**
		 * @par (4) Paddingデータの追加
		 * Argumentデータのバイト数が4の倍数でない場合は、4の倍数になるようpadding
		 * データ(0x00)をinfo->bufに追加する。
		 */
		padding_size = 4 - size % 4;
		if (padding_size < 4) {
			result = isdio_AppendData(info, padding, padding_size);
		}
	}

	/**
	 * @par (5) 終了処理
	 * - 実行結果を返す。
	 */
error:
	return result;
}

/**
 * @brief	iSDIOコマンドの発行
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * @ref iSDIO_SetWriteCommand, @ref iSDIO_SetArgument で指定したiSDIOコマンドを
 * SDホストコントローラに発行する。iSDIOコマンドの実行プロセス状況の確認は、
 * @ref iSDIO_ReadCommandResponseStatus で行うこと。
 */
int32_t iSDIO_WriteCommandWriteData(iSDIO_INFO_t *info) {

	/**
	 * @par 内部処理
	 */
	iSDIO_CommandWriteDataHeader_t *header;
	int32_t result;

	/**
	 * @par (1) パラメータチェック
	 * - infoがNULL、またはinfo->fnoが0であればE_iSDIO_INVALID_PARAMを返す。
	 */
	if ((info == NULL) || (info->fno == 0)) {
		return E_iSDIO_INVALID_PARAM;
	}

	/**
	 * @par (2) iSDIOコマンドサイズの設定
	 * iSDIO Command Write Dataのsize_of_iSDIO_command_write_dataに info->cmd_write_data_sizeを設定する。
	 */
	header = (iSDIO_CommandWriteDataHeader_t*)info->buf;
	header->size_of_iSDIO_command_write_data = info->cmd_write_data_size;

	/**
	 * @par (3) iSDIOコマンドの書き込み
	 * - iSDIO_WriteRegisterにより、iSDIOコマンドを @ref iSDIO_COMMAND_WRITE_REGISTER_PORT_ADDRESS に
	 *   書き込む。
	 */
	result = iSDIO_WriteRegister(info, iSDIO_COMMAND_WRITE_REGISTER_PORT_ADDRESS, info->cmd_write_data_size, info->buf);

	/**
	 * @par (4) 終了処理
	 * - 実行結果を返す。
	 */
	return result;
}

/**
 * @brief	Command Response Statusの読み込み
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 *
 * @return	取得したCommand Response Statusへのアドレスを返す。失敗した場合はNULLを返す。
 *
 * @ref iSDIO_WriteCommandWriteData で発行した、iSDIOコマンドの実行プロセス情報である
 * Command Response Status を読み込む。iSDIOコマンドが正常終了した場合は、response_status
 * が @ref iSDIO_PROCESS_SUCCEEDED となる。
 */
iSDIO_CommandResponseStatus_t *iSDIO_ReadCommandResponseStatus(iSDIO_INFO_t *info) {

	/**
	 * @par 内部処理
	 */
	int32_t result;
	uint8_t data_buf[SD_HCXC_BLOCK_SIZE];

	/**
	 * @par (1) パラメータチェック
	 * - infoがNULL、またはinfo->fnoが0であればNULLを返す。
	 */
	if ((info == NULL) || (info->fno == 0)) {
		return NULL;
	}

	/**
	 * @par (2) Command Response Statusの読み込み
	 * iSDIO_ReadRegisterにより、@ref iSDIO_COMMAND_RESPONSE_STATUS_QUEUE からスタータスをinfo->cmd_resp_statusに読み込む。
	 * 読み込みに成功した場合は、info->cmd_resp_statusのアドレスを返し、失敗した場合は、NULLを返す。
	 */
//	result = iSDIO_ReadRegister(info, iSDIO_COMMAND_RESPONSE_STATUS_QUEUE, sizeof(iSDIO_CommandResponseStatus_t), (uint8_t*)&info->cmd_resp_status);
	result = iSDIO_ReadRegister(info, iSDIO_COMMAND_RESPONSE_STATUS_QUEUE, sizeof(iSDIO_CommandResponseStatus_t), data_buf);
	if (result == E_iSDIO_OK) {
		memcpy(&info->cmd_resp_status, data_buf, sizeof(iSDIO_CommandResponseStatus_t));
		return &info->cmd_resp_status;
	}
	return NULL;
}

/**
 * @brief	Command Response Dataの読み込み
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 *
 * @return	読み込んだCommand Response Dataへのポインタを返す。
 *
 * @par 注意
 * 本関数を実行する前には @ref iSDIO_ReadCommandResponseStatus を実行し、戻り値である
 * iSDIO_CommandResponseStatus_tののresponse_statusが @ref iSDIO_PROCESS_SUCCEEDED である
 * ことを確認すること。response_statusが @ref iSDIO_PROCESS_SUCCEEDED でない場合の本関数の戻り値はNULLとなる。
 * また、読み込むデータサイズは、最大 @ref iSDIO_BUF_SIZE までである。
 */
iSDIO_CommandResponseDataHeader_t *iSDIO_ReadCommandResponseData(iSDIO_INFO_t *info) {

	/**
	 * @par 内部処理
	 */
	int32_t result;
	uint32_t size;

	/**
	 * @par (1) パラメータチェック
	 * - infoがNULL、またはinfo->fnoが0であればNULLを返す。
	 */
	if ((info == NULL) || (info->fno == 0)) {
		return NULL;
	}

	/**
	 * @par (2) Response Dataサイズの取得チェック
	 * - info->response_statusがiSDIO_PROCESS_SUCCEEDEDでない場合はNULLを返す。
	 */
	if (info->cmd_resp_status.response_status != iSDIO_PROCESS_SUCCEEDED) {
		return NULL;
	}

	/**
	 * @par (3) 読み込むCommand Response Dataのバイト数の取得
	 * - Command Response Dataサイズはinfo->cmd_resp_status.resp_data_sizeとする。
	 *   但し、info->bufのサイズより大きい場合は、info->bufのサイズまでとする。
	 *   (※規格に記載されているCommand Response StatusのResponse Data SizeはCommand Response Data Sizeのこと)
	 */
	size = info->cmd_resp_status.resp_data_size;
	if (size > iSDIO_BUF_SIZE) {
		size = iSDIO_BUF_SIZE;
	}

	/**
	 * @par (4) Command Response Dataの読み込み
	 * - iSDIO_ReadRegisterにより、iSDIO_RESPONSE_DATA_REGISTER_ADDRESSからCommand Response Dataを読み込む。
	 * - 読み込みに成功した場合は、info->bufを返し、失敗した場合はNULLを返す。
	 */
	result = iSDIO_ReadRegister(info, iSDIO_RESPONSE_DATA_REGISTER_ADDRESS, size, info->buf);
	if (result != E_iSDIO_OK) {
		return NULL;
	}
	return (iSDIO_CommandResponseDataHeader_t*)info->buf;
}
