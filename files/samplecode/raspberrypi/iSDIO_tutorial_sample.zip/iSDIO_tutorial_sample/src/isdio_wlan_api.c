// *******************************************************
//   COPYRIGHT(C) 2017
//   Toshiba Development & Engineering Corporation
//   ALL RIGHTS RESERVED
// *******************************************************
/**
 * @file isdio_wlan_api.c
 * @brief iSDIO(FlashAir)APIのソースファイル
 *
 * @see
 *   - Part E7 iSDIO Simplified Specification Version 1.10 March 25, 2014
 *   - Part E7 Wireless LAN Simplified Addendum Version 1.10 March 25, 2014
 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>

#include "../inc/isdio_wlan_api.h"

unsigned int WaitResponseTime = 30000/20;	//NSW add 2017.09.22 end

/**
 * @brief	接続可能な無線LANの探索
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 接続可能な無線LANを探索する。探索した結果は @ref iSDIO_ReadCommandResponseData にて取得する。
 * 取得したレスポンスデータのフォーマットについては、@ref iSDIO_WLAN_SSIDList_s
 * 構造体を参照のこと。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 3.6.2 Wireless LAN SSID List
 *   - 4.2.1 Scan()
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_Scan(iSDIO_INFO_t *info, uint32_t seq_id) {

	/**
	 * @par 内部処理
	 */
	int32_t result = E_iSDIO_OK;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommandにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドID=iSDIO_WLAN_SCANを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SCAN, 0);
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);
	if (result != E_iSDIO_OK) {
		goto exit;
    }

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	ステーションとしての無線LANの接続
 *
 * @param[in]	*info			iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id			iSDIOコマンドシーケンスID
 * @param[in]	*ssid			接続先APのSSID
 * @param[in]	ssid_size		接続先APのSSIDのバイト数
 * @param[in]	*ntwk_key		ネットワークキー
 * @param[in]	ntwk_key_size	ネットワークキーのバイト数(0の場合は暗号化なし)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * ステーションとして、指定されたアクセスポイントのSSID, ネットワークキー
 * で無線LANを接続する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.2.2 Connect(ssid, networkKey)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_Connect(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *ssid, uint16_t ssid_size,
		uint8_t *ntwk_key, uint32_t ntwk_key_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_CONNECTを設定する。
	 *   - Argument 1にssidを設定する。
	 *   - Argument 2にntwk_keyを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_CONNECT, 2);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, ssid, ssid_size);			// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, ntwk_key, ntwk_key_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	アクセスポイントとしての無線LAN接続の確立
 *
 * @param[in]	*info			iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id			iSDIOコマンドシーケンスID
 * @param[in]	*ssid			接続するSTAのSSID
 * @param[in]	ssid_size		接続するSTAのSSIDのバイト数
 * @param[in]	*ntwk_key		ネットワークキー
 * @param[in]	ntwk_key_size	ネットワークキーのバイト数(0の場合は暗号化なし)
 * @param[in]	encMode			暗号モード(@ref iSDIO_WLAN_EcnMode_e)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * アクセスポイントとして、指定されたステーションのSSID, ネットワークキー、
 * 暗号モードで無線LAN接続を確立させる。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 3.5 iSDIO Capability Register for Wireless LAN
 *   - 4.2.3 Establish(ssid, networkKey, encMode)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_Establish(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *ssid, uint32_t ssid_size,
		uint8_t *ntwk_key, uint32_t ntwk_key_size,
		iSDIO_WLAN_EcnMode_t encMode) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_ESTABLISHを設定する。
	 *   - Argument 1にssidを設定する。
	 *   - Argument 2にntwk_keyを設定する。
	 *   - Argument 3にencModeを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_ESTABLISH, 3);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, ssid, ssid_size);			// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, ntwk_key, ntwk_key_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &encMode, 1);				// argument 3
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	WiFiダイレクト接続
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	wpsMode		WPSモード(@ref iSDIO_WLAN_WPSMode_e)
 * @param[in]	*pin		PINコード
 * @param[in]	pin_size	PINコードサイズ
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * WiFiダイレクト接続を行う。wpsModeで iSDIO_WLAN_WPSMODE_WITH_PBC を指定
 * する場合、pinにはNULL、pin_sizeには0を指定すること。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.2.4 WiFiDirect(wpsMode, pin)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_WiFiDirect(
		iSDIO_INFO_t *info, uint32_t seq_id,
		iSDIO_WLAN_WPSMode_t wpsMode,
		uint8_t *pin, uint32_t pin_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_WIFI_DIRECTを設定する。
	 *   - Argument 1にwpsModeを設定する。
	 *   - Argument 2にpinを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_WIFI_DIRECT, 2);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &wpsMode, 1);				// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, pin, pin_size);			// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	ステーションとしてのWPSによる無線LAN接続設定の開始
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	*ssid		接続先APのSSID
 * @param[in]	ssid_size	接続先APのSSIDのバイト数
 * @param[in]	wpsMode		WPSモード(@ref iSDIO_WLAN_WPSMode_e)
 * @param[in]	*pin		PINコード
 * @param[in]	pin_size	PINコードサイズ
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * ステーションとして、WPSによる無線LAN接続設定を開始する。本コマンド完了後、
 * アクセスポイントの無線LAN接続設定情報は @ref iSDIO_ReadCommandResponseData
 * にて取得できる。
 * なお、wpsModeで iSDIO_WLAN_WPSMODE_WITH_PBC を指定する場合、ssid, pinにはNULL、
 * ssid_size, pin_sizeには0を指定すること。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 3.6.1 WPS List
 *   - 4.2.5 StartWPS(ssid, wpsMode, pin)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_StartWPS(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *ssid, uint32_t ssid_size,
		iSDIO_WLAN_WPSMode_t wpsMode,
		uint8_t *pin, uint32_t pin_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_START_WPSを設定する。
	 *   - Argument 1にssidを設定する。
	 *   - Argument 2にwpsModeを設定する。
	 *   - Argument 3にpinを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_START_WPS, 3);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, ssid, ssid_size);		// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &wpsMode, 1);          // argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, pin, pin_size);        // argument 3
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	アクセスポイントとしてのWPSによる無線LAN接続設定の開始
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	wpsMode		WPSモード(@ref iSDIO_WLAN_WPSMode_e)
 * @param[in]	*pin		PINコード
 * @param[in]	pin_size	PINコードサイズ
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * アクセスポイントとしてWPSによる無線LAN接続設定を開始する。
 * wpsModeで iSDIO_WLAN_WPSMODE_WITH_PBC を指定する場合、pinにはNULL、pin_sizeには0を指定すること。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.2.6 StartWPSAP(wpsMode, pin)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_StartWPSAP(
		iSDIO_INFO_t *info, uint32_t seq_id,
		iSDIO_WLAN_WPSMode_t wpsMode,
		uint8_t *pin, uint32_t pin_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_START_WPSAPを設定する。
	 *   - Argument 1にwpsModeを設定する。
	 *   - Argument 2にpinを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_START_WPSAP, 2);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &wpsMode, 1);	        // argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, pin, pin_size);		// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	無線LANの切断
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 無線LAN接続を切断する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.2.7 Disconnect()
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_Disconnect(iSDIO_INFO_t *info, uint32_t seq_id) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommandにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_DISCONNECTを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_DISCONNECT, 0);
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	カードの日時設定
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	currentDate	日付
 * @param[in]	currentTime	時間
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * SDカードの日時設定を行う。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.3.1 SetCurrentTime(currentDate, currentTime)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SetCurrentTime(
		iSDIO_INFO_t *info, uint32_t seq_id,
		iSDIO_WLAN_Date_t currentDate,
		iSDIO_WLAN_Time_t currentTime) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SET_CURRENT_TIMEを設定する。
	 *   - Argument 1にcurrentDateを設定する。
	 *   - Argument 2にcurrentTimeを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SET_CURRENT_TIME, 2);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &currentDate, 2);		// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &currentTime, 2);		// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	iSDIOコマンド実行プロセスの中断
 *
 * @param[in]	*info			iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id			iSDIOコマンドシーケンスID
 * @param[in]	abort_seq_id	中断させるiSDIOコマンドシーケンスID
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * iSDIOコマンド実行プロセスを中断する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.3.2 Abort(sequenceID)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_Abort(iSDIO_INFO_t *info, uint32_t seq_id, uint32_t abort_seq_id) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_ABORTを設定する。
	 *   - Argument 1にabort_seq_idを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_ABORT, 1);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &abort_seq_id, 4);		// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	レスポンスデータ読み込み
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	read_seq_id	レスポンスデータを読み込むiSDIOコマンドシーケンスID
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * レスポンスデータの読み込みコマンドを発行する。
 * レスポンスデータは、@ref iSDIO_ReadCommandResponseData にて別途取得すること。
 *
 * @see
 *   - iSDIO Simplified Specification Version 1.10
 *     - 2.2.2.3 iSDIO Command Response Data
 *   - Wireless LAN Simplified Addendum Version 1.10
 *     - 4.3.3 ReadResponse(sequenceID)
 *     - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_ReadResponse(iSDIO_INFO_t *info, uint32_t seq_id, uint32_t read_seq_id) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_READ_RESPONSEを設定する。
	 *   - Argument 1にread_seq_idを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_READ_RESPONSE, 1);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &read_seq_id, 4);			// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	パワーセーブモードの設定
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	powerMode	パワーセーブモード
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * パワーセーブモードの設定を行う。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.3.4 SetPowerSaveMode(powerMode)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SetPowerSaveMode(
		iSDIO_INFO_t *info, uint32_t seq_id,
		iSDIO_WLAN_PowerMode_t powerMode) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SET_POWER_SAVE_MODEを設定する。
	 *   - Argument 1にpowerModeを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SET_POWER_SAVE_MODE, 1);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &powerMode, 1);			// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	アクセスポイントのチャネル番号の設定
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	ch			チャネル番号 <br>
 * 							　0x00: 自動 <br>
 * 							　0x01: チャネル1 <br>
 * 							　... <br>
 * 							　0x0E: チャネル14 <br>
 * 							　0x24: チャネル36 <br>
 * 							　... <br>
 * 							　0xA1: チャネル161
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * チャネル番号の設定を行う。
 * サポートされているチャネル番号については、Capability Registerにより取得出来る。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 3.5 iSDIO Capability Register for Wireless LAN
 *   - 4.3.5 SetChannel(channelNum)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SetCannel(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t ch) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SET_CHANNELを設定する。
	 *   - Argument 1にchを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SET_CHANNEL, 1);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &ch, 1);				// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	HTTPメッセージの送信
 *
 * @param[in]	*info			iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id			iSDIOコマンドシーケンスID
 * @param[in]	*hostname		ホスト名
 * @param[in]	hostname_size	ホスト名のバイト数
 * @param[in]	*message		HTTPメッセージ
 * @param[in]	message_size	HTTPメッセージのバイト数
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 指定されたホストに対して、HTTPメッセージを送信する。
 *
 * @see
 *   - iSDIO Simplified Specification Version 1.10
 *     - 2.2.2.3 iSDIO Command Response Data
 *   - Wireless LAN Simplified Addendum Version 1.10
 *     - 4.4.1 SendHTTPMessageByRegister(hostName, message)
 *     - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SendHTTPMessageByRegister(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *message, uint32_t message_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SEND_HTTP_MESSAGE_BY_REGISTERを設定する。
	 *   - Argument 1にhostnameを設定する。
	 *   - Argument 2にmessageを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SEND_HTTP_MESSAGE_BY_REGISTER, 2);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, hostname, hostname_size);	// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, message, message_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	添付ファイル付きHTTPメッセージの送信
 *
 * @param[in]	*info			iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id			iSDIOコマンドシーケンスID
 * @param[in]	*hostname		ホスト名
 * @param[in]	hostname_size	ホスト名のバイト数
 * @param[in]	*filename		添付ファイル名
 * @param[in]	filename_size	ファイル名のバイト数
 * @param[in]	*message		HTTPメッセージ
 * @param[in]	message_size	HTTPメッセージのバイト数
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 指定されたホストに対して、HTTPメッセージに添付ファイルを展開し、送信する。
 * ファイル名はNANDメモリ内のrootからのフルパスで指定すること。
 *
 * @see
 *   - iSDIO Simplified Specification Version 1.10
 *     - 2.2.2.3 iSDIO Command Response Data
 *   - Wireless LAN Simplified Addendum Version 1.10
 *     - 4.4.2 SendHTTPFileByRegister(hostName, appendFileName, message)
 *     - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SendHTTPFileByRegister(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *filename, uint32_t filename_size,
		uint8_t *message, uint32_t message_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SEND_HTTP_FILE_BY_REGISTERを設定する。
	 *   - Argument 1にhostnameを設定する。
	 *   - Argument 2にfilenameを設定する。
	 *   - Argument 3にmessageを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SEND_HTTP_FILE_BY_REGISTER, 3);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, hostname, hostname_size);	// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, filename, filename_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, message, message_size);	// argument 3
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	HTTPメッセージの送信(SSL)
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	*hostname		ホスト名
 * @param[in]	hostname_size	ホスト名のバイト数
 * @param[in]	*message		HTTPメッセージ
 * @param[in]	message_size	HTTPメッセージのバイト数
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 指定されたホストに対して、HTTPメッセージをSSLで送信する。
 *
 * @see
 *   - iSDIO Simplified Specification Version 1.10
 *     - 2.2.2.3 iSDIO Command Response Data
 *   - Wireless LAN Simplified Addendum Version 1.10
 *     - 4.4.3 SendHTTPSSLMessageByRegister(hostName, message)
 *     - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SendHTTPSSLMessageByRegister(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *message, uint32_t message_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SEND_HTTP_SSL_MESSAGE_BY_REGISTERを設定する。
	 *   - Argument 1にhostnameを設定する。
	 *   - Argument 2にmessageを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SEND_HTTP_SSL_MESSAGE_BY_REGISTER, 2);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, hostname, hostname_size);	// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, message, message_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	添付ファイル付きHTTPメッセージの送信(SSL)
 *
 * @param[in]	*info			iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id			iSDIOコマンドシーケンスID
 * @param[in]	*hostname		ホスト名
 * @param[in]	hostname_size	ホスト名のバイト数
 * @param[in]	*filename		添付ファイル名
 * @param[in]	filename_size	ファイル名のバイト数
 * @param[in]	*message		HTTPメッセージ
 * @param[in]	message_size	HTTPメッセージのバイト数
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 指定されたホストに対して、HTTPメッセージに添付ファイルを展開し、SSLで送信する。
 * ファイル名はNANDメモリ内のrootからのフルパスで指定すること。
 *
 * @see
 *   - iSDIO Simplified Specification Version 1.10
 *     - 2.2.2.3 iSDIO Command Response Data
 *   - Wireless LAN Simplified Addendum Version 1.10
 *     - 4.4.4 SendHTTPSSLFileByRegister(hostName, appendFileName, message)
 *     - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SendHTTPSSLFileByRegister(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *filename, uint32_t filename_size,
		uint8_t *message, uint32_t message_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SEND_HTTP_SSL_FILE_BY_REGISTERを設定する。
	 *   - Argument 1にhostnameを設定する。
	 *   - Argument 2にfilenameを設定する。
	 *   - Argument 3にmessageを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SEND_HTTP_SSL_FILE_BY_REGISTER, 3);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, hostname, hostname_size);	// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, filename, filename_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, message, message_size);	// argument 3
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	HTTPメッセージ(ファイル)の送信
 *
 * @param[in]	*info				iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id				iSDIOコマンドシーケンスID
 * @param[in]	*hostname			ホスト名
 * @param[in]	hostname_size		ホスト名のバイト数
 * @param[in]	*msg_filename		メッセージファイル名
 * @param[in]	msg_filename_size	メッセージファイル名のバイト数
 * @param[in]	headerRemoval		ヘッダ付加情報(@ref iSDIO_WLAN_HeaderRemoval_e)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 指定されたホストに対して、HTTPメッセージ(ファイル)を送信する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.4.5 SendHTTPMessageByFile(hostName, messageFileName, headerRemoval)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SendHTTPMessageByFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *msg_filename, uint32_t msg_filename_size,
		iSDIO_WLAN_HeaderRemoval_t headerRemoval) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SEND_HTTP_MESSAGE_BY_FILEを設定する。
	 *   - Argument 1にhostnameを設定する。
	 *   - Argument 2にmsg_filenameを設定する。
	 *   - Argument 3にheaderRemovalを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SEND_HTTP_MESSAGE_BY_FILE, 3);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, hostname, hostname_size);			// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, msg_filename, msg_filename_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &headerRemoval, 1);	        	// argument 3
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	添付ファイル付きHTTPメッセージ(ファイル)の送信
 *
 * @param[in]	*info				iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id				iSDIOコマンドシーケンスID
 * @param[in]	*hostname			ホスト名
 * @param[in]	hostname_size		ホスト名のバイト数
 * @param[in]	*msg_filename		メッセージファイル名
 * @param[in]	msg_filename_size	メッセージファイル名のバイト数
 * @param[in]	*apnd_filename		添付ファイル名
 * @param[in]	apnd_filename_size	添付ファイル名のバイト数
 * @param[in]	headerRemoval		ヘッダ付加情報(@ref iSDIO_WLAN_HeaderRemoval_e)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 指定されたホストに対して、HTTPメッセージ(ファイル)に添付ファイルを展開し、送信する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.4.6 SendHTTPFileByFile(hostName, messageFileName, appendFileName, headerRemoval)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SendHTTPFileByFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *msg_filename, uint32_t msg_filename_size,
		uint8_t *apnd_filename, uint32_t apnd_filename_size,
		iSDIO_WLAN_HeaderRemoval_t headerRemoval) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SEND_HTTP_FILE_BY_FILEを設定する。
	 *   - Argument 1にhostnameを設定する。
	 *   - Argument 2にmsg_filenameを設定する。
	 *   - Argument 3にapnd_filenameを設定する。
	 *   - Argument 4にheaderRemovalを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SEND_HTTP_FILE_BY_FILE, 4);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, hostname, hostname_size);			// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, msg_filename, msg_filename_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, apnd_filename, apnd_filename_size);    // argument 3
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &headerRemoval, 1);		        // argument 4
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	HTTPメッセージ(ファイル)の送信(SSL)
 *
 * @param[in]	*info				iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id				iSDIOコマンドシーケンスID
 * @param[in]	*hostname			ホスト名
 * @param[in]	hostname_size		ホスト名のバイト数
 * @param[in]	*msg_filename		メッセージファイル名
 * @param[in]	msg_filename_size	メッセージファイル名のバイト数
 * @param[in]	headerRemoval		ヘッダ付加情報(@ref iSDIO_WLAN_HeaderRemoval_e)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 指定されたホストに対して、HTTPメッセージ(ファイル)をSSLで送信する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.4.7 SendHTTPSSLMessageByFile(hostName, messageFileName, headerRemoval)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SendHTTPSSLMessageByFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *msg_filename, uint32_t msg_filename_size,
		iSDIO_WLAN_HeaderRemoval_t headerRemoval) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SEND_HTTP_SSL_MESSAGE_BY_FILEを設定する。
	 *   - Argument 1にhostnameを設定する。
	 *   - Argument 2にmsg_filenameを設定する。
	 *   - Argument 3にheaderRemovalを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SEND_HTTP_SSL_MESSAGE_BY_FILE, 3);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, hostname, hostname_size);			// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, msg_filename, msg_filename_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &headerRemoval, 1);		        // argument 3
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	添付ファイル付きHTTPメッセージ(ファイル)の送信(SSL)
 *
 * @param[in]	*info				iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id				iSDIOコマンドシーケンスID
 * @param[in]	*hostname			ホスト名
 * @param[in]	hostname_size		ホスト名のバイト数
 * @param[in]	*msg_filename		メッセージファイル名
 * @param[in]	msg_filename_size	メッセージファイル名のバイト数
 * @param[in]	*apnd_filename		添付ファイル名
 * @param[in]	apnd_filename_size	添付ファイル名のバイト数
 * @param[in]	headerRemoval		ヘッダ付加情報(@ref iSDIO_WLAN_HeaderRemoval_e)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 指定されたホストに対して、HTTPメッセージ(ファイル)に添付ファイルを展開し、SSLで送信する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.4.8 SendHTTPSSLFileByFile(hostName, messageFileName, appendFileName, headerRemoval)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SendHTTPSSLFileByFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *hostname, uint32_t hostname_size,
		uint8_t *msg_filename, uint32_t msg_filename_size,
		uint8_t *apnd_filename, uint32_t apnd_filename_size,
		iSDIO_WLAN_HeaderRemoval_t headerRemoval) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SEND_HTTP_SSL_FILE_BY_FILEを設定する。
	 *   - Argument 1にhostnameを設定する。
	 *   - Argument 2にmsg_filenameを設定する。
	 *   - Argument 3にapnd_filenameを設定する。
	 *   - Argument 4にheaderRemovalを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SEND_HTTP_SSL_FILE_BY_FILE, 4);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, hostname, hostname_size);			// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, msg_filename, msg_filename_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, apnd_filename, apnd_filename_size);	// argument 3
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &headerRemoval, 1);		        // argument 4
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	HTTPS接続用ルート証明書の設定
 *
 * @param[in]	*info				iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id				iSDIOコマンドシーケンスID
 * @param[in]	*certificate		証明書
 * @param[in]	certificate_size	証明書のバイト数
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * HTTPS接続のためのルート証明書の設定を行う。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.4.9 SetCertificate(certificate)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SetCertificate(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *certificate, uint32_t certificate_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SET_CERTIFICATIONを設定する。
	 *   - Argument 1にcertificateを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SET_CERTIFICATION, 1);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, certificate, certificate_size);	// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	HTTPS接続用ルート証明書(ファイル)の設定
 *
 * @param[in]	*info			iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id			iSDIOコマンドシーケンスID
 * @param[in]	*filename		証明書ファイル名
 * @param[in]	filename_size	証明書ファイル名のバイト数
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * HTTPS接続のためのルート証明書(ファイル)の設定を行う。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.4.10 SetCertificateByFile(certificateFileName)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SetCertificateByFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *filename, uint32_t filename_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SET_CERTIFICATE_BY_FILEを設定する。
	 *   - Argument 1にfilenameを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SET_CERTIFICATE_BY_FILE, 1);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, filename, filename_size);		// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	送信側としてのP2Pによる無線LAN接続の開始
 *
 * @param[in]	*info			iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id			iSDIOコマンドシーケンスID
 * @param[in]	*ssid			SSID
 * @param[in]	ssid_size		SSIDのバイト数
 * @param[in]	*ntwk_key		ネットワークキー
 * @param[in]	ntwk_key_size	ネットワークキーのバイト数(0の場合は暗号化なし)
 * @param[in]	encMode			暗号モード(@ref iSDIO_WLAN_EcnMode_e)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * P2Pによるファイル転送機能の送信側として、無線LANの接続を開始する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.6.1 StartP2PSender(ssid, networkKey, encMode)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_StartP2PSender(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *ssid, uint32_t ssid_size,
		uint8_t *ntwk_key, uint32_t ntwk_key_size,
		iSDIO_WLAN_EcnMode_t encMode) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_START_P2P_SENDERを設定する。
	 *   - Argument 1にssidを設定する。
	 *   - Argument 2にntwk_keyを設定する。
	 *   - Argument 3にencModeを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_START_P2P_SENDER, 3);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, ssid, ssid_size);			// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, ntwk_key, ntwk_key_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &encMode, 1);		        // argument 3
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	受信側としてのP2Pによる無線LAN接続の開始
 *
 * @param[in]	*info			iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id			iSDIOコマンドシーケンスID
 * @param[in]	*ssid			アクセスポイントのSSID
 * @param[in]	ssid_size		アクセスポイントのSSIDのバイト数
 * @param[in]	*ntwk_key		ネットワークキー
 * @param[in]	ntwk_key_size	ネットワークキーのバイト数(0の場合は暗号化なし)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * P2Pによるファイル転送機能の受信側として、無線LAN接続を開始する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.6.2 StartP2PReceiver(ssid, networkKey)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_StartP2PReceiver(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *ssid, uint32_t ssid_size,
		uint8_t *ntwk_key, uint32_t ntwk_key_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_START_P2P_RECEIVERを設定する。
	 *   - Argument 1にssidを設定する。
	 *   - Argument 2にntwk_keyを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_START_P2P_RECEIVER, 2);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, ssid, ssid_size);			// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, ntwk_key, ntwk_key_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	P2Pによるファイルの取得(受信側用)
 *
 * @param[in]	*info				iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id				iSDIOコマンドシーケンスID
 * @param[in]	*req_filename		要求ファイル名
 * @param[in]	req_filename_size	要求ファイル名のバイト数
 * @param[in]	*save_filename		保存ファイル名
 * @param[in]	save_filename_size	保存ファイル名のバイト数
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * P2Pによるファイル転送機能の受信側として、送信側に要求したファイルを受信し、
 * NANDメモリにファイルを保存する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.6.3 GetFile(requestFileName, saveFileName)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_GetFile(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *req_filename, uint32_t req_filename_size,
		uint8_t *save_filename, uint32_t save_filename_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_GET_FILEを設定する。
	 *   - Argument 1にreq_filenameを設定する。
	 *   - Argument 2にsave_filenameを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_GET_FILE, 2);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, req_filename, req_filename_size);		// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, save_filename, save_filename_size);	// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	P2Pにおける無線LAN IDリストの取得(送信側用)
 *
 * @param[in]	*info				iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id				iSDIOコマンドシーケンスID
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * P2Pによるファイル転送機能の送信側として、受信側のiSDIOカードのIDリストを取得する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.6.4 ReadIDList()
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_ReadIDList(
		iSDIO_INFO_t *info, uint32_t seq_id) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommandにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_READ_ID_LISTを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_READ_ID_LIST, 0);
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	P2Pにおける受信側のMACアドレスの選択(送信側用)
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	*mac		MACアドレス(6バイト)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * P2Pによるファイル転送機能の送信側として、受信側のiSDIOカードのMACアドレスを指定する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.6.5 SelectMAC(mac)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SelectMAC(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *mac) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SELECT_MACを設定する。
	 *   - Argument 1にmacを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SELECT_MAC, 1);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, mac, 6);						// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	P2Pにおける受信側のMACアドレスの指定解除(送信側用)
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	*mac		MACアドレス(6バイト)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * P2Pによるファイル転送機能の送信側として、受信側のiSDIOカードのMACアドレスの指定を解除する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.6.6 DeselectMAC(mac)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_DeselectMAC(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *mac) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_DESELECT_MACを設定する。
	 *   - Argument 1にmacを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_DESELECT_MAC, 1);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, mac, 6);					// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	P2Pにおける受信側の無線LAN IDの設定(受信側用)
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id		iSDIOコマンドシーケンスID
 * @param[in]	*id			受信側カードのID
 * @param[in]	id_size		受信側カードのIDのバイト数
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * P2Pによるファイル転送機能の受信側としての無線LAN IDを設定する。
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.6.7 SetID(id)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_SetID(
		iSDIO_INFO_t *info, uint32_t seq_id,
		uint8_t *id, uint32_t id_size) {

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SET_IDを設定する。
	 *   - Argument 1にidを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_SET_ID, 1);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, id, id_size);				// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	Shared Memory書き込み
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	addr		書き込みアドレス（0～2047）
 * @param[in]	len			データ長（1～2048）byte
 * @param[in]	*buf		書き込みデータ
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * Shared Memory（共有メモリ）へデータの書き込みを行う
 */
int32_t iSDIO_WLAN_WriteSharedMemory(iSDIO_INFO_t *info, uint32_t addr, uint32_t len, uint8_t *buf)
{
	/**
	 * @par 内部処理
	 */
	int32_t result = E_iSDIO_OK;
	uint8_t temp_buf[SD_HCXC_BLOCK_SIZE];
	uint32_t offset = addr;
	uint32_t rem_size = len;
	uint32_t write_size = 0;
	uint8_t cardver = 0;
	uint16_t cardsize = 0;
	uint32_t sharedmemorysize = 0;

	/**
	 * @par (1) 書き込みデータサイズの確認
	 * - カードバージョンを確認し、Shared Memoryのサイズを確認する
	 * - パラメータチェック
	 *   - addrとlenのパラメータチェックをする
	 */

	/*
	 * |0       511|512    1023|1024   1535|1536   2047|
	 * |    [0]    |    [1]    |    [2]    |    [3]    |
	 * |  512byte  |  512byte  |  512byte  |  512byte  |
	 */
	iSDIO_WLAN_GetFlashAirVersion(info, &cardver, &cardsize);
	if( (cardver == CID_NOT_FLASHAIR) && (cardsize == CID_CARD_SIZE_UNKNOWN) ){
		return E_iSDIO_DEVICE_ERROR;
	}
	else if(cardver == CID_CARDVERSION_W02){
		return E_iSDIO_DEVICE_ERROR;
	}
	else if(cardver == CID_CARDVERSION_W03){
		sharedmemorysize = iSDIO_WLAN_SHAREDMEMORY_SIZE_W03;
	}
	else{
		sharedmemorysize = iSDIO_WLAN_SHAREDMEMORY_SIZE_W04;
	}

	// addrチェック W03:512以上でエラー W04:2048以上でエラー
	if( addr >= sharedmemorysize ){
		return E_iSDIO_INVALID_PARAM;
	}
	// lenチェック W03:512超でエラー W04:2048超でエラー
	if( len > sharedmemorysize ){
		return E_iSDIO_INVALID_PARAM;
	}
	// addr + lenチェック W03:512超でエラー W04:2048超でエラー
	if( (addr + len) > sharedmemorysize ){
		return E_iSDIO_INVALID_PARAM;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - ドライバに送るデータを作る
	 * - iSDIO_WriteRegisterにより、iSDIOコマンドを発行しShared Memoryを書き出す
	 * - データは、512byteずつ書き込む
	 * - iSDIO_WriteRegister内で512byteに足らない分は0パディングするため、ここではデータを用意するだけとする。
	 */
	do{
		// 書き込み開始アドレスから、ブロックの境界までのバイト数をwrite_sizeに格納する
		write_size = SD_HCXC_BLOCK_SIZE - (offset % SD_HCXC_BLOCK_SIZE);
		// 残り書き込みデータサイズがブロック境界までのバイト数以下だった場合、
		// write_sizeのデータをrem_sizeに書き換える
		if( write_size >= rem_size ){
			write_size = rem_size;
		}
		memcpy(temp_buf, (buf + (len - rem_size)), write_size );

		result = iSDIO_WriteRegister( info, (iSDIO_WLAN_SHAREDMEMORY_START_ADDR + offset), write_size, temp_buf );
		if(result != E_iSDIO_OK){
			break;
		}

		rem_size = rem_size - write_size;
		offset = offset + write_size;
	}while(rem_size > 0);

	return result;
}

/**
 * @brief	Shared Memory読み込み
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	addr		読み出しアドレス（0～2047）
 * @param[in]	len			データ長（1～2048）byte
 * @param[out]	*buf		読み出しデータ
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * Shared Memory（共有メモリ）へデータの読み込みを行う
 *
 */
int32_t iSDIO_WLAN_ReadSharedMemory(iSDIO_INFO_t *info, uint32_t addr, uint32_t len, uint8_t *buf)
{
	/**
	 * @par 内部処理
	 */
	int32_t result = 0;
	int32_t i = 0;
	uint8_t temp_buf[SD_HCXC_BLOCK_SIZE];
	uint32_t start_block_pos = 0;
	uint32_t end_block_pos = 0;
	uint32_t offset = 0;
	uint32_t dst_offset = 0;
	uint32_t temp_len = len;
	uint8_t cardver = 0;
	uint16_t cardsize = 0;
	uint32_t sharedmemorysize = 0;

	/**
	 * @par (1) 読み出すデータサイズの確認
	 * - カードバージョンを確認し、Shared Memoryのサイズを確認する
	 * - パラメータチェック
	 *   - addrとlenのパラメータチェックをする。<br>
	 *     （addr+lenが2048byte超であればE_iSDIO_INVALID_PARAMを返す）
	 * - 読み出しアドレスとブロック数の確認
	 *   - addrとlenから読み出し位置と読み出しブロック数を確認する<br>
	 *     読み出しは512byte単位で行われる。
	 */

	/*
	 * |0       511|512    1023|1024   1535|1536   2047|
	 * |    [0]    |    [1]    |    [2]    |    [3]    |
	 * |  512byte  |  512byte  |  512byte  |  512byte  |
	 */
	iSDIO_WLAN_GetFlashAirVersion(info, &cardver, &cardsize);
	if( (cardver == CID_NOT_FLASHAIR) && (cardsize == CID_CARD_SIZE_UNKNOWN) ){
		return E_iSDIO_DEVICE_ERROR;
	}
	else if(cardver == CID_CARDVERSION_W02){
			return E_iSDIO_DEVICE_ERROR;
	}
	else if(cardver == CID_CARDVERSION_W03){
		sharedmemorysize = iSDIO_WLAN_SHAREDMEMORY_SIZE_W03;
	}
	else{
		sharedmemorysize = iSDIO_WLAN_SHAREDMEMORY_SIZE_W04;
	}

	// addrチェック W03:512以上でエラー W04:2048以上でエラー
	if( addr >= sharedmemorysize ){
		return E_iSDIO_INVALID_PARAM;
	}
	// lenチェック W03:512超でエラー W04:2048超でエラー
	if( len > sharedmemorysize ){
		return E_iSDIO_INVALID_PARAM;
	}
	// addr + lenチェック W03:512超でエラー W04:2048超でエラー
	if( (addr + len) > sharedmemorysize ){
		return E_iSDIO_INVALID_PARAM;
	}
	else{
		start_block_pos = (addr / SD_HCXC_BLOCK_SIZE);
		end_block_pos = ( (addr + len - 1) / SD_HCXC_BLOCK_SIZE );
		offset = addr % SD_HCXC_BLOCK_SIZE;
		i = start_block_pos;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_ReadRegisterにより、iSDIOコマンドを発行しShared Memoryを読み出す
	 * - 読み出したデータをbufに格納する
	 */
	do{
		result = iSDIO_ReadRegister(info, (iSDIO_WLAN_SHAREDMEMORY_START_ADDR + (SD_HCXC_BLOCK_SIZE * i)), SD_HCXC_BLOCK_SIZE, temp_buf);
		if(result != E_iSDIO_OK){
			break;
		}

		// ブロックまたぎ
		if( (offset + temp_len) > SD_HCXC_BLOCK_SIZE){
			memcpy( buf + dst_offset, (temp_buf + offset), (SD_HCXC_BLOCK_SIZE - offset));
			temp_len = temp_len - (SD_HCXC_BLOCK_SIZE - offset);
			dst_offset = dst_offset + (SD_HCXC_BLOCK_SIZE - offset);
		}
		else{
			memcpy( buf + dst_offset, (temp_buf + offset), temp_len );
		}
		// 2回目から、先頭からデータを読み出すためoffsetは0にする
		offset = 0;
		i++;
	}while(start_block_pos + i <= end_block_pos);

	return result;
}

/**
 * @brief	CIDからFlashAirのバージョンと容量確認
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[out]	*cardver	カードバージョン
 * @param[out]	*cardsize	カード容量（GByte）
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * CIDからFlashAirのバージョンと容量を読み出す。
 * cardver、cardsizeとFlashAirのバージョンと容量の関係は以下のテーブルの通り。
 *
@table "cardver、cardsizeとFlashAirのバージョンと容量の関係"
+---------+----------+----------------------------------------+
| cardver | cardsize | バージョンと容量                       |
+=========+==========+========================================+
| 2       | 8        | FlashAir W02 8G                        |
+---------+----------+----------------------------------------+
| 2       | 16       | FlashAir W02 16G                       |
+---------+----------+----------------------------------------+
| 2       | 32       | FlashAir W02 32G                       |
+---------+----------+----------------------------------------+
| 3       | 8        | FlashAir W03 8G                        |
+---------+----------+----------------------------------------+
| 3       | 16       | FlashAir W03 16G                       |
+---------+----------+----------------------------------------+
| 3       | 32       | FlashAir W03 32G                       |
+---------+----------+----------------------------------------+
| 4       | 16       | FlashAir W04 16G                       |
+---------+----------+----------------------------------------+
| 4       | 32       | FlashAir W04 32G                       |
+---------+----------+----------------------------------------+
| 4       | 64       | FlashAir W04 64G                       |
+---------+----------+----------------------------------------+
| 255     | 0以外    | バージョン不明でcardsize容量のFlashAir |
+---------+----------+----------------------------------------+
| 255     | 0        | バージョン、容量不明のFlashAir         |
+---------+----------+----------------------------------------+
| 0       | 0        | FlashAirではない                       |
+---------+----------+----------------------------------------+
@endtable
 *
 * @attention 本関数はSDカードスロットが1スロットのシステムで、デバイスファイルが/dev/mmcblk0にある場合に使用可能です。
 */
int32_t iSDIO_WLAN_GetFlashAirVersion(iSDIO_INFO_t *info, uint8_t *cardver, uint16_t *cardsize)
{
	/**
	 * @par 内部処理
	 */
	FILE *fp;
	char buf[33];

	buf[32]=0;

	/**
	 * @par (1) CIDを読み出す
	 * - LinuxのシステムクラスからSDカードのCIDを読み出す
	 *   - /sys/class/mmc_host/mmc0/mmc0:＊/cid
	 */
	fp = popen("cat /sys/class/mmc_host/mmc0/mmc0:" "*" "/cid", "r");
	if(fp == NULL){
		return E_iSDIO_DEVICE_ERROR;
	}
	fread(buf, 1, 32, fp);
	pclose(fp);

	/**
	 * @par (2) CIDを解析する
	 * - CIDを解析し、カードのバージョン、容量を読み出す。
	 * - 解析する値は以下の通り（値の詳細は、@ref isdio_wlan_api.h を参照）
	 *   - PNM：先頭から6byteの位置から開始、サイズは4byte
	 *     - FlashAirであるか判別する
	 *   - PRV：先頭から16byteの位置から開始、サイズは2byte
	 *     - カードのバージョンを判別する
	 *   - PNM：先頭から10byteの位置から開始、サイズは6byte
	 *     - カードのサイズを判別する
	 */
	if(strncmp(&buf[CID_PNM_FLASHAIR_POS], CID_PNM_FLASHAIR, CID_PNM_FLASHAIR_SIZE) == 0){
		// flashairカードである

		if(strncmp(&buf[CID_PRV_POS], CID_PRV_W02_8G16G32G, CID_PRV_SIZE) == 0){
			// W02カードである
			*cardver = CID_CARDVERSION_W02;
		}
		else if(strncmp(&buf[CID_PRV_POS], CID_PRV_W03_8G, CID_PRV_SIZE) == 0){
			// W03カードである
			*cardver = CID_CARDVERSION_W03;
		}
		else if(strncmp(&buf[CID_PRV_POS], CID_PRV_W03_16G32G, CID_PRV_SIZE) == 0){
			// W03カードである
			*cardver = CID_CARDVERSION_W03;
		}
		else if(strncmp(&buf[CID_PRV_POS], CID_PRV_W04_16G, CID_PRV_SIZE) == 0){
			// W04カードである
			*cardver = CID_CARDVERSION_W04;
		}
		else if(strncmp(&buf[CID_PRV_POS], CID_PRV_W04_32G64G, CID_PRV_SIZE) == 0){
			// W04カードである
			*cardver = CID_CARDVERSION_W04;
		}
		else{
			// バージョンが不明なFlashAir
			*cardver = CID_CARDVERSION_UNKNOWN;
		}

		if(strncmp(&buf[CID_PNM_CARD_SIZE_POS], CID_PNM_CARD_SIZE_08G, CID_PNM_CARD_SIZE_SIZE) == 0){
			//8Gカードである
			*cardsize = CID_CARD_SIZE_8G;
		}
		else if(strncmp(&buf[CID_PNM_CARD_SIZE_POS], CID_PNM_CARD_SIZE_16G, CID_PNM_CARD_SIZE_SIZE) == 0){
			//16Gカードである
			*cardsize = CID_CARD_SIZE_16G;
		}
		else if(strncmp(&buf[CID_PNM_CARD_SIZE_POS], CID_PNM_CARD_SIZE_32G, CID_PNM_CARD_SIZE_SIZE) == 0){
			// 32Gカードである
			*cardsize = CID_CARD_SIZE_32G;
		}
		else if(strncmp(&buf[CID_PNM_CARD_SIZE_POS], CID_PNM_CARD_SIZE_64G, CID_PNM_CARD_SIZE_SIZE) == 0){
			// 64Gカードである
			*cardsize = CID_CARD_SIZE_64G;
		}
		else{
			// 容量不明である
			*cardsize = CID_CARD_SIZE_UNKNOWN;
		}
	}
	else{
		// FlashAirではない
		*cardver = CID_NOT_FLASHAIR;
		*cardsize = CID_CARD_SIZE_UNKNOWN;
	}

	return E_iSDIO_OK;
}
/* NSW add 2017.09.22 start */
/**
 * @brief	添付ファイル付きHTTPメッセージ(ファイル)の送信(SSL)
 *
 * @param[in]	*info			iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id			iSDIOコマンドシーケンスID
 * @param[in]	*hostname		ホスト名
 * @param[in]	hostname_size		ホスト名のバイト数
 * @param[in]	msg_type		HTTPメッセージタイプ
 * @param[in]	*message		メッセージ(ファイル名)
 * @param[in]	message_size	メッセージ(ファイル名)のバイト数
 * @param[in]	*apnd_filename	添付ファイル名
 * @param[in]	apnd_filename_size	添付ファイル名のバイト数
 * @param[in]	headerRemoval		ヘッダ付加情報(@ref iSDIO_WLAN_HeaderRemoval_e)
 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 指定されたホストに対して、HTTPメッセージ(ファイル)に添付ファイルを展開し、SSLで送信する。
 *
 * @see
 *   - iSDIO Simplified Specification Version 1.10
 *     - 2.2.2.3 iSDIO Command Response Data
 *   - iSDIO Simplified Specification Version 1.10
 *     - 4.4.1 SendHTTPMessageByRegister(hostName, message)
 *     - 4.4.2 SendHTTPFileByRegister(hostName, appendFileName, message)
 *     - 4.4.3 SendHTTPSSLMessageByRegister(hostName, message)
 *     - 4.4.4 SendHTTPSSLFileByRegister(hostName, appendFileName, message)
 *     - 4.4.5 SendHTTPMessageByFile(hostName, messageFileName, headerRemoval)
 *     - 4.4.6 SendHTTPFileByFile(hostName, messageFileName, appendFileName, headerRemoval)
 *     - 4.4.7 SendHTTPSSLMessageByFile(hostName, messageFileName, headerRemoval)
 *     - 4.4.8 SendHTTPSSLFileByFile(hostName, messageFileName, appendFileName, headerRemoval)
 *     - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_Request(
		iSDIO_INFO_t *info, uint32_t seq_id,
		iSDIO_WLAN_httpType_t host_type,
		uint8_t *hostname, uint32_t hostname_size,
		iSDIO_WLAN_MessageType_t msg_type,
		uint8_t *message, uint32_t message_size,
		uint8_t *apnd_filename, uint32_t apnd_filename_size,
		iSDIO_WLAN_HeaderRemoval_t headerRemoval) 
{

	/**
	 * @par 内部処理
	 */
	int32_t result=E_iSDIO_INVALID_PARAM;
	if((hostname==NULL) || (hostname_size==0)){
		goto exit;
	}
	//if( (strncmp((const char *)hostname,"https://",8)==0) ) {
	if(host_type) {
		if(msg_type) {
			/**
			 * @par FileからHTTPメッセージ取得
			 */
			if((apnd_filename!=NULL) && (apnd_filename_size!=0)) {
				// 添付ファイル付きHTTPメッセージ(ファイル)の送信(SSL)
				result = iSDIO_WLAN_SendHTTPSSLFileByFile(
							info, seq_id,
							hostname, hostname_size,
							message, message_size,
							apnd_filename, apnd_filename_size,
							headerRemoval);
			}
			else {
				// HTTPメッセージ(ファイル)の送信(SSL)
				result = iSDIO_WLAN_SendHTTPSSLMessageByFile(
							info, seq_id,
							hostname, hostname_size,
							message, message_size,
							headerRemoval);
			}
		}
		else {
			if((apnd_filename!=NULL) && (apnd_filename_size!=0)) {
				// 添付ファイル付きHTTPメッセージの送信(SSL)
				result = iSDIO_WLAN_SendHTTPSSLFileByRegister(
							info, seq_id,
							hostname, hostname_size,
							apnd_filename, apnd_filename_size,
							message, message_size);
			}
			else {
				// HTTPメッセージの送信(SSL)
				result = iSDIO_WLAN_SendHTTPSSLMessageByRegister(
							info, seq_id,
							hostname, hostname_size,
							message, message_size);
			}
		}
	}
	else {
		if(msg_type) {
			/**
			 * @par FileからHTTPメッセージ取得
			 */
			if((apnd_filename!=NULL) && (apnd_filename_size!=0)) {
				// 添付ファイル付きHTTPメッセージ(ファイル)の送信
				result = iSDIO_WLAN_SendHTTPFileByFile(
							info, seq_id,
							hostname, hostname_size,
							message, message_size,
							apnd_filename, apnd_filename_size,
							headerRemoval);
			}
			else {
				// HTTPメッセージ(ファイル)の送信
				result = iSDIO_WLAN_SendHTTPMessageByFile(
							info, seq_id,
							hostname, hostname_size,
							message, message_size,
							headerRemoval);
			}
		}
		else {
			if((apnd_filename!=NULL) && (apnd_filename_size!=0)) {
				// 添付ファイル付きHTTPメッセージの送信
				result = iSDIO_WLAN_SendHTTPFileByRegister(
							info, seq_id,
							hostname, hostname_size,
							apnd_filename, apnd_filename_size,
							message, message_size);
			}
			else {
				// HTTPメッセージの送信
				result = iSDIO_WLAN_SendHTTPMessageByRegister(
							info, seq_id,
							hostname, hostname_size,
							message, message_size);
			}
		}
	}

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	ブリッジモードを起動
 *
 * @param[in]	*info				iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id				iSDIOコマンドシーケンスID
 * @param[in]	*apssid				AirNetから接続するためのSSID ※ 33文字以上：コマンドパラメータエラー
 * @param[in]	*apnetworkKey		AirNetから接続するためのネットワークキー ※ 65文字以上：コマンドパラメータエラー
 * @param[in]	encMode				暗号モード(@ref iSDIO_WLAN_EcnMode_e)
 * @param[in]	*brgssid			TopNetへ接続するSSID ※ 33文字以上：コマンドパラメータエラー
 * @param[in]	*brgnetworkKey		TopNetへ接続するネットワークキー ※ 65文字以上：コマンドパラメータエラー

 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * ブリッジモードを起動
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 *   - 4.6.7 SetID(id)
 *   - 6.2.2.4 Command Processing Time
 */
int32_t iSDIO_WLAN_Bridge(
	iSDIO_INFO_t *info, uint32_t seq_id, 
	uint8_t *apssid, uint32_t apssid_size,
	uint8_t *apnetworkKey, uint32_t apnetworkKey_size,
	iSDIO_WLAN_EcnMode_t  encMode, 
	uint8_t *brgssid, uint32_t brgssid_size,
	uint8_t *brgnetworkKey, uint32_t brgnetworkKey_size){

	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_BRIDGEを設定する。
	 *   - Argument 1にapssidを設定する。
	 *   - Argument 2にapnetworkKeyを設定する。
	 *   - Argument 3にencModeを設定する。
	 *   - Argument 4にbrgssidを設定する。
	 *   - Argument 5にbrgnetworkKeyを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_BRIDGE, 5);
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, apssid, apssid_size);					// argument 1
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, apnetworkKey, apnetworkKey_size);		// argument 2
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, &encMode, 1);							// argument 3
	if (result != E_iSDIO_OK) {
		goto exit;
	}
	result = iSDIO_SetArgument(info, brgssid, brgssid_size);				// argument 4
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	result = iSDIO_SetArgument(info, brgnetworkKey, brgnetworkKey_size);	// argument 5
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	ブリッジモード情報を取得する。
 *
 * @param[in]	*info	iSDIOカード制御情報へのポインタ
 * @param[in]	seq_id	iSDIOコマンドシーケンスID

 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * ブリッジモード情報を取得する。
 *
 * @see
 */
int32_t iSDIO_WLAN_BridgeGetInfoByRegister(
	iSDIO_INFO_t *info, uint32_t seq_id){
	/**
	 * @par 内部処理
	 */
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommandにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_BRIDGE_GET_INFO_BY_REGISTERを設定する。
	 */
	result = iSDIO_SetWriteCommand(info, seq_id, iSDIO_WLAN_BRIDGE_GET_INFO_BY_REGISTER, 0);
	if (result != E_iSDIO_OK) {
		goto exit;
	}

	/**
	 * @par (2) iSDIOコマンドの発行
	 * - iSDIO_WriteCommandWriteDataにより、iSDIOコマンド発行する。
	 */
	result = iSDIO_WriteCommandWriteData(info);

	/**
	 * @par (3) 終了処理
	 * - 実行結果を返す。
	 */
exit:
	return result;
}

/**
 * @brief	Scan後のAP数を取得する
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[out]	*num		AP数

 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * Scan後のAP数を取得する
 *
 * @see
 *   Wireless LAN Simplified Addendum Version 1.10
 */
int32_t iSDIO_WLAN_GetSSIDs(iSDIO_INFO_t *info, uint8_t *num)
{
	/**
	 * @par 内部処理
	 */
	int32_t result=E_iSDIO_OK;
	iSDIO_CommandResponseDataHeader_t *p_hd;
	iSDIO_WLAN_SSIDList_t *p_ssid;
	/**
	 * @par (1) Command Response Dataの読み込み
	 * - iSDIO_ReadCommandResponseDataにより、SSID数を取得する。
	 */
	p_hd = iSDIO_ReadCommandResponseData(info);
	if (p_hd == NULL){
		*num = 0;
		return result;		
	}
	p_ssid = (iSDIO_WLAN_SSIDList_t*)((uint8_t*)p_hd + sizeof(iSDIO_CommandResponseDataHeader_t));
	*num = p_ssid->ssid_num;
	/**
	 * @par (2) 終了処理
	 * - 実行結果を返す。
	 */
	return result;
}


/**
 * @brief	アクセスポイント名を取得
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[in]	number		指定番号(有効範囲は0~(Max-1))
 * @param[out]	*ssid		アクセスポイント名

 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * 指定番号のアクセスポイント名を取得する
 *
 * @see
 */
int32_t iSDIO_WLAN_GetSSID(
	iSDIO_INFO_t *info, 
	uint8_t number , uint8_t *ssid){
	/**
	 * @par 内部処理
	 */
	//iSDIO_CommandResponseStatus_t *p_st;
	iSDIO_CommandResponseDataHeader_t *p_hd;
	iSDIO_WLAN_SSIDList_t *p_ssid;
	/**
	 * @par (1) Command Response Dataの読み込み
	 * - iSDIO_ReadCommandResponseDataにより、SSID数を取得する。
	 */
	p_hd = iSDIO_ReadCommandResponseData(info);
	if (p_hd == NULL){
		ssid = NULL;
		return E_iSDIO_UNKNOWN_ERROR;		
	}
	p_ssid = (iSDIO_WLAN_SSIDList_t*)((uint8_t*)p_hd + sizeof(iSDIO_CommandResponseDataHeader_t));
	if((number > (p_ssid->ssid_num-1)) || (ssid==NULL))
	{
		return E_iSDIO_INVALID_PARAM;
	}
	memcpy(ssid, p_ssid->items[number].ssid, 32);
	/**
	 * @par (2) 終了処理
	 * - 実行結果を返す。
	 */
	return E_iSDIO_OK;
}

/**
 * @brief	Status Registerの出力データを取得
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[out]	*getbuf		取得バッファポインタ

 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * Status Registerの出力データを取得
 *
 * @see
 */
int32_t iSDIO_WLAN_GetStatusData(
	iSDIO_INFO_t *info, 
	uint8_t *getbuf){
	/**
	 * @par 内部処理
	 */
	iSDIO_StatusRegister_t *p_st_r;

	/**
	 * @par (1) Status Register情報の読み込み
	 * - iSDIO_ReadStatusRegisterにより、Status Registerの出力データを取得する。
	 */
	p_st_r =  iSDIO_ReadStatusRegister(info);

	/**
	 * @par (2) 終了処理
	 * - 実行結果を返す。
	 */
	//getbuf = (uint8_t*)p_st_r;
	memcpy(getbuf, p_st_r, 512);
	return E_iSDIO_OK;
}

/**
 * @brief	Response Data Register Portの出力データを取得
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[out]	*getbuf		取得バッファポインタ

 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * Response Data Register Portの出力データを取得
 *
 * @see
 */
int32_t iSDIO_WLAN_GetResponseData(
	iSDIO_INFO_t *info, 
	uint8_t *getbuf)
{
	/**
	 * @par 内部処理
	 */
	//iSDIO_CommandResponseStatus_t *p_rsp;
	//iSDIO_CommandResponseDataHeader_t *p_rsp;
	int32_t result;

	/**
	 * @par (1) iSDIOコマンドの生成
	 * - iSDIO_SetWriteCommand、iSDIO_SetArgumentにより、iSDIOコマンドバッファに以下を設定する。
	 *   - コマンドIDにiSDIO_WLAN_SET_IDを設定する。
	 *   - Argument 1にidを設定する。
	 */
	//p_rsp = iSDIO_ReadCommandResponseStatus(info);
	//p_rsp = iSDIO_ReadCommandResponseData(info);
	result = iSDIO_ReadRegister(info, iSDIO_RESPONSE_DATA_REGISTER_ADDRESS, 512, info->buf);

	/**
	 * @par (2) 終了処理
	 * - 実行結果を返す。
	 */
	memcpy(getbuf, info->buf, 512);
	return result;
}

/**
 * @brief	バージョン情報を取得
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[out]	*getbuf		取得バッファポインタ

 *
 * @retval	E_iSDIO_OK	正常終了
 * @retval	その他		エラー発生
 *
 * バージョン情報を取得
 *
 * @see
 */
int32_t iSDIO_WLAN_GetVersion(iSDIO_INFO_t *info, uint8_t *getbuf){
	/**
	 * @par 内部処理
	 */
	int32_t result;
	iSDIO_StatusRegister_t *p_st_r;

	/**
	 * @par (1) パラメータチェック
	 * - getbufがNULLであればE_iSDIO_INVALID_PARAMを返す。
	 */
	if (getbuf == NULL) {
		return E_iSDIO_INVALID_PARAM;
	}

	/**
	 * @par (2) Version情報の読み込み
	 * iSDIO_ReadStatusRegisterにより、Version情報を読み込む。
	 * 読み込みに成功した場合は、info->bufのアドレスを返し、失敗した場合は、NULLを返す。
	 */
	p_st_r =  iSDIO_ReadStatusRegister(info);
	if(p_st_r != NULL) {
		memcpy(getbuf, &p_st_r->app_status[0xf0],16);
		result = E_iSDIO_OK;
	}
	return result;
}

/**
 * @brief	FA_Api_WaitResponseの待機時間を設定
 *
 * @param[in]	timef		Response待機のタイムアウト値

 *
 * @retval	
 *
 * FA_Api_WaitResponseの待機時間を設定
 *
 * @see
 */
void iSDIO_WLAN_SetWaitResponseTime(uint32_t time){
	/**
	 * @par (1) Response待機のタイムアウト値更新
	 * - WaitResponseTimeを更新
	 */
	WaitResponseTime = time / 20;
}

/**
 * @brief	WLAN接続をチェック
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[out]	*connect	接続状態

 *
 * @retval	
 *
 * WLAN接続をチェック
 *
 * @see
 */
int32_t iSDIO_WLAN_Check_WLANConnect(iSDIO_INFO_t *info, iSDIO_WLAN_Connect_t *connect){
	/**
	 * @par 内部処理
	 */
	iSDIO_StatusRegister_t *p_st_r;

	/**
	 * @par (1) Status Register情報の読み込み
	 * - iSDIO_ReadStatusRegisterにより、Status Registerの出力データを取得する。
	 */
	p_st_r =  iSDIO_ReadStatusRegister(info);
	if(p_st_r == NULL){
		*connect = 0;
		return E_iSDIO_DEVICE_ERROR;
	}
	/**
	 * @par (2) 終了処理
	 * - WLAN接続状態を取得し、実行結果を返す。
	 */
	if((p_st_r->app_status[iSDIO_STATUS_REGISTER_MAP_WLAN] & iSDIO_ST_REG_APPST_CONNECTED) == 0x00){
		*connect = iSDIO_WLAN_NO_CONNECTION;
	}
	else{
		*connect = iSDIO_WLAN_CONNECTED;
	}
	return E_iSDIO_OK;
}

/**
 * @brief	WLAN On/Off状態をチェック
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[out]	*onoff		無線LAN動作状態

 *
 * @retval	
 *
 * WLAN On/Off状態をチェック
 *
 * @see
 */
int32_t iSDIO_WLAN_Check_WLAN(iSDIO_INFO_t *info, iSDIO_WLAN_OnOFF_t *onoff){
	/**
	 * @par 内部処理
	 */
	iSDIO_StatusRegister_t *p_st_r;

	/**
	 * @par (1) Status Register情報の読み込み
	 * - iSDIO_ReadStatusRegisterにより、Status Registerの出力データを取得する。
	 */
	p_st_r =  iSDIO_ReadStatusRegister(info);
	if(p_st_r == NULL){
		*onoff = 0;
		return E_iSDIO_DEVICE_ERROR;
	}
	/**
	 * @par (2) 終了処理
	 * - WLAN接続状態を取得し、実行結果を返す。
	 */
	if((p_st_r->app_status[iSDIO_STATUS_REGISTER_MAP_WLAN] & iSDIO_ST_REG_APPST_ID) == 0x00){
		*onoff = iSDIO_WLAN_OFF;
	}
	else{
		*onoff = iSDIO_WLAN_ON;
	}
	return E_iSDIO_OK;
}

/**
 * @brief	Status Register “WLAN”データを取得
 *
 * @param[in]	*info		iSDIOカード制御情報へのポインタ
 * @param[out]	*para		WLANデータ

 *
 * @retval	
 *
 * Status Register “WLAN”データを取得
 *
 * @see
 */
int32_t iSDIO_WLAN_Get_WLAN_Status(iSDIO_INFO_t *info, uint8_t *para){
	/**
	 * @par 内部処理
	 */
	iSDIO_StatusRegister_t *p_st_r;

	/**
	 * @par (1) Status Register情報の読み込み
	 * - iSDIO_ReadStatusRegisterにより、Status Registerの出力データを取得する。
	 */
	p_st_r =  iSDIO_ReadStatusRegister(info);
	if(p_st_r == NULL){
		para = NULL;
		return E_iSDIO_DEVICE_ERROR;
	}
	/**
	 * @par (2) 終了処理
	 * - WLAN接続状態を取得し、実行結果を返す。
	 */
	*para = p_st_r->app_status[iSDIO_STATUS_REGISTER_MAP_WLAN];
	return E_iSDIO_OK;
}
/* NSW add 2017.09.22 end */
