/**
 * @file isdioreg.c
 * @brief isdioコマンド作成
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

#include "../inc/mmc.h"
#include "../inc/isdioreg.h"

/**
 * - プロトタイプ宣言
 */
static __u32 make_cmd48_arg(__u32 addr, __u32 len, __u8 fno);
static __u32 make_cmd49_arg(__u32 addr, __u32 len, __u8 fno);
static __u32 make_cmd58_arg(__u32 addr, __u32 buc, __u8 fno);
static __u32 make_cmd59_arg(__u32 addr, __u32 buc, __u8 fno);
int iSDIOREG_read_ext_reg(int fd, __u8 fno, __u32 ext_address, __u8 *pdata, __u32 block_num, __u32 len);
int iSDIOREG_write_ext_reg(int fd, __u8 fno, __u32 ext_address, const __u8 *pdata, __u32 block_num, __u32 len);
int iSDIOREG_open_ext_reg(char *devname);
void iSDIOREG_close_ext_reg(int fd);

/*---------------------------------------------------------------------------*/
// make_cmd48_arg()
/*---------------------------------------------------------------------------*/
/**
 * @brief cmd48のSD Command Argumentを作成する
 *
 * @param[in]	addr		address of extension register space
 * @param[in]	len 		effective length of a page(0...512)
 * @param[in]	fno 		function number
 *
 * @return		cmd48のSD Command Argument
 *
 * @par 概要
 *		cmd48のSD Command Argumentを作成する
 */
/*---------------------------------------------------------------------------*/
static __u32 make_cmd48_arg(__u32 addr, __u32 len, __u8 fno)
{
	/**
	 * - response data register（0x200）をアクセスする場合は、lenには0を指定する。
	 * （Part 1 Physical Layer Specification Ver.5.00 P.177 5.7.2.1 Extension Register Read Command(Single Block参照)
	 */
	if (addr == iSDIOREG_RESPONSE_DATA_REGISTER_ADDRESS){
		len = 0;
	}
	else{
		if(len != 0){
			len = len - 1;
		}
	}

	return (1<<31) | ((fno & 0x7) << 28) | ((addr & 0x1FFFF) << 9) | len;
}

/*---------------------------------------------------------------------------*/
// make_cmd49_arg()
/*---------------------------------------------------------------------------*/
/**
 * @brief cmd49のSD Command Argumentを作成する
 *
 * @param[in]	addr		address of extension register space
 * @param[in]	len 		effective length of a page(0...512)
 * @param[in]	fno 		function number
 *
 * @return		cmd49のSD Command Argument
 *
 * @par 概要
 *		cmd49のSD Command Argumentを作成する
 */
/*---------------------------------------------------------------------------*/
static __u32 make_cmd49_arg(__u32 addr, __u32 len, __u8 fno)
{
	/**
	 * - write register address（0x000）をアクセスする場合は、lenには0を指定する。
	 * （Part 1 Physical Layer Specification Ver.5.00 P.179 5.7.2.2 Extension Register Write Command(Single Block参照)
	 */
	if (addr == iSDIOREG_COMMAND_WRITE_REGISTER_PORT_ADDRESS){
		len = 0;
	}
	else{
		if(len != 0){
			len = len - 1;
		}
	}

	return (1<<31) | ((fno & 0x7) << 28) | ((addr & 0x1FFFF) << 9) | len;
}

/*---------------------------------------------------------------------------*/
// make_cmd58_arg()
/*---------------------------------------------------------------------------*/
/**
 * @brief cmd58のSD Command Argumentを作成する
 *
 * @param[in]	addr		address of extension register space
 * @param[in]	buc 		Block Unit Count(1...512)
 * @param[in]	fno 		function number
 *
 * @return		cmd58のSD Command Argument
 *
 * @par 概要
 *		cmd58のSD Command Argumentを作成する
 */
/*---------------------------------------------------------------------------*/
static __u32 make_cmd58_arg(__u32 addr, __u32 buc, __u8 fno)
{
	buc = buc - 1;

	return (1<<31) | ((fno & 0x7) << 28) | ((addr & 0x1FFFF) << 9) | buc;
}

/*---------------------------------------------------------------------------*/
// make_cmd59_arg()
/*---------------------------------------------------------------------------*/
/**
 * @brief cmd59のSD Command Argumentを作成する
 *
 * @param[in]	addr		address of extension register space
 * @param[in]	buc 		Block Unit Count(1...512)
 * @param[in]	fno 		function number
 *
 * @return		cmd59のSD Command Argument
 *
 * @par 概要
 *		cmd59のSD Command Argumentを作成する
 */
/*---------------------------------------------------------------------------*/
static __u32 make_cmd59_arg(__u32 addr, __u32 buc, __u8 fno)
{
	buc = buc - 1;

	return (1<<31) | ((fno & 0x7) << 28) | ((addr & 0x1FFFF) << 9) | buc;
}

/*---------------------------------------------------------------------------*/
// read_ext_reg()
/*---------------------------------------------------------------------------*/
/**
 * @brief 拡張レジスタ情報を読み込む
 *
 * @param[in]	fd			デバイスハンドル
 * @param[in]	fno 		function number
 * @param[in]	ext_address address of extension register space
 * @param[out]	pdata		読み込みデータバッファ
 * @param[in]	block_num	ブロック数(0 or 1)
 * @param[in]	len 		effective length of a page(1...512)
 *
 * @retval		E_SD_iSDIOREG_OK			   正常終了
 * @retval		E_SD_iSDIOREG_ERR_PARAM 	   パラメータエラー
 * @retval		E_SD_iSDIOREG_ERR_DEVICE	   デバイスエラー
 *
 * @par 概要
 *		拡張レジスタ領域を指定サイズとブロック数分、データバッファへ読み込む\n
 *		block_numの0はシングルブロック転送、1以上はマルチブロック転送を表す。
 *		FlashAirのiSDIOコマンドはマルチブロック転送に対応していないため、0を指定してください。
 *		マルチブロック転送を使用する場合は、lenの値は無視されます。
 */
/*---------------------------------------------------------------------------*/
int iSDIOREG_read_ext_reg(int fd, __u8 fno, __u32 ext_address, __u8 *pdata, __u32 block_num, __u32 len)
{
	struct mmc_ioc_cmd idata;

	// シングル・マルチ共通設定
	memset(&idata, 0, sizeof(idata));
	idata.write_flag = 0;
	idata.flags = MMC_RSP_R1 | MMC_CMD_ADTC;
	idata.blksz = 512;

	// block_numが0のときはシングルブロック転送
	if(block_num == 0){
		memset(pdata, 0, sizeof(__u8) * (block_num + 1) * len);
		idata.opcode = 48;
		idata.arg = make_cmd48_arg(ext_address, len, fno);
		idata.blocks = block_num + 1;
	}
	// block_numが1以上のときはマルチブロック転送
	else{
		len = 512;
		memset(pdata, 0, sizeof(__u8) * block_num * len);
		idata.opcode = 58;
		idata.arg = make_cmd58_arg(ext_address, block_num, fno);
		idata.blocks = block_num;
	}

	mmc_ioc_cmd_set_data(idata, pdata);

	return ioctl(fd, MMC_IOC_CMD, &idata);
}

/*---------------------------------------------------------------------------*/
// int write_ext_reg()
/*---------------------------------------------------------------------------*/
/**
 * @brief 拡張レジスタ情報を書き込む
 *
 * @param[in]	fd	 		デバイスハンドル
 * @param[in]	fno 		function number
 * @param[in]	ext_address address of extension register space
 * @param[in]	pdata		書き込みデータバッファ
 * @param[in]	block_num	ブロック数(0 or 1)
 * @param[in]	len 		effective length of a page(1...512)
 *
 * @retval		E_SD_iSDIOREG_OK			   正常終了
 * @retval		E_SD_iSDIOREG_ERR_PARAM 	   パラメータエラー
 * @retval		E_SD_iSDIOREG_ERR_DEVICE	   デバイスエラー
 *
 * @par 概要
 *		拡張レジスタ領域を指定サイズとブロック数分、データバッファを書き込む\n
 *		block_numの0はシングルブロック転送、1以上はマルチブロック転送を表す。
 *		FlashAirのiSDIOコマンドはマルチブロック転送に対応していないため、0を指定してください。
 */
/*---------------------------------------------------------------------------*/
int iSDIOREG_write_ext_reg(int fd, __u8 fno, __u32 ext_address, const __u8 *pdata, __u32 block_num, __u32 len)
{
	struct mmc_ioc_cmd idata;

	memset(&idata, 0, sizeof(idata));

	// シングル・マルチ共通設定
	idata.write_flag = 1;
	idata.flags = MMC_RSP_R1 | MMC_CMD_ADTC ;
	idata.blksz = 512;

	// block_numが0のときはシングルブロック転送を行う
	if(block_num == 0){
		idata.opcode = 49;
		idata.arg = make_cmd49_arg(ext_address, len, fno);
		idata.blocks = block_num + 1;
	}
	// block_numが0以外のときはマルチブロック転送を行う
	else{
		idata.opcode = 59;
		idata.arg = make_cmd59_arg(ext_address, block_num, fno);
		idata.blocks = block_num;
	}

	mmc_ioc_cmd_set_data(idata, pdata);

	return ioctl(fd, MMC_IOC_CMD, &idata);
}

/*---------------------------------------------------------------------------*/
// iSDIOREG_open_ext_reg()
/*---------------------------------------------------------------------------*/
/**
 * @brief デバイスファイルをopenする
 *
 * @param[in]	devname 	  デバイスファイル名
 *
 * @retval		0以上		  デバイスハンドル
 * @retval		0未満		  エラー
 *
 * @par 概要
 *		FlashAirのデバイスファイルをオープンする
 */
/*---------------------------------------------------------------------------*/
int iSDIOREG_open_ext_reg(char *devname)
{
	return open(devname, O_RDWR);
}

/*---------------------------------------------------------------------------*/
// iSDIOREG_close_ext_reg()
/*---------------------------------------------------------------------------*/
/**
 * @brief デバイスファイルをcloseする
 *
 * @param[in]	fd		 デバイスハンドル
 *
 * @return		なし
 *
 * @par 概要
 *		FlashAirのデバイスファイルをクローズする
 */
/*---------------------------------------------------------------------------*/
void iSDIOREG_close_ext_reg(int fd)
{
	close(fd);
}
