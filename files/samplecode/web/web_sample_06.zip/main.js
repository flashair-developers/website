/**
 *  main.js
 *
 *  Created by Junichi Kitano on 2013/05/15.
 * 
 *  Copyright (c) 2013, Fixstars Corporation
 *  All rights reserved.
 *  Released under the BSD 2-Clause license.
 *   http://flashair-developers.com/documents/license.html
 */
//Show file list
function getFileList(){
	//Make backward path
	if(location.pathname!="/"){
		$("#list").append(
			$("<div></div>").append(
				$('<a href="'+location.pathname+'/.." class="dir">..</a>')
			)
		);
	}
	$.each(wlansd,function(){
		var file = this.split(',');
		var filelink = $('<a></a>').attr('href',file[0]+'/'+file[1]).text(file[1]);
		var fileobj = $("<div></div>");
		//for hidden file
		if((file[3] & 0x02) ){
			return;
		}
		if((file[3] & 0x10) ){
			filelink.addClass("dir");
		}else{
			filelink.addClass("file");
			var ext=file[1].split(".");
			if(ext[1]=='JPG'){
				var img = $('<img>').attr("src","/thumbnail.cgi?"+file[0]+'/'+file[1]);
				filelink.append(img);
			}
		}
		$("#list").append(
			fileobj.append(filelink)
		);
	});		
}
//Callback Function for sort()
function cmptime(a, b){
	var g = a.split(",");
	var f = b.split(",");
	if( eval(f[4]) == eval(g[4]) ){
		return eval(f[5] - g[5]);
	}
	else{
		return eval(f[4] - g[4]);
	}
}

//Callback Function for Polling
function polling(){
	var url="/command.cgi?op=102";
	$.get(url,function(data){
		if($.trim(data)=="1"){
			location.reload(true);
		}
	});
}

//Document Ready
$(function() {
	wlansd.sort(cmptime);
	getFileList();
	
	setInterval(function(){
		polling();
	},5000);
});
